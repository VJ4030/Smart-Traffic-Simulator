#pragma once
#include <GL/freeglut.h>
#include <cmath>

enum class CameraView {
    CHASE,
    CLOSE_CHASE,
    HOOD
};

class Camera {
public:
    Camera()
        : m_view(CameraView::CHASE),
          m_posX(0.0f), m_posY(3.5f), m_posZ(-8.0f),
          m_targetX(0.0f), m_targetY(1.0f), m_targetZ(0.0f) {}

    void toggleMode() {
        if (m_view == CameraView::CHASE) m_view = CameraView::CLOSE_CHASE;
        else if (m_view == CameraView::CLOSE_CHASE) m_view = CameraView::HOOD;
        else m_view = CameraView::CHASE;
    }

    void update(float targetX, float targetY, float targetZ, float heading, float dt) {
        float fwdX = std::sin(heading);
        float fwdZ = std::cos(heading);

        float desiredPosX = 0.0f;
        float desiredPosY = 0.0f;
        float desiredPosZ = 0.0f;

        switch (m_view) {
            case CameraView::CHASE:
                desiredPosX = targetX - fwdX * 7.5f;
                desiredPosY = targetY + 3.2f;
                desiredPosZ = targetZ - fwdZ * 7.5f;
                m_targetX = targetX + fwdX * 5.0f;
                m_targetY = targetY + 1.2f;
                m_targetZ = targetZ + fwdZ * 5.0f;
                break;
            case CameraView::CLOSE_CHASE:
                desiredPosX = targetX - fwdX * 4.8f;
                desiredPosY = targetY + 2.0f;
                desiredPosZ = targetZ - fwdZ * 4.8f;
                m_targetX = targetX + fwdX * 6.0f;
                m_targetY = targetY + 1.0f;
                m_targetZ = targetZ + fwdZ * 6.0f;
                break;
            case CameraView::HOOD:
                desiredPosX = targetX + fwdX * 1.5f;
                desiredPosY = targetY + 1.1f;
                desiredPosZ = targetZ + fwdZ * 1.5f;
                m_targetX = targetX + fwdX * 25.0f;
                m_targetY = targetY + 1.0f;
                m_targetZ = targetZ + fwdZ * 25.0f;
                break;
        }

        float smoothFactor = 8.0f * dt;
        if (smoothFactor > 1.0f) smoothFactor = 1.0f;
        m_posX += (desiredPosX - m_posX) * smoothFactor;
        m_posY += (desiredPosY - m_posY) * smoothFactor;
        m_posZ += (desiredPosZ - m_posZ) * smoothFactor;
    }

    void apply() const {
        gluLookAt(m_posX, m_posY, m_posZ,
                  m_targetX, m_targetY, m_targetZ,
                  0.0, 1.0, 0.0);
    }

private:
    CameraView m_view;
    float m_posX, m_posY, m_posZ;
    float m_targetX, m_targetY, m_targetZ;
};
