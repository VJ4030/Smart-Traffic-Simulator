#pragma once
#include <vector>

enum class SignalState {
    GREEN,
    YELLOW,
    RED
};

struct TrafficSignalData {
    float x;
    float z;
    SignalState state;
    float timer;
};

class World {
public:
    World();
    ~World();

    void update(float dt);
    void render() const;
    void spawnTraffic(std::vector<class Vehicle>& aiVehicles, int count);
    const std::vector<TrafficSignalData>& getSignals() const { return m_signals; }

private:
    std::vector<TrafficSignalData> m_signals;

    void renderRoadGrid() const;
    void renderBuildings() const;
    void renderHazards() const;
    void renderSignals() const;
};
