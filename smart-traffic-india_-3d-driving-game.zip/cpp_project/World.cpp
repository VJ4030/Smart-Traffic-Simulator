#include "World.h"
#include "Vehicle.h"
#include <GL/freeglut.h>
#include <cmath>

World::World() {
    m_signals.push_back({ 10.0f, 10.0f, SignalState::GREEN, 0.0f });
    m_signals.push_back({ -10.0f, -10.0f, SignalState::GREEN, 0.0f });
    m_signals.push_back({ 10.0f, -10.0f, SignalState::RED, 15.0f });
    m_signals.push_back({ -10.0f, 10.0f, SignalState::RED, 15.0f });
}

World::~World() {}

void World::update(float dt) {
    for (auto& sig : m_signals) {
        sig.timer += dt;
        float cycle = std::fmod(sig.timer, 30.0f);
        if (cycle < 13.0f) {
            sig.state = SignalState::GREEN;
        } else if (cycle < 16.0f) {
            sig.state = SignalState::YELLOW;
        } else {
            sig.state = SignalState::RED;
        }
    }
}

void World::spawnTraffic(std::vector<Vehicle>& aiVehicles, int count) {
    aiVehicles.clear();
    VehicleType types[] = {
        VehicleType::AUTO_RICKSHAW,
        VehicleType::INDIAN_TRUCK,
        VehicleType::CITY_BUS,
        VehicleType::SEDAN,
        VehicleType::HATCHBACK,
        VehicleType::SUV
    };

    for (int i = 0; i < count; i++) {
        VehicleType t = types[i % 6];
        float laneX = (i % 2 == 0) ? -4.5f : 4.5f;
        float z = -250.0f + i * 25.0f;
        aiVehicles.emplace_back(t, laneX, z, 0.0f, false);
    }
}

void World::render() const {
    renderRoadGrid();
    renderBuildings();
    renderHazards();
    renderSignals();
}

void World::renderRoadGrid() const {
    glColor3f(0.58f, 0.64f, 0.72f);
    glBegin(GL_QUADS);
    glNormal3f(0, 1, 0);
    glVertex3f(-500.0f, 0.0f, -500.0f);
    glVertex3f(-500.0f, 0.0f, 500.0f);
    glVertex3f(500.0f, 0.0f, 500.0f);
    glVertex3f(500.0f, 0.0f, -500.0f);
    glEnd();

    glColor3f(0.15f, 0.15f, 0.17f);
    glBegin(GL_QUADS);
    glNormal3f(0, 1, 0);
    glVertex3f(-9.0f, 0.02f, -500.0f);
    glVertex3f(-9.0f, 0.02f, 500.0f);
    glVertex3f(9.0f, 0.02f, 500.0f);
    glVertex3f(9.0f, 0.02f, -500.0f);

    glVertex3f(-500.0f, 0.02f, -9.0f);
    glVertex3f(-500.0f, 0.02f, 9.0f);
    glVertex3f(500.0f, 0.02f, 9.0f);
    glVertex3f(500.0f, 0.02f, -9.0f);
    glEnd();

    glColor3f(0.98f, 0.8f, 0.1f);
    glLineWidth(3.0f);
    glBegin(GL_LINES);
    glVertex3f(0.0f, 0.03f, -500.0f);
    glVertex3f(0.0f, 0.03f, 500.0f);
    glVertex3f(-500.0f, 0.03f, 0.0f);
    glVertex3f(500.0f, 0.03f, 0.0f);
    glEnd();
}

void World::renderBuildings() const {
    for (int bx = -1; bx <= 1; bx += 2) {
        for (int bz = -1; bz <= 1; bz += 2) {
            glPushMatrix();
            glTranslatef(bx * 70.0f, 15.0f, bz * 70.0f);
            glColor3f(0.85f, 0.88f, 0.92f);
            glScalef(60.0f, 30.0f, 60.0f);
            glutSolidCube(1.0);
            glPopMatrix();
        }
    }
}

void World::renderHazards() const {
    glColor3f(0.95f, 0.8f, 0.1f);
    glPushMatrix();
    glTranslatef(0.0f, 0.08f, 50.0f);
    glScalef(18.0f, 0.2f, 1.4f);
    glutSolidCube(1.0);
    glPopMatrix();

    glColor3f(0.05f, 0.05f, 0.05f);
    glPushMatrix();
    glTranslatef(-4.5f, 0.04f, -70.0f);
    glScalef(2.5f, 0.05f, 2.5f);
    glutSolidCube(1.0);
    glPopMatrix();
}

void World::renderSignals() const {
    for (const auto& sig : m_signals) {
        glPushMatrix();
        glTranslatef(sig.x, 0.0f, sig.z);

        glColor3f(0.28f, 0.33f, 0.41f);
        glPushMatrix();
        glTranslatef(0, 2.5f, 0);
        glScalef(0.3f, 5.0f, 0.3f);
        glutSolidCube(1.0);
        glPopMatrix();

        glColor3f(0.1f, 0.1f, 0.12f);
        glPushMatrix();
        glTranslatef(0, 4.5f, 0);
        glScalef(0.8f, 1.8f, 0.6f);
        glutSolidCube(1.0);
        glPopMatrix();

        if (sig.state == SignalState::RED) glColor3f(1.0f, 0.0f, 0.0f);
        else if (sig.state == SignalState::YELLOW) glColor3f(1.0f, 0.85f, 0.0f);
        else glColor3f(0.0f, 1.0f, 0.0f);

        glPushMatrix();
        glTranslatef(0, 4.5f, 0.35f);
        glutSolidSphere(0.25, 10, 10);
        glPopMatrix();

        glPopMatrix();
    }
}
