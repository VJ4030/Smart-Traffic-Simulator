#pragma once
#include <vector>
#include <string>

enum class VehicleType {
    HATCHBACK,
    SEDAN,
    SUV,
    SPORTS_CAR,
    AUTO_RICKSHAW,
    CITY_BUS,
    INDIAN_TRUCK,
    MOTORCYCLE,
    AMBULANCE
};

class Vehicle {
public:
    Vehicle(VehicleType type, float x, float z, float heading, bool isPlayer = false);
    ~Vehicle();

    void applyInput(float throttle, float steer, bool handbrake, float dt);
    void updateAI(const Vehicle& player, const std::vector<Vehicle>& others, const std::vector<struct TrafficSignalData>& signals, float dt);
    void render() const;

    float getX() const { return m_x; }
    float getY() const { return m_y; }
    float getZ() const { return m_z; }
    float getHeading() const { return m_heading; }
    float getSpeed() const { return m_speed; }
    void setSpeed(float s) { m_speed = s; }

private:
    VehicleType m_type;
    bool m_isPlayer;

    float m_x, m_y, m_z;
    float m_speed;
    float m_heading;
    float m_steerAngle;

    float m_maxSpeed;
    float m_accel;
    float m_brake;
    float m_length;
    float m_width;

    float m_colorR, m_colorG, m_colorB;

    void drawBox(float w, float h, float d) const;
    void drawWheel(float radius, float width) const;
    void renderAutoRickshaw() const;
    void renderIndianTruck() const;
    void renderCityBus() const;
    void renderSedan() const;
    void renderHatchback() const;
    void renderSUV() const;
    void renderSportsCar() const;
    void renderMotorcycle() const;
    void renderAmbulance() const;
};
