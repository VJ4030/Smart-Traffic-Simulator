#include "Vehicle.h"
#include "World.h"
#include <GL/freeglut.h>
#include <cmath>

Vehicle::Vehicle(VehicleType type, float x, float z, float heading, bool isPlayer)
    : m_type(type),
      m_isPlayer(isPlayer),
      m_x(x),
      m_y(0.0f),
      m_z(z),
      m_speed(0.0f),
      m_heading(heading),
      m_steerAngle(0.0f)
{
    switch (type) {
        case VehicleType::AUTO_RICKSHAW:
            m_maxSpeed = 16.0f;
            m_accel = 10.0f;
            m_brake = 18.0f;
            m_length = 2.6f;
            m_width = 1.3f;
            m_colorR = 0.1f; m_colorG = 0.65f; m_colorB = 0.2f;
            break;
        case VehicleType::INDIAN_TRUCK:
            m_maxSpeed = 18.0f;
            m_accel = 6.0f;
            m_brake = 14.0f;
            m_length = 8.8f;
            m_width = 2.4f;
            m_colorR = 0.95f; m_colorG = 0.45f; m_colorB = 0.1f;
            break;
        case VehicleType::CITY_BUS:
            m_maxSpeed = 20.0f;
            m_accel = 7.0f;
            m_brake = 15.0f;
            m_length = 9.5f;
            m_width = 2.5f;
            m_colorR = 0.8f; m_colorG = 0.15f; m_colorB = 0.15f;
            break;
        case VehicleType::AMBULANCE:
            m_maxSpeed = 35.0f;
            m_accel = 15.0f;
            m_brake = 25.0f;
            m_length = 4.8f;
            m_width = 1.85f;
            m_colorR = 0.95f; m_colorG = 0.95f; m_colorB = 0.95f;
            break;
        case VehicleType::SPORTS_CAR:
            m_maxSpeed = 50.0f;
            m_accel = 22.0f;
            m_brake = 30.0f;
            m_length = 4.5f;
            m_width = 1.9f;
            m_colorR = 0.95f; m_colorG = 0.75f; m_colorB = 0.1f;
            break;
        default:
            m_maxSpeed = 32.0f;
            m_accel = 13.0f;
            m_brake = 22.0f;
            m_length = 4.2f;
            m_width = 1.75f;
            m_colorR = 0.15f; m_colorG = 0.45f; m_colorB = 0.85f;
            break;
    }
}

Vehicle::~Vehicle() {}

void Vehicle::applyInput(float throttle, float steer, bool handbrake, float dt) {
    float targetSteer = steer * 0.6f;
    m_steerAngle += (targetSteer - m_steerAngle) * 5.0f * dt;

    if (throttle > 0.0f) {
        m_speed += throttle * m_accel * dt;
    } else if (throttle < 0.0f) {
        m_speed += throttle * m_brake * dt;
    } else {
        if (m_speed > 0.0f) m_speed = std::max(0.0f, m_speed - 3.0f * dt);
        if (m_speed < 0.0f) m_speed = std::min(0.0f, m_speed + 3.0f * dt);
    }

    if (handbrake) {
        m_speed *= std::max(0.0f, 1.0f - 8.0f * dt);
    }

    if (std::abs(m_speed) > 0.1f) {
        m_heading += (m_speed / m_length) * std::tan(m_steerAngle) * dt;
    }

    m_x += std::sin(m_heading) * m_speed * dt;
    m_z += std::cos(m_heading) * m_speed * dt;
}

void Vehicle::updateAI(const Vehicle& player, const std::vector<Vehicle>& others,
                      const std::vector<TrafficSignalData>& signals, float dt) {
    bool shouldBrake = false;

    float dxP = player.getX() - m_x;
    float dzP = player.getZ() - m_z;
    if (std::hypot(dxP, dzP) < 10.0f) {
        shouldBrake = true;
    }

    for (const auto& other : others) {
        if (&other == this) continue;
        float dx = other.getX() - m_x;
        float dz = other.getZ() - m_z;
        float dist = std::hypot(dx, dz);
        if (dist < 12.0f && dz > 0) {
            shouldBrake = true;
            break;
        }
    }

    for (const auto& sig : signals) {
        float dist = std::hypot(sig.x - m_x, sig.z - m_z);
        if (dist < 15.0f && dist > 2.0f && sig.state == SignalState::RED) {
            shouldBrake = true;
            break;
        }
    }

    if (shouldBrake) {
        m_speed = std::max(0.0f, m_speed - 12.0f * dt);
    } else {
        float targetCruising = m_maxSpeed * 0.7f;
        m_speed += (targetCruising - m_speed) * 2.0f * dt;
    }

    m_z += std::cos(m_heading) * m_speed * dt;
    m_x += std::sin(m_heading) * m_speed * dt;

    if (m_z > 350.0f) m_z = -350.0f;
    if (m_z < -350.0f) m_z = 350.0f;
    if (m_x > 350.0f) m_x = -350.0f;
    if (m_x < -350.0f) m_x = 350.0f;
}

void Vehicle::drawBox(float w, float h, float d) const {
    glPushMatrix();
    glScalef(w, h, d);
    glutSolidCube(1.0);
    glPopMatrix();
}

void Vehicle::drawWheel(float radius, float width) const {
    glPushMatrix();
    glColor3f(0.12f, 0.12f, 0.12f);
    glutSolidCylinder(radius, width, 12, 1);
    glPopMatrix();
}

void Vehicle::renderAutoRickshaw() const {
    glColor3f(0.1f, 0.65f, 0.2f);
    glPushMatrix();
    glTranslatef(0, 0.5f, 0);
    drawBox(1.3f, 0.6f, 2.5f);
    glPopMatrix();

    glColor3f(0.95f, 0.8f, 0.1f);
    glPushMatrix();
    glTranslatef(0, 1.45f, 0);
    drawBox(1.25f, 0.15f, 2.3f);
    glPopMatrix();

    glColor3f(0.2f, 0.3f, 0.4f);
    glPushMatrix();
    glTranslatef(0, 1.15f, 0.95f);
    drawBox(1.15f, 0.55f, 0.05f);
    glPopMatrix();
}

void Vehicle::renderIndianTruck() const {
    glColor3f(0.95f, 0.45f, 0.1f);
    glPushMatrix();
    glTranslatef(0, 1.4f, 2.8f);
    drawBox(2.35f, 1.8f, 2.4f);
    glPopMatrix();

    glColor3f(0.95f, 0.85f, 0.1f);
    glPushMatrix();
    glTranslatef(0, 2.4f, 3.1f);
    drawBox(2.5f, 0.4f, 0.6f);
    glPopMatrix();

    glColor3f(0.1f, 0.4f, 0.75f);
    glPushMatrix();
    glTranslatef(0, 1.5f, -1.3f);
    drawBox(2.4f, 1.8f, 5.8f);
    glPopMatrix();
}

void Vehicle::renderCityBus() const {
    glColor3f(0.85f, 0.15f, 0.15f);
    glPushMatrix();
    glTranslatef(0, 1.5f, 0);
    drawBox(2.5f, 2.4f, 9.4f);
    glPopMatrix();

    glColor3f(0.2f, 0.3f, 0.45f);
    glPushMatrix();
    glTranslatef(0, 1.7f, 0);
    drawBox(2.52f, 0.8f, 8.4f);
    glPopMatrix();
}

void Vehicle::renderSedan() const {
    glColor3f(m_colorR, m_colorG, m_colorB);
    glPushMatrix();
    glTranslatef(0, 0.5f, 0);
    drawBox(1.7f, 0.6f, 4.3f);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0, 1.05f, -0.15f);
    drawBox(1.48f, 0.55f, 2.2f);
    glPopMatrix();
}

void Vehicle::render() const {
    glPushMatrix();
    glTranslatef(m_x, m_y, m_z);
    glRotatef(m_heading * 180.0f / 3.14159f, 0, 1, 0);

    switch (m_type) {
        case VehicleType::AUTO_RICKSHAW: renderAutoRickshaw(); break;
        case VehicleType::INDIAN_TRUCK:  renderIndianTruck(); break;
        case VehicleType::CITY_BUS:      renderCityBus(); break;
        default:                         renderSedan(); break;
    }

    glPopMatrix();
}
