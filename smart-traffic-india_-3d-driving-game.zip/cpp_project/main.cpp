/**
 * SMART TRAFFIC INDIA - Native C++ / OpenGL / FreeGLUT Entry Point
 * Target: Visual Studio Community 2022 (x64)
 */

#include <GL/freeglut.h>
#include <iostream>
#include <chrono>
#include "Game.h"

Game* g_game = nullptr;
auto g_lastFrameTime = std::chrono::high_resolution_clock::now();

void displayCallback() {
    if (g_game) g_game->render();
}

void reshapeCallback(int width, int height) {
    if (g_game) g_game->onWindowResize(width, height);
}

void timerCallback(int value) {
    auto currentFrameTime = std::chrono::high_resolution_clock::now();
    std::chrono::duration<float> elapsed = currentFrameTime - g_lastFrameTime;
    g_lastFrameTime = currentFrameTime;

    float dt = elapsed.count();
    if (dt > 0.1f) dt = 0.1f; // clamp delta time

    if (g_game) g_game->update(dt);

    glutPostRedisplay();
    glutTimerFunc(16, timerCallback, 0);
}

void keyDownCallback(unsigned char key, int x, int y) {
    if (g_game) g_game->onKeyDown(key, x, y);
}

void keyUpCallback(unsigned char key, int x, int y) {
    if (g_game) g_game->onKeyUp(key, x, y);
}

void specialKeyDownCallback(int key, int x, int y) {
    if (g_game) g_game->onSpecialKeyDown(key, x, y);
}

void specialKeyUpCallback(int key, int x, int y) {
    if (g_game) g_game->onSpecialKeyUp(key, x, y);
}

int main(int argc, char** argv) {
    std::cout << "========================================================\\n";
    std::cout << "       SMART TRAFFIC INDIA: 3D DRIVING GAME             \\n";
    std::cout << "      OpenGL / FreeGLUT x64 Simulation Architecture    \\n";
    std::cout << "========================================================\\n";

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(1280, 720);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Smart Traffic India - 3D Realistic Driving Simulator");

    g_game = new Game(1280, 720);
    g_game->initOpenGL();

    glutDisplayFunc(displayCallback);
    glutReshapeFunc(reshapeCallback);
    glutKeyboardFunc(keyDownCallback);
    glutKeyboardUpFunc(keyUpCallback);
    glutSpecialFunc(specialKeyDownCallback);
    glutSpecialUpFunc(specialKeyUpCallback);
    glutTimerFunc(16, timerCallback, 0);

    glutMainLoop();

    delete g_game;
    return 0;
}
