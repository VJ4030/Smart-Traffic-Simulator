# SMART TRAFFIC INDIA — VISUAL STUDIO COMMUNITY SETUP GUIDE (x64)

This document provides step-by-step instructions to compile and run the native C++ / OpenGL / FreeGLUT version of Smart Traffic India in **Visual Studio 2022 Community** on Windows (x64 architecture).

---

## Method 1: Install FreeGLUT via Vcpkg (Recommended & Fastest)

1. Open PowerShell / Command Prompt and run:
   ```bash
   git clone https://github.com/microsoft/vcpkg.git
   cd vcpkg
   .\bootstrap-vcpkg.bat
   .\vcpkg.exe integrate install
   .\vcpkg.exe install freeglut:x64-windows
   ```

2. Open `SmartTrafficIndia.sln` in Visual Studio 2022.
3. Set Solution Configuration to **Release** and Platform to **x64**.
4. Press **F5** (or Build -> Build Solution).
5. The game compiles and launches with full hardware-accelerated OpenGL!

---

## Method 2: Manual FreeGLUT Setup in Visual Studio

1. Download FreeGLUT Windows binaries from: https://www.transmissionzero.co.uk/software/freeglut-devel/
2. Extract the archive (e.g. to `C:\freeglut`).
3. In Visual Studio -> Right click Project -> **Properties**:
   - Configuration: **All Configurations**, Platform: **x64**
   - **C/C++ -> General -> Additional Include Directories**: Add `C:\freeglut\include`
   - **Linker -> General -> Additional Library Directories**: Add `C:\freeglut\lib\x64`
   - **Linker -> Input -> Additional Dependencies**: Ensure `freeglut.lib;opengl32.lib;glu32.lib` are listed.
4. Copy `freeglut.dll` from `C:\freeglut\bin\x64` into your output executable directory (e.g. `x64\Release`).
5. Run the game!

---

## In-Game Controls
- **W / Up Arrow**: Accelerate
- **S / Down Arrow**: Brake / Reverse
- **A / Left Arrow**: Steer Left
- **D / Right Arrow**: Steer Right
- **Spacebar**: Handbrake
- **C**: Toggle Camera View (Chase -> Close Chase -> Hood)
- **H**: Electric Horn
- **L**: Toggle Headlights
- **ESC**: Exit Game
