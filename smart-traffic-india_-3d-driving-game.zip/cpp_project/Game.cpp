#include "Game.h"
#include <GL/freeglut.h>
#include <cmath>
#include <sstream>
#include <iomanip>

Game::Game(int windowWidth, int windowHeight)
    : m_windowWidth(windowWidth),
      m_windowHeight(windowHeight),
      m_state(GameState::PLAYING),
      m_playerVehicle(VehicleType::HATCHBACK, -4.5f, -40.0f, 0.0f, true),
      m_camera(),
      m_currentMissionIndex(0),
      m_missionTimer(90.0f),
      m_cash(2500),
      m_score(0),
      m_fuel(100.0f),
      m_vehicleHealth(100.0f),
      m_collisionsCount(0),
      m_redLightViolations(0),
      m_keyUp(false),
      m_keyDown(false),
      m_keyLeft(false),
      m_keyRight(false),
      m_keyHandbrake(false),
      m_headlightsOn(true),
      m_notificationTimer(0.0f)
{
    // Initialize Career Missions
    m_missions.push_back({1, "Morning Commute", "Reach Connaught Place without breaking traffic rules.", 90.0f, -4.5f, 140.0f, 1200, 2});
    m_missions.push_back({2, "Chandni Chowk Rush", "Navigate through heavy auto-rickshaw traffic.", 75.0f, 140.0f, -4.5f, 1800, 1});
    m_missions.push_back({3, "Emergency 108 Run", "Fast escort to City Civil Hospital under time limit.", 60.0f, 140.0f, -140.0f, 3000, 3});

    // Populate AI traffic vehicles
    m_world.spawnTraffic(m_aiVehicles, 24);
}

Game::~Game() {}

void Game::initOpenGL() {
    glClearColor(0.53f, 0.81f, 0.92f, 1.0f); // Indian sky blue
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glShadeModel(GL_SMOOTH);

    // Setup Lighting
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_COLOR_MATERIAL);
    glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);

    GLfloat lightPos[] = { 100.0f, 180.0f, 80.0f, 1.0f };
    GLfloat lightAmbient[] = { 0.35f, 0.35f, 0.35f, 1.0f };
    GLfloat lightDiffuse[] = { 0.95f, 0.9f, 0.85f, 1.0f };
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
    glLightfv(GL_LIGHT0, GL_AMBIENT, lightAmbient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, lightDiffuse);
}

void Game::onWindowResize(int width, int height) {
    m_windowWidth = width;
    m_windowHeight = (height <= 0) ? 1 : height;
    glViewport(0, 0, m_windowWidth, m_windowHeight);
}

void Game::update(float dt) {
    if (m_state != GameState::PLAYING) return;

    if (m_notificationTimer > 0.0f) {
        m_notificationTimer -= dt;
    }

    if (m_missionTimer > 0.0f) {
        m_missionTimer -= dt;
        if (m_missionTimer <= 0.0f) {
            m_state = GameState::GAME_OVER;
            showNotification("Time Up! Destination not reached.");
        }
    }

    updatePhysics(dt);
    updateAITraffic(dt);
    m_world.update(dt);
    checkCollisionsAndRules();

    m_camera.update(m_playerVehicle.getX(), m_playerVehicle.getY(), m_playerVehicle.getZ(),
                    m_playerVehicle.getHeading(), dt);
}

void Game::updatePhysics(float dt) {
    float throttle = 0.0f;
    float steer = 0.0f;

    if (m_keyUp) throttle += 1.0f;
    if (m_keyDown) throttle -= 1.0f;
    if (m_keyLeft) steer -= 1.0f;
    if (m_keyRight) steer += 1.0f;

    m_playerVehicle.applyInput(throttle, steer, m_keyHandbrake, dt);

    if (std::abs(m_playerVehicle.getSpeed()) > 0.5f) {
        m_fuel = std::max(0.0f, m_fuel - 0.2f * dt);
    }
}

void Game::updateAITraffic(float dt) {
    for (auto& ai : m_aiVehicles) {
        ai.updateAI(m_playerVehicle, m_aiVehicles, m_world.getSignals(), dt);
    }
}

void Game::checkCollisionsAndRules() {
    float px = m_playerVehicle.getX();
    float pz = m_playerVehicle.getZ();

    for (auto& ai : m_aiVehicles) {
        float dx = px - ai.getX();
        float dz = pz - ai.getZ();
        float dist = std::sqrt(dx * dx + dz * dz);
        if (dist < 3.2f) {
            m_collisionsCount++;
            m_vehicleHealth = std::max(0.0f, m_vehicleHealth - 15.0f);
            m_playerVehicle.setSpeed(-m_playerVehicle.getSpeed() * 0.3f);
            showNotification("Collision Alert! Vehicle Damaged (-15% HP)");

            if (m_vehicleHealth <= 0.0f) {
                m_state = GameState::GAME_OVER;
            }
        }
    }

    for (const auto& sig : m_world.getSignals()) {
        float dist = std::hypot(px - sig.x, pz - sig.z);
        if (dist < 10.0f && sig.state == SignalState::RED && m_playerVehicle.getSpeed() > 3.0f) {
            m_redLightViolations++;
            m_score = std::max(0, m_score - 100);
            showNotification("Traffic Violation! Red Light Jumped (-100 Score)");
        }
    }

    if (m_currentMissionIndex < (int)m_missions.size()) {
        const auto& mission = m_missions[m_currentMissionIndex];
        float distToTarget = std::hypot(px - mission.targetX, pz - mission.targetZ);
        if (distToTarget < 6.0f && m_playerVehicle.getSpeed() < 3.0f) {
            m_cash += mission.rewardCash;
            m_score += 500;
            m_state = GameState::MISSION_SUCCESS;
            showNotification("Mission Complete! Earned Rs. " + std::to_string(mission.rewardCash));
        }
    }
}

void Game::render() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60.0, (double)m_windowWidth / (double)m_windowHeight, 0.5, 500.0);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    m_camera.apply();

    m_world.render();

    for (const auto& ai : m_aiVehicles) {
        ai.render();
    }

    m_playerVehicle.render();

    renderHUD();

    glutSwapBuffers();
}

void Game::renderText2D(float x, float y, const std::string& text, float r, float g, float b) {
    glColor3f(r, g, b);
    glRasterPos2f(x, y);
    for (char c : text) {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, c);
    }
}

void Game::renderHUD() {
    glDisable(GL_LIGHTING);
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0, m_windowWidth, 0, m_windowHeight);

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();

    std::stringstream ss;
    ss << "SMART TRAFFIC INDIA | SPEED: " << (int)(std::abs(m_playerVehicle.getSpeed()) * 3.6f) << " KM/H";
    ss << " | CASH: Rs. " << m_cash << " | HP: " << (int)m_vehicleHealth << "%";
    renderText2D(30, m_windowHeight - 40, ss.str(), 1.0f, 0.9f, 0.2f);

    if (m_currentMissionIndex < (int)m_missions.size()) {
        std::stringstream ms;
        ms << "MISSION: " << m_missions[m_currentMissionIndex].title << " | TIME: " << (int)m_missionTimer << "s";
        renderText2D(30, m_windowHeight - 70, ms.str(), 0.3f, 1.0f, 0.3f);
    }

    if (m_notificationTimer > 0.0f) {
        renderText2D(m_windowWidth / 2 - 180, m_windowHeight - 120, m_activeNotification, 1.0f, 0.2f, 0.2f);
    }

    renderText2D(30, 25, "[W/UP] Accelerate | [S/DOWN] Brake/Reverse | [A/D] Steer | [SPACE] Handbrake | [C] Camera | [H] Horn", 0.9f, 0.9f, 0.9f);

    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glEnable(GL_LIGHTING);
}

void Game::showNotification(const std::string& msg, float duration) {
    m_activeNotification = msg;
    m_notificationTimer = duration;
}

void Game::onKeyDown(unsigned char key, int x, int y) {
    switch (key) {
        case 'w': case 'W': m_keyUp = true; break;
        case 's': case 'S': m_keyDown = true; break;
        case 'a': case 'A': m_keyLeft = true; break;
        case 'd': case 'D': m_keyRight = true; break;
        case ' ': m_keyHandbrake = true; break;
        case 'c': case 'C': m_camera.toggleMode(); break;
        case 'h': case 'H': showNotification("*HONK HONK!* (Indian Electric Horn)"); break;
        case 'l': case 'L': m_headlightsOn = !m_headlightsOn; break;
        case 27: exit(0); break;
    }
}

void Game::onKeyUp(unsigned char key, int x, int y) {
    switch (key) {
        case 'w': case 'W': m_keyUp = false; break;
        case 's': case 'S': m_keyDown = false; break;
        case 'a': case 'A': m_keyLeft = false; break;
        case 'd': case 'D': m_keyRight = false; break;
        case ' ': m_keyHandbrake = false; break;
    }
}

void Game::onSpecialKeyDown(int key, int x, int y) {
    switch (key) {
        case GLUT_KEY_UP: m_keyUp = true; break;
        case GLUT_KEY_DOWN: m_keyDown = true; break;
        case GLUT_KEY_LEFT: m_keyLeft = true; break;
        case GLUT_KEY_RIGHT: m_keyRight = true; break;
    }
}

void Game::onSpecialKeyUp(int key, int x, int y) {
    switch (key) {
        case GLUT_KEY_UP: m_keyUp = false; break;
        case GLUT_KEY_DOWN: m_keyDown = false; break;
        case GLUT_KEY_LEFT: m_keyLeft = false; break;
        case GLUT_KEY_RIGHT: m_keyRight = false; break;
    }
}
