#pragma once
#include <vector>
#include <string>
#include "Vehicle.h"
#include "World.h"
#include "Camera.h"

enum class GameState {
    MENU,
    CAREER_SELECT,
    PLAYING,
    GARAGE,
    PAUSED,
    MISSION_SUCCESS,
    GAME_OVER
};

struct MissionData {
    int id;
    std::string title;
    std::string description;
    float timeLimit;
    float targetX;
    float targetZ;
    int rewardCash;
    int maxCollisions;
};

class Game {
public:
    Game(int windowWidth, int windowHeight);
    ~Game();

    void initOpenGL();
    void update(float dt);
    void render();
    void onWindowResize(int width, int height);

    void onKeyDown(unsigned char key, int x, int y);
    void onKeyUp(unsigned char key, int x, int y);
    void onSpecialKeyDown(int key, int x, int y);
    void onSpecialKeyUp(int key, int x, int y);

    void startMission(int missionId);
    void startFreeDrive();

private:
    int m_windowWidth;
    int m_windowHeight;
    GameState m_state;

    World m_world;
    Vehicle m_playerVehicle;
    Camera m_camera;

    std::vector<Vehicle> m_aiVehicles;
    std::vector<MissionData> m_missions;
    int m_currentMissionIndex;
    float m_missionTimer;

    int m_cash;
    int m_score;
    float m_fuel;
    float m_vehicleHealth;
    int m_collisionsCount;
    int m_redLightViolations;

    bool m_keyUp;
    bool m_keyDown;
    bool m_keyLeft;
    bool m_keyRight;
    bool m_keyHandbrake;
    bool m_headlightsOn;

    std::string m_activeNotification;
    float m_notificationTimer;

    void updatePhysics(float dt);
    void updateAITraffic(float dt);
    void checkCollisionsAndRules();
    void renderHUD();
    void renderText2D(float x, float y, const std::string& text, float r, float g, float b);
    void showNotification(const std::string& msg, float duration = 2.5f);
};
