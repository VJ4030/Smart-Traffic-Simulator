import JSZip from 'jszip';
import { CPP_SOURCE_FILES } from '../cpp_source/sourceCode';

export async function downloadCppProjectZip(): Promise<void> {
  const zip = new JSZip();
  const folder = zip.folder('SmartTrafficIndia_Cpp_OpenGL');

  if (!folder) return;

  // Add all C++ sources, headers, configs
  for (const file of CPP_SOURCE_FILES) {
    folder.file(file.filename, file.content);
  }

  // Add Solution file .sln
  const slnContent = `Microsoft Visual Studio Solution File, Format Version 12.00
# Visual Studio Version 17
VisualStudioVersion = 17.8.34330.188
MinimumVisualStudioVersion = 10.0.40219.1
Project("{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}") = "SmartTrafficIndia", "SmartTrafficIndia.vcxproj", "{A1B2C3D4-E5F6-7890-ABCD-EF1234567890}"
EndProject
Global
	GlobalSection(SolutionConfigurationPlatforms) = preSolution
		Debug|x64 = Debug|x64
		Release|x64 = Release|x64
	EndGlobalSection
	GlobalSection(ProjectConfigurationPlatforms) = postSolution
		{A1B2C3D4-E5F6-7890-ABCD-EF1234567890}.Debug|x64.ActiveCfg = Debug|x64
		{A1B2C3D4-E5F6-7890-ABCD-EF1234567890}.Debug|x64.Build.0 = Debug|x64
		{A1B2C3D4-E5F6-7890-ABCD-EF1234567890}.Release|x64.ActiveCfg = Release|x64
		{A1B2C3D4-E5F6-7890-ABCD-EF1234567890}.Release|x64.Build.0 = Release|x64
	EndGlobalSection
	GlobalSection(SolutionProperties) = preSolution
		HideSolutionNode = FALSE
	EndGlobalSection
EndGlobal
`;
  folder.file('SmartTrafficIndia.sln', slnContent);

  // Add filters file
  const filtersContent = `<?xml version="1.0" encoding="utf-8"?>
<Project ToolsVersion="4.0" xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
  <ItemGroup>
    <Filter Include="Source Files">
      <UniqueIdentifier>{4FC737F1-C7A5-4376-A066-2A32D752A2FF}</UniqueIdentifier>
      <Extensions>cpp;c;cc;cxx;def;odl;idl;hpj;bat;asm;asmx</Extensions>
    </Filter>
    <Filter Include="Header Files">
      <UniqueIdentifier>{93995380-89BD-4b04-88EB-625FBE52EBFB}</UniqueIdentifier>
      <Extensions>h;hh;hpp;hxx;hm;inl;inc;ipp;xsd</Extensions>
    </Filter>
  </ItemGroup>
  <ItemGroup>
    <ClCompile Include="main.cpp"><Filter>Source Files</Filter></ClCompile>
    <ClCompile Include="Game.cpp"><Filter>Source Files</Filter></ClCompile>
    <ClCompile Include="Vehicle.cpp"><Filter>Source Files</Filter></ClCompile>
    <ClCompile Include="World.cpp"><Filter>Source Files</Filter></ClCompile>
  </ItemGroup>
  <ItemGroup>
    <ClInclude Include="Game.h"><Filter>Header Files</Filter></ClInclude>
    <ClInclude Include="Vehicle.h"><Filter>Header Files</Filter></ClInclude>
    <ClInclude Include="World.h"><Filter>Header Files</Filter></ClInclude>
    <ClInclude Include="Camera.h"><Filter>Header Files</Filter></ClInclude>
  </ItemGroup>
</Project>
`;
  folder.file('SmartTrafficIndia.vcxproj.filters', filtersContent);

  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'SmartTrafficIndia_VisualStudio_x64.zip';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
