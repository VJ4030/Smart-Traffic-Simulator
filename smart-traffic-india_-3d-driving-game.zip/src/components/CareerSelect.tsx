import React from 'react';
import { CAREER_MISSIONS } from '../game/missions';
import { Mission, PlayerStats } from '../types/game';
import { ArrowLeft, CheckCircle2, Clock, Play, ShieldAlert, Trophy } from 'lucide-react';

interface CareerSelectProps {
  stats: PlayerStats;
  onSelectMission: (mission: Mission) => void;
  onBack: () => void;
}

export const CareerSelect: React.FC<CareerSelectProps> = ({
  stats,
  onSelectMission,
  onBack
}) => {
  return (
    <div className="absolute inset-0 bg-slate-950/95 text-white flex flex-col p-4 md:p-8 z-30 overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
        <button
          onClick={onBack}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-sm font-semibold transition"
        >
          <ArrowLeft size={18} />
          <span>Back to Menu</span>
        </button>

        <div className="text-center">
          <h1 className="text-2xl md:text-3xl font-black tracking-tight text-white flex items-center justify-center gap-2">
            <span>CAREER DRIVING MISSIONS</span>
          </h1>
          <p className="text-xs text-slate-400">Master Indian traffic rules, navigate arterial corridors, and earn rewards</p>
        </div>

        <div className="bg-emerald-950/80 border border-emerald-600/80 px-4 py-2 rounded-xl font-mono text-emerald-300 font-bold text-sm md:text-base flex items-center gap-2 shadow-lg">
          <Trophy size={16} />
          <span>{stats.completedMissions.length} / {CAREER_MISSIONS.length} Cleared</span>
        </div>
      </div>

      {/* Grid of Missions */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 max-w-6xl mx-auto w-full pb-8">
        {CAREER_MISSIONS.map(m => {
          const completed = stats.completedMissions.includes(m.id);
          return (
            <div
              key={m.id}
              className={`rounded-2xl border p-5 flex flex-col justify-between transition-all ${
                completed
                  ? 'bg-slate-900/80 border-emerald-700/60 shadow-lg'
                  : 'bg-slate-900/60 hover:bg-slate-900 border-slate-800 hover:border-sky-600 shadow-md'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-mono font-bold uppercase tracking-wider text-sky-400 bg-sky-950/70 border border-sky-800 px-2 py-0.5 rounded">
                    Mission #{m.id}
                  </span>
                  {completed ? (
                    <span className="text-xs font-bold text-emerald-400 flex items-center gap-1 bg-emerald-950/80 px-2.5 py-0.5 rounded-full border border-emerald-800">
                      <CheckCircle2 size={13} /> Completed
                    </span>
                  ) : (
                    <span className="text-xs font-mono text-amber-400">
                      Reward: ₹{m.rewardCash}
                    </span>
                  )}
                </div>

                <h3 className="font-bold text-lg text-white leading-snug">{m.title}</h3>
                <h4 className="text-xs text-amber-400/90 font-medium mb-2">{m.subheading}</h4>
                <p className="text-xs text-slate-300 leading-relaxed mb-4">{m.description}</p>

                {/* Constraint Badges */}
                <div className="grid grid-cols-2 gap-2 text-[11px] font-mono text-slate-400 bg-slate-950/70 p-2.5 rounded-xl border border-slate-800 mb-4">
                  <div className="flex items-center gap-1.5">
                    <Clock size={13} className="text-sky-400" />
                    <span>Time: {m.timeLimitSec}s</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <ShieldAlert size={13} className="text-rose-400" />
                    <span>Max Hits: {m.allowedCollisions}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span>🚦 Max Red: {m.allowedRedLights}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="capitalize">Traffic: {m.trafficDensity}</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => onSelectMission(m)}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-500 hover:to-blue-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-sky-950/50 active:scale-95 transition"
              >
                <Play size={14} /> Start Mission
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
