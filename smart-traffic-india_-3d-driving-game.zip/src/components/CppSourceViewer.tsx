import React, { useState } from 'react';
import { CPP_SOURCE_FILES, CppFileItem } from '../cpp_source/sourceCode';
import { downloadCppProjectZip } from '../utils/zipExporter';
import { ArrowLeft, Check, Copy, Download, FileCode, FolderArchive, Terminal } from 'lucide-react';

interface CppSourceViewerProps {
  onBack: () => void;
}

export const CppSourceViewer: React.FC<CppSourceViewerProps> = ({ onBack }) => {
  const [selectedFile, setSelectedFile] = useState<CppFileItem>(CPP_SOURCE_FILES[0]);
  const [copied, setCopied] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    try {
      setDownloading(true);
      await downloadCppProjectZip();
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="absolute inset-0 bg-slate-950/95 text-white flex flex-col p-4 md:p-6 z-30 overflow-hidden font-sans">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4 shrink-0">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-semibold transition"
          >
            <ArrowLeft size={16} />
            <span>Return to Game</span>
          </button>
          <div>
            <h1 className="text-lg md:text-xl font-bold text-white flex items-center gap-2">
              <Terminal size={20} className="text-sky-400" />
              <span>C++ / OpenGL / FreeGLUT Project Source Code</span>
            </h1>
            <p className="text-xs text-slate-400">Complete, clean C++ implementation targeting Visual Studio 2022 Community x64</p>
          </div>
        </div>

        {/* 1-Click ZIP Download Button */}
        <button
          onClick={handleDownloadZip}
          disabled={downloading}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-emerald-950/50 active:scale-95 transition"
        >
          <FolderArchive size={16} />
          <span>{downloading ? 'Packing ZIP...' : 'Download Visual Studio x64 Project (.ZIP)'}</span>
        </button>
      </div>

      {/* Main Workspace */}
      <div className="flex-1 grid grid-cols-1 md:grid-cols-12 gap-4 overflow-hidden">
        {/* Left File Tree Browser */}
        <div className="md:col-span-3 bg-slate-900/80 border border-slate-800 rounded-xl p-3 flex flex-col overflow-y-auto">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2 px-1">
            Project Files ({CPP_SOURCE_FILES.length})
          </span>

          <div className="flex flex-col gap-1">
            {CPP_SOURCE_FILES.map(file => {
              const active = file.filename === selectedFile.filename;
              return (
                <button
                  key={file.filename}
                  onClick={() => setSelectedFile(file)}
                  className={`px-3 py-2 rounded-lg text-left text-xs font-mono flex items-center justify-between transition ${
                    active
                      ? 'bg-sky-950 text-sky-300 border border-sky-600/70 font-bold'
                      : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <FileCode size={14} className={active ? 'text-sky-400' : 'text-slate-500'} />
                    <span className="truncate">{file.filename}</span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-sans px-1.5 py-0.5 rounded bg-slate-950 border border-slate-800 shrink-0">
                    {file.category}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Quick instructions box */}
          <div className="mt-auto pt-3 border-t border-slate-800 text-[11px] text-slate-400">
            <span className="font-bold text-slate-300 block mb-1">To build on Windows:</span>
            <span>1. Download ZIP & extract</span><br />
            <span>2. Open SmartTrafficIndia.sln</span><br />
            <span>3. Set configuration to Release x64</span><br />
            <span>4. Press F5 to compile & run!</span>
          </div>
        </div>

        {/* Right Code Content Viewer */}
        <div className="md:col-span-9 bg-slate-950 border border-slate-800 rounded-xl flex flex-col overflow-hidden shadow-2xl">
          {/* File bar */}
          <div className="bg-slate-900/90 border-b border-slate-800 px-4 py-2.5 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2 font-mono text-xs text-sky-300">
              <FileCode size={16} />
              <span>{selectedFile.filename}</span>
              <span className="text-slate-500">({selectedFile.category})</span>
            </div>

            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 transition"
            >
              {copied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
              <span>{copied ? 'Copied!' : 'Copy Code'}</span>
            </button>
          </div>

          {/* Code text */}
          <pre className="flex-1 p-4 overflow-auto font-mono text-xs text-slate-300 leading-relaxed bg-[#0b0f19] select-text">
            <code>{selectedFile.content}</code>
          </pre>
        </div>
      </div>
    </div>
  );
};
