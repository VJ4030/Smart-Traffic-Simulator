import React, { useState } from 'react';
import * as THREE from 'three';
import { VEHICLE_CATALOG, buildVehicleMesh } from '../game/vehicleModels';
import { PlayerStats, VehicleDefinition, VehicleId } from '../types/game';
import { ArrowLeft, Check, Lock, Palette, Shield, Sparkles, Zap, Gauge } from 'lucide-react';

interface GarageViewProps {
  stats: PlayerStats;
  onSelectVehicle: (id: VehicleId) => void;
  onBuyVehicle: (id: VehicleId, price: number) => void;
  onColorChange: (id: VehicleId, hex: string) => void;
  onBack: () => void;
}

const ShowroomPreview: React.FC<{ vehicleId: VehicleId; color: string }> = ({ vehicleId, color }) => {
  const mountRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const width = mount.clientWidth || 400;
    const height = mount.clientHeight || 240;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);

    const isLarge = vehicleId === 'city_bus' || vehicleId === 'indian_truck';
    const isSmall = vehicleId === 'auto_rickshaw' || vehicleId === 'motorcycle';
    const camDist = isLarge ? 12 : isSmall ? 5.5 : 7.5;
    camera.position.set(camDist * 0.7, camDist * 0.45, camDist * 0.7);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    mount.appendChild(renderer.domElement);

    // Lights
    const amb = new THREE.AmbientLight(0xffffff, 0.85);
    const dir = new THREE.DirectionalLight(0xfff5e6, 1.4);
    dir.position.set(8, 12, 8);
    const rim = new THREE.DirectionalLight(0x38bdf8, 0.8);
    rim.position.set(-8, 5, -8);
    scene.add(amb, dir, rim);

    // Showroom Pedestal
    const pedGeo = new THREE.CylinderGeometry(isLarge ? 7 : 4, isLarge ? 7.2 : 4.2, 0.3, 36);
    const pedMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.8, roughness: 0.2 });
    const pedestal = new THREE.Mesh(pedGeo, pedMat);
    pedestal.position.y = -0.15;
    scene.add(pedestal);

    // Vehicle
    const mesh = buildVehicleMesh(vehicleId, color);
    scene.add(mesh);

    camera.lookAt(0, isLarge ? 1.4 : 0.8, 0);

    let frameId: number;
    const animate = () => {
      frameId = requestAnimationFrame(animate);
      mesh.rotation.y += 0.012;
      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      if (!mount) return;
      const w = mount.clientWidth;
      const h = mount.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      if (mount.contains(renderer.domElement)) {
        mount.removeChild(renderer.domElement);
      }
    };
  }, [vehicleId, color]);

  return <div ref={mountRef} className="w-full h-full flex items-center justify-center cursor-grab" />;
};

const COLOR_PRESETS = [
  '#0284c7', // Sky Blue
  '#e11d48', // Crimson Red
  '#15803d', // Forest Green
  '#f59e0b', // Amber Gold
  '#7c3aed', // Royal Purple
  '#1e293b', // Midnight Black
  '#f8fafc', // Pearl White
  '#ea580c'  // Saffron Orange
];

export const GarageView: React.FC<GarageViewProps> = ({
  stats,
  onSelectVehicle,
  onBuyVehicle,
  onColorChange,
  onBack
}) => {
  const [selectedIdx, setSelectedIdx] = useState(() => {
    const idx = VEHICLE_CATALOG.findIndex(v => v.id === stats.selectedVehicle);
    return idx >= 0 ? idx : 0;
  });

  const vehicle = VEHICLE_CATALOG[selectedIdx];
  const isUnlocked = stats.unlockedVehicles.includes(vehicle.id);
  const isCurrent = stats.selectedVehicle === vehicle.id;
  const currentColor = stats.customColors[vehicle.id] || vehicle.color;

  return (
    <div className="absolute inset-0 bg-slate-950/95 text-white flex flex-col p-4 md:p-8 z-30 overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
        <button
          onClick={onBack}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-sm font-semibold transition"
        >
          <ArrowLeft size={18} />
          <span>Back to Menu</span>
        </button>

        <div className="text-center">
          <h1 className="text-2xl md:text-3xl font-black tracking-tight text-white flex items-center justify-center gap-2">
            <span>INDIAN MOTOR GARAGE</span>
          </h1>
          <p className="text-xs text-slate-400">Inspect specs, customize authentic livery, and unlock Indian vehicles</p>
        </div>

        <div className="bg-amber-950/80 border border-amber-600/80 px-4 py-2 rounded-xl font-mono text-amber-300 font-bold text-sm md:text-base flex items-center gap-2 shadow-lg">
          <span>₹</span>
          <span>{stats.cash.toLocaleString()} INR</span>
        </div>
      </div>

      {/* Main Garage Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 flex-1 items-start">
        {/* Left: Vehicle Selection Carousel List (All 9 Distinct Indian Vehicles) */}
        <div className="lg:col-span-5 flex flex-col gap-2.5 max-h-[600px] overflow-y-auto pr-1">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1">
            Available Fleet ({VEHICLE_CATALOG.length} Models)
          </span>
          {VEHICLE_CATALOG.map((v, idx) => {
            const unlocked = stats.unlockedVehicles.includes(v.id);
            const active = idx === selectedIdx;
            return (
              <button
                key={v.id}
                onClick={() => setSelectedIdx(idx)}
                className={`p-3.5 rounded-xl border flex items-center justify-between text-left transition ${
                  active
                    ? 'bg-sky-950/70 border-sky-500 shadow-[0_0_15px_rgba(2,132,199,0.25)]'
                    : 'bg-slate-900/60 hover:bg-slate-800/80 border-slate-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className="w-4 h-4 rounded-full border border-white/40 shrink-0"
                    style={{ backgroundColor: stats.customColors[v.id] || v.color }}
                  />
                  <div>
                    <h4 className="font-bold text-sm text-white">{v.name}</h4>
                    <span className="text-[11px] text-slate-400">{v.category}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {unlocked ? (
                    v.id === stats.selectedVehicle ? (
                      <span className="text-xs bg-emerald-950 text-emerald-400 border border-emerald-800 px-2.5 py-1 rounded-full font-bold flex items-center gap-1">
                        <Check size={12} /> Active
                      </span>
                    ) : (
                      <span className="text-xs text-sky-400 font-medium">Ready</span>
                    )
                  ) : (
                    <span className="text-xs bg-amber-950/80 text-amber-300 border border-amber-800 px-2 py-0.5 rounded flex items-center gap-1 font-mono">
                      <Lock size={12} /> ₹{v.price.toLocaleString()}
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Right: Selected Vehicle Details, Performance Specs, Color Customizer */}
        <div className="lg:col-span-7 bg-slate-900/70 border border-slate-800 rounded-2xl p-5 md:p-7 flex flex-col justify-between shadow-2xl">
          <div>
            <div className="flex items-start justify-between">
              <div>
                <span className="text-xs uppercase font-bold text-sky-400 tracking-wider bg-sky-950/80 px-2.5 py-1 rounded border border-sky-800">
                  {vehicle.category}
                </span>
                <h2 className="text-2xl md:text-3xl font-black mt-2 text-white">{vehicle.name}</h2>
                <p className="text-sm text-slate-300 mt-1 max-w-lg">{vehicle.description}</p>
              </div>

              <div className="flex items-center gap-2">
                <span
                  className="w-5 h-5 rounded-full border border-white/40 shadow-inner"
                  style={{ backgroundColor: currentColor }}
                  title="Active Paint Color"
                />
              </div>
            </div>

            {/* 3D Showroom Turntable */}
            <div className="w-full h-52 md:h-60 my-4 rounded-2xl overflow-hidden border border-slate-800 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 relative shadow-inner">
              <ShowroomPreview vehicleId={vehicle.id} color={currentColor} />
              <div className="absolute top-2 left-3 text-[10px] uppercase font-mono tracking-wider text-sky-400 bg-slate-950/80 px-2 py-0.5 rounded border border-slate-800">
                360° Showroom Platform
              </div>
            </div>

            {/* Performance Stat Gauges */}
            <div className="grid grid-cols-2 gap-4 my-6 bg-slate-950/60 p-4 rounded-xl border border-slate-800/80">
              {/* Top Speed */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-400 flex items-center gap-1"><Gauge size={13} /> Top Speed</span>
                  <span className="font-bold text-white font-mono">{vehicle.topSpeedKmh} KM/H</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-amber-500 rounded-full" style={{ width: `${(vehicle.topSpeedKmh / 220) * 100}%` }} />
                </div>
              </div>

              {/* Acceleration */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-400 flex items-center gap-1"><Zap size={13} /> Acceleration</span>
                  <span className="font-bold text-white font-mono">{vehicle.acceleration} / 100</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${vehicle.acceleration}%` }} />
                </div>
              </div>

              {/* Handling */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-400 flex items-center gap-1"><Sparkles size={13} /> City Handling</span>
                  <span className="font-bold text-white font-mono">{vehicle.handling} / 100</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-sky-500 rounded-full" style={{ width: `${vehicle.handling}%` }} />
                </div>
              </div>

              {/* Braking */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-400 flex items-center gap-1"><Shield size={13} /> Brakes Response</span>
                  <span className="font-bold text-white font-mono">{vehicle.braking} / 100</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-rose-500 rounded-full" style={{ width: `${vehicle.braking}%` }} />
                </div>
              </div>
            </div>

            {/* Custom Livery / Color Customizer */}
            <div className="mt-4">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 mb-2.5">
                <Palette size={14} /> Custom Vehicle Paint
              </span>
              <div className="flex items-center gap-2.5 flex-wrap">
                {COLOR_PRESETS.map(hex => (
                  <button
                    key={hex}
                    onClick={() => onColorChange(vehicle.id, hex)}
                    className={`w-8 h-8 rounded-full border-2 transition ${
                      currentColor === hex ? 'scale-125 border-white shadow-lg' : 'border-transparent hover:scale-110'
                    }`}
                    style={{ backgroundColor: hex }}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Action Buttons: Select or Buy */}
          <div className="mt-8 pt-5 border-t border-slate-800 flex items-center justify-between gap-4">
            {isUnlocked ? (
              <button
                disabled={isCurrent}
                onClick={() => onSelectVehicle(vehicle.id)}
                className={`flex-1 py-3.5 rounded-xl font-bold text-sm tracking-wider uppercase flex items-center justify-center gap-2 transition ${
                  isCurrent
                    ? 'bg-slate-800 text-emerald-400 border border-emerald-700/50 cursor-default'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-xl shadow-emerald-950/40'
                }`}
              >
                {isCurrent ? <><Check size={18} /> Selected Vehicle</> : 'Select Vehicle for Drive'}
              </button>
            ) : (
              <button
                disabled={stats.cash < vehicle.price}
                onClick={() => onBuyVehicle(vehicle.id, vehicle.price)}
                className={`flex-1 py-3.5 rounded-xl font-bold text-sm tracking-wider uppercase flex items-center justify-center gap-2 transition ${
                  stats.cash >= vehicle.price
                    ? 'bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-white shadow-xl shadow-orange-950/40'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                }`}
              >
                <Lock size={16} />
                {stats.cash >= vehicle.price ? `Purchase for ₹${vehicle.price.toLocaleString()}` : `Insufficient Cash (Need ₹${vehicle.price.toLocaleString()})`}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
