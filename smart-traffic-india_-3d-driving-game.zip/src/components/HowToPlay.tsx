import React from 'react';
import { ArrowLeft, Car, CheckCircle, Compass, ShieldAlert, Sparkles } from 'lucide-react';

interface HowToPlayProps {
  onBack: () => void;
}

export const HowToPlay: React.FC<HowToPlayProps> = ({ onBack }) => {
  return (
    <div className="absolute inset-0 bg-slate-950/95 text-white flex flex-col p-4 md:p-8 z-30 overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
        <button
          onClick={onBack}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-sm font-semibold transition"
        >
          <ArrowLeft size={18} />
          <span>Back to Menu</span>
        </button>

        <div className="text-center">
          <h1 className="text-2xl md:text-3xl font-black tracking-tight text-white">
            HOW TO PLAY & DRIVING MANUAL
          </h1>
          <p className="text-xs text-slate-400">Rules of the road, vehicle controls, and Indian traffic survival tips</p>
        </div>

        <div className="w-24" />
      </div>

      <div className="max-w-4xl mx-auto w-full flex flex-col gap-6 pb-12 text-sm">
        {/* Controls Grid */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 md:p-6 shadow-xl">
          <h2 className="text-base font-bold uppercase tracking-wider text-amber-400 mb-4 flex items-center gap-2">
            <Car size={18} /> Vehicle Controls
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800 flex items-center justify-between">
              <span className="text-slate-300">Accelerate Forward</span>
              <kbd className="px-2.5 py-1 bg-slate-800 rounded border border-slate-700 font-mono text-xs font-bold text-emerald-400">
                W / Up Arrow
              </kbd>
            </div>
            <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800 flex items-center justify-between">
              <span className="text-slate-300">Brake / Reverse Gear</span>
              <kbd className="px-2.5 py-1 bg-slate-800 rounded border border-slate-700 font-mono text-xs font-bold text-rose-400">
                S / Down Arrow
              </kbd>
            </div>
            <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800 flex items-center justify-between">
              <span className="text-slate-300">Steer Left & Right</span>
              <kbd className="px-2.5 py-1 bg-slate-800 rounded border border-slate-700 font-mono text-xs font-bold text-sky-400">
                A / D or Left / Right
              </kbd>
            </div>
            <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800 flex items-center justify-between">
              <span className="text-slate-300">Handbrake (Drift / E-Brake)</span>
              <kbd className="px-2.5 py-1 bg-slate-800 rounded border border-slate-700 font-mono text-xs font-bold text-amber-400">
                SPACEBAR
              </kbd>
            </div>
            <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800 flex items-center justify-between">
              <span className="text-slate-300">Cycle Camera (Chase, Close, Hood)</span>
              <kbd className="px-2.5 py-1 bg-slate-800 rounded border border-slate-700 font-mono text-xs font-bold text-purple-400">
                C
              </kbd>
            </div>
            <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800 flex items-center justify-between">
              <span className="text-slate-300">Electric Indian Dual Horn</span>
              <kbd className="px-2.5 py-1 bg-slate-800 rounded border border-slate-700 font-mono text-xs font-bold text-yellow-400">
                H
              </kbd>
            </div>
          </div>
          <p className="text-xs text-slate-400 mt-3">
            * Note: Full on-screen touch pedals, steering buttons, and horn are also available for touchscreen laptops and mobile devices!
          </p>
        </div>

        {/* Indian Road Hazards & Signals Guide */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 md:p-6 shadow-xl">
          <h2 className="text-base font-bold uppercase tracking-wider text-rose-400 mb-4 flex items-center gap-2">
            <ShieldAlert size={18} /> Indian Traffic Rules & Hazards
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800">
              <h3 className="font-bold text-amber-300 text-sm mb-1.5 flex items-center gap-1.5">
                🚦 Traffic Light Signals
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Always stop before the white stop line on RED and YELLOW. Jumping a red light costs -100 score points and counts towards mission failure!
              </p>
            </div>

            <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800">
              <h3 className="font-bold text-amber-300 text-sm mb-1.5 flex items-center gap-1.5">
                ⚠️ Speed Breakers
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Slow down below 25 km/h before crossing yellow-and-black painted speed breakers. Hitting them at full speed causes suspension damage and penalties!
              </p>
            </div>

            <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800">
              <h3 className="font-bold text-amber-300 text-sm mb-1.5 flex items-center gap-1.5">
                💥 Monsoon Potholes
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Steer around dark road depressions or slow down below 15 km/h. Driving over deep potholes degrades vehicle health!
              </p>
            </div>
          </div>
        </div>

        {/* Pro Driving Tips */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 md:p-6 shadow-xl">
          <h2 className="text-base font-bold uppercase tracking-wider text-emerald-400 mb-4 flex items-center gap-2">
            <Sparkles size={18} /> Dr. Driving Pro Tips
          </h2>
          <ul className="space-y-2 text-xs text-slate-300">
            <li className="flex items-start gap-2">
              <CheckCircle size={14} className="text-emerald-400 shrink-0 mt-0.5" />
              <span><strong>Drive on the Left Side (LHT):</strong> India drives on the left side of the road! Always stay on the left carriageway. Crossing the central median into oncoming traffic triggers a contraflow warning.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle size={14} className="text-emerald-400 shrink-0 mt-0.5" />
              <span><strong>Follow the 3D GPS Nav Arrow:</strong> The green holographic 3D arrow hovering above your vehicle points directly toward your destination at all times, accompanied by live turn-by-turn HUD guidance.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle size={14} className="text-emerald-400 shrink-0 mt-0.5" />
              <span><strong>Smooth Ride & Handling:</strong> Steering sensitivity adjusts automatically based on your speed—sharp and agile at low speeds, stable and smooth on expressways. The dynamic suspension absorbs road ripples.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle size={14} className="text-emerald-400 shrink-0 mt-0.5" />
              <span><strong>Watch AI Auto-Rickshaws:</strong> Tuk-tuks turn rapidly and have tight turning radiuses. Give them a wide berth when overtaking.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle size={14} className="text-emerald-400 shrink-0 mt-0.5" />
              <span><strong>Honk to Clear Lanes:</strong> Pressing H sounds the dual-tone horn, prompting nearby AI drivers to check their mirrors and make way.</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};
