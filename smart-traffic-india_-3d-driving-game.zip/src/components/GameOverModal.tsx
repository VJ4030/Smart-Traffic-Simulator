import React from 'react';
import { AlertTriangle, RotateCcw } from 'lucide-react';

interface GameOverModalProps {
  reason?: string;
  onRestart: () => void;
  onMenu: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  reason,
  onRestart,
  onMenu
}) => {
  return (
    <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 z-40 select-none">
      <div className="bg-slate-900 border-2 border-rose-600/80 rounded-3xl p-6 md:p-8 max-w-md w-full shadow-2xl text-center text-white animate-in fade-in zoom-in duration-200">
        <div className="w-16 h-16 bg-rose-950 border-2 border-rose-600 rounded-full flex items-center justify-center mx-auto mb-4 text-rose-400">
          <AlertTriangle size={36} />
        </div>

        <span className="text-xs font-mono uppercase tracking-widest text-rose-400 font-bold">
          MISSION FAILED
        </span>
        <h2 className="text-2xl md:text-3xl font-black text-white mt-1">
          Challan & Breakdown!
        </h2>
        <p className="text-xs text-rose-300 mt-2 bg-rose-950/60 p-3 rounded-xl border border-rose-800">
          {reason || 'Vehicle was totalled or critical traffic regulations were violated.'}
        </p>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2.5 mt-6">
          <button
            onClick={onRestart}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-xl shadow-rose-950/50 active:scale-95 transition"
          >
            <RotateCcw size={16} />
            <span>Try Again</span>
          </button>

          <button
            onClick={onMenu}
            className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs transition"
          >
            Return to Main Menu
          </button>
        </div>
      </div>
    </div>
  );
};
