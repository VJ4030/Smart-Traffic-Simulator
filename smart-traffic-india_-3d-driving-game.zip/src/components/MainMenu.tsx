import React from 'react';
import { PlayerStats } from '../types/game';
import {
  Car,
  Compass,
  FileCode,
  HelpCircle,
  Play,
  Trophy,
  Volume2,
  VolumeX,
  Wrench,
  FolderArchive
} from 'lucide-react';
import { soundManager } from '../audio/soundManager';

interface MainMenuProps {
  stats: PlayerStats;
  onStartCareer: () => void;
  onStartFreeDrive: () => void;
  onOpenGarage: () => void;
  onOpenHowToPlay: () => void;
  onOpenCppCode: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  stats,
  onStartCareer,
  onStartFreeDrive,
  onOpenGarage,
  onOpenHowToPlay,
  onOpenCppCode
}) => {
  const [muted, setMuted] = React.useState(soundManager.isMuted());

  const toggleSound = () => {
    const next = !muted;
    soundManager.setMuted(next);
    setMuted(next);
  };

  return (
    <div className="absolute inset-0 bg-gradient-to-b from-slate-950/85 via-slate-900/90 to-slate-950/95 flex flex-col justify-between p-4 sm:p-6 md:p-10 z-30 select-none text-white backdrop-blur-sm overflow-y-auto">
      {/* Top Header */}
      <div className="flex items-center justify-between w-full">
        <div className="flex items-center gap-2">
          {/* Subtle Indian Tricolor Badge */}
          <div className="flex h-5 w-8 rounded overflow-hidden shadow">
            <div className="w-1/3 bg-[#ff9933]" />
            <div className="w-1/3 bg-white" />
            <div className="w-1/3 bg-[#138808]" />
          </div>
          <span className="text-xs font-mono font-bold tracking-widest text-slate-300">
            MADE FOR INDIA • OPENGL 3D
          </span>
        </div>

        <div className="flex items-center gap-3">
          {/* Stats Badges */}
          <div className="bg-slate-900/90 border border-slate-700/80 px-3.5 py-1.5 rounded-xl font-mono text-xs flex items-center gap-2 shadow">
            <span className="text-amber-400 font-bold">₹{stats.cash.toLocaleString()}</span>
          </div>

          <div className="bg-slate-900/90 border border-slate-700/80 px-3.5 py-1.5 rounded-xl font-mono text-xs flex items-center gap-2 shadow">
            <Trophy size={14} className="text-emerald-400" />
            <span className="text-white font-bold">{stats.highScore} PTS</span>
          </div>

          <button
            onClick={toggleSound}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 transition"
            title="Toggle Audio"
          >
            {muted ? <VolumeX size={18} /> : <Volume2 size={18} />}
          </button>
        </div>
      </div>

      {/* Hero Title & Main Actions */}
      <div className="max-w-xl mx-auto text-center flex flex-col items-center my-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold mb-3">
          <span>🚦 REALISTIC 3D DRIVING SIMULATOR</span>
        </div>

        <h1 className="text-4xl md:text-6xl font-black tracking-tight leading-none text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-white to-emerald-400 drop-shadow-[0_5px_15px_rgba(0,0,0,0.8)]">
          SMART TRAFFIC INDIA
        </h1>
        <p className="text-xs md:text-sm text-slate-300 mt-3 max-w-md">
          Authentic Indian arterial traffic, dynamic signal AI, auto-rickshaws, potholes, and speed breakers powered by 3D OpenGL mechanics.
        </p>

        {/* Menu Buttons Stack */}
        <div className="flex flex-col gap-3 w-full max-w-sm mt-8">
          <button
            onClick={onStartCareer}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2.5 shadow-xl shadow-amber-950/50 active:scale-95 transition"
          >
            <Play size={18} fill="currentColor" />
            <span>Career Mode (Missions)</span>
          </button>

          <button
            onClick={onStartFreeDrive}
            className="w-full py-3 rounded-2xl bg-slate-800/90 hover:bg-slate-700 border border-slate-700 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg active:scale-95 transition"
          >
            <Compass size={16} className="text-sky-400" />
            <span>Free Drive (Continuous City)</span>
          </button>

          <div className="grid grid-cols-2 gap-2.5">
            <button
              onClick={onOpenGarage}
              className="py-3 rounded-2xl bg-slate-800/90 hover:bg-slate-700 border border-slate-700 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition"
            >
              <Car size={16} className="text-amber-400" />
              <span>Garage (Fleet)</span>
            </button>

            <button
              onClick={onOpenHowToPlay}
              className="py-3 rounded-2xl bg-slate-800/90 hover:bg-slate-700 border border-slate-700 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition"
            >
              <HelpCircle size={16} className="text-emerald-400" />
              <span>How To Play</span>
            </button>
          </div>

          {/* C++ OpenGL Source Code & Download Button */}
          <button
            onClick={onOpenCppCode}
            className="w-full py-2.5 rounded-xl bg-sky-950/80 hover:bg-sky-900/90 border border-sky-600/60 text-sky-200 font-mono text-xs font-semibold flex items-center justify-center gap-2 shadow-lg transition"
          >
            <FileCode size={15} />
            <span>View & Download C++ OpenGL Source (.ZIP)</span>
          </button>
        </div>
      </div>

      {/* Footer Info */}
      <div className="flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-800/80 pt-4">
        <span>Controls: WASD / Arrow Keys • Space (Handbrake) • H (Horn) • C (Camera)</span>
        <span className="font-mono text-slate-400">Target: Visual Studio Community 2022 (x64)</span>
      </div>
    </div>
  );
};
