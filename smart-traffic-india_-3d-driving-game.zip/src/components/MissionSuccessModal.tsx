import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Mission, PlayerStats } from '../types/game';
import { Award, CheckCircle2, RotateCcw, ArrowRight } from 'lucide-react';

interface MissionSuccessModalProps {
  mission: Mission | null;
  score: number;
  cashEarned: number;
  onNextMission: () => void;
  onRestart: () => void;
  onMenu: () => void;
}

export const MissionSuccessModal: React.FC<MissionSuccessModalProps> = ({
  mission,
  score,
  cashEarned,
  onNextMission,
  onRestart,
  onMenu
}) => {
  useEffect(() => {
    // Confetti celebration
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 }
    });
  }, []);

  return (
    <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 z-40 select-none">
      <div className="bg-slate-900 border-2 border-emerald-500/80 rounded-3xl p-6 md:p-8 max-w-md w-full shadow-2xl text-center text-white animate-in fade-in zoom-in duration-200">
        <div className="w-16 h-16 bg-emerald-950 border-2 border-emerald-500 rounded-full flex items-center justify-center mx-auto mb-4 text-emerald-400">
          <CheckCircle2 size={36} />
        </div>

        <span className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-bold">
          MISSION ACCOMPLISHED!
        </span>
        <h2 className="text-2xl md:text-3xl font-black text-white mt-1">
          {mission ? mission.title : 'Free Drive Run Finished'}
        </h2>
        <p className="text-xs text-slate-300 mt-1">
          Arrived safely at the destination waypoint complying with Indian traffic regulations.
        </p>

        {/* Score & Cash breakdown */}
        <div className="grid grid-cols-2 gap-3 my-6 bg-slate-950 p-4 rounded-2xl border border-slate-800">
          <div>
            <span className="text-xs text-slate-400 block">Total Score</span>
            <span className="text-xl md:text-2xl font-black text-white font-mono">{score}</span>
          </div>
          <div>
            <span className="text-xs text-slate-400 block">Reward Cash</span>
            <span className="text-xl md:text-2xl font-black text-amber-400 font-mono">+₹{cashEarned.toLocaleString()}</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2.5">
          <button
            onClick={onNextMission}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-xl shadow-emerald-950/50 active:scale-95 transition"
          >
            <span>Continue Next Mission</span>
            <ArrowRight size={16} />
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={onRestart}
              className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs flex items-center justify-center gap-1.5 transition"
            >
              <RotateCcw size={14} />
              <span>Retry</span>
            </button>
            <button
              onClick={onMenu}
              className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs transition"
            >
              Main Menu
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
