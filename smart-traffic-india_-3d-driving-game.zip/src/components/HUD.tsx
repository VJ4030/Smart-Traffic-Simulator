import React, { useEffect, useRef } from 'react';
import {
  CameraMode,
  DrivingTelemetry,
  Mission,
  TrafficSignal
} from '../types/game';
import {
  Camera,
  Flame,
  Heart,
  Lightbulb,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Navigation
} from 'lucide-react';
import { soundManager } from '../audio/soundManager';

interface HUDProps {
  telemetry: DrivingTelemetry;
  mission: Mission | null;
  cameraMode: CameraMode;
  onCameraChange: () => void;
  onHeadlightsToggle: () => void;
  onHonk: () => void;
  onPause: () => void;
  onRestart: () => void;
  playerPos: { x: number; z: number; angle: number };
  signals: TrafficSignal[];
  onPedalPress: (throttle: number) => void;
  onSteerPress: (steer: number) => void;
  onHandbrakePress: (active: boolean) => void;
  hazardAlert: { message: string; type: 'warning' | 'danger' | 'info' } | null;
  onToggleBlinker?: (dir: 'left' | 'right') => void;
  blinkerState?: 'off' | 'left' | 'right';
}

export const HUD: React.FC<HUDProps> = ({
  telemetry,
  mission,
  cameraMode,
  onCameraChange,
  onHeadlightsToggle,
  onHonk,
  onPause,
  onRestart,
  playerPos,
  signals,
  onPedalPress,
  onSteerPress,
  onHandbrakePress,
  hazardAlert,
  onToggleBlinker,
  blinkerState = 'off'
}) => {
  const radarCanvasRef = useRef<HTMLCanvasElement>(null);
  const [muted, setMuted] = React.useState(soundManager.isMuted());

  // Find nearest traffic signal ahead
  const nearestSignal = React.useMemo<{ signal: TrafficSignal; dist: number } | null>(() => {
    let nearest: { signal: TrafficSignal; dist: number } | null = null;
    let minD = 999;
    signals.forEach(sig => {
      const d = Math.hypot(sig.x - playerPos.x, sig.z - playerPos.z);
      if (d < 45 && d < minD) {
        minD = d;
        nearest = { signal: sig, dist: Math.round(d) };
      }
    });
    return nearest;
  }, [signals, playerPos]);

  // Render Minimap Radar with GPS Navigation Route
  useEffect(() => {
    const canvas = radarCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    // Dark circular radar background
    ctx.fillStyle = 'rgba(15, 23, 42, 0.90)';
    ctx.beginPath();
    ctx.arc(w / 2, h / 2, w / 2 - 2, 0, Math.PI * 2);
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = '#0284c7';
    ctx.stroke();

    // Radar distance rings
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.2)';
    ctx.beginPath();
    ctx.arc(w / 2, h / 2, w / 4, 0, Math.PI * 2);
    ctx.arc(w / 2, h / 2, w / 2.5, 0, Math.PI * 2);
    ctx.stroke();

    // Rotate map relative to player car heading
    ctx.save();
    ctx.translate(w / 2, h / 2);
    ctx.rotate(-playerPos.angle);

    const scale = 0.65; // pixels per meter

    // Draw City Roads Grid
    ctx.fillStyle = 'rgba(71, 85, 105, 0.6)';
    [-280, -140, 0, 140, 280].forEach(rx => {
      const relX = (rx - playerPos.x) * scale;
      ctx.fillRect(relX - 5, -h, 10, h * 2);
    });
    [-280, -140, 0, 140, 280].forEach(rz => {
      const relZ = (rz - playerPos.z) * scale;
      ctx.fillRect(-w, relZ - 5, w * 2, 10);
    });

    // Destination Pin & GPS Navigation Vector
    const nav = telemetry.navigation;
    const targetX = nav?.targetX ?? (mission ? mission.targetX : 0);
    const targetZ = nav?.targetZ ?? (mission ? mission.targetZ : 140);

    const destRelX = (targetX - playerPos.x) * scale;
    const destRelZ = (targetZ - playerPos.z) * scale;
    const distPixels = Math.hypot(destRelX, destRelZ);
    const maxRadius = w / 2 - 8;

    // Green dynamic navigation trail
    ctx.strokeStyle = 'rgba(16, 185, 129, 0.5)';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    if (distPixels <= maxRadius) {
      ctx.lineTo(destRelX, destRelZ);
    } else {
      const factor = maxRadius / distPixels;
      ctx.lineTo(destRelX * factor, destRelZ * factor);
    }
    ctx.stroke();

    // Destination Pin (Clamped to perimeter if beyond radar range)
    ctx.save();
    if (distPixels <= maxRadius) {
      ctx.translate(destRelX, destRelZ);
    } else {
      const factor = maxRadius / distPixels;
      ctx.translate(destRelX * factor, destRelZ * factor);
    }

    ctx.fillStyle = '#10b981';
    ctx.beginPath();
    ctx.arc(0, 0, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.restore();

    ctx.restore();

    // Player Vehicle Icon (Centered, pointing forward UP)
    ctx.save();
    ctx.translate(w / 2, h / 2);
    ctx.fillStyle = '#f59e0b';
    ctx.beginPath();
    ctx.moveTo(0, -7);
    ctx.lineTo(5, 6);
    ctx.lineTo(0, 3);
    ctx.lineTo(-5, 6);
    ctx.closePath();
    ctx.fill();
    ctx.restore();

    // North Compass Indicator
    ctx.save();
    ctx.translate(w / 2, 10);
    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 9px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('N', 0, 0);
    ctx.restore();
  }, [playerPos, mission, telemetry.navigation]);

  const toggleSound = () => {
    const next = !muted;
    soundManager.setMuted(next);
    setMuted(next);
  };

  const nav = telemetry.navigation;

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-2 sm:p-4 md:p-6 select-none font-sans">
      {/* Top Bar: Mission Info, Center GPS Navigation, and Quick Controls */}
      <div className="flex items-start justify-between w-full gap-3">
        {/* Left: Mission / Mode Objective Card */}
        <div className="pointer-events-auto bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded-xl p-3 md:p-4 text-white shadow-xl max-w-xs md:max-w-sm hidden sm:block">
          {mission ? (
            <div>
              <div className="flex items-center justify-between gap-3 mb-1">
                <span className="text-xs uppercase tracking-wider font-semibold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800">
                  Mission #{mission.id}
                </span>
                <span className="text-xs font-mono font-bold text-amber-400">
                  ⏱️ {Math.max(0, Math.round(telemetry.distanceTravelledMeters))}m
                </span>
              </div>
              <h3 className="font-bold text-sm md:text-base leading-tight text-white">{mission.title}</h3>
              <p className="text-xs text-slate-300 mt-0.5 line-clamp-1">{mission.subheading}</p>

              <div className="flex items-center gap-4 mt-2 pt-2 border-t border-slate-800 text-xs">
                <div className="text-slate-300">
                  Collisions: <span className="font-bold text-red-400">{telemetry.collisions} / {mission.allowedCollisions}</span>
                </div>
                <div className="text-slate-300">
                  Signals: <span className="font-bold text-amber-400">{telemetry.redLightViolations} / {mission.allowedRedLights}</span>
                </div>
              </div>
            </div>
          ) : (
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs uppercase tracking-wider font-bold text-sky-400 bg-sky-950/60 px-2 py-0.5 rounded border border-sky-800">
                  Free Drive Mode
                </span>
              </div>
              <h3 className="font-bold text-sm md:text-base text-white">Indian Metropolis Roam</h3>
              <p className="text-xs text-slate-300">Explore multi-lane avenues, obey signals, and follow the GPS navigation arrow.</p>
            </div>
          )}
        </div>

        {/* Center: Turn-by-Turn GPS Navigation Banner & Signal Alerts */}
        <div className="flex flex-col items-center pointer-events-auto gap-2 flex-1 max-w-lg">
          {/* Turn-by-Turn GPS Navigation Card */}
          {nav && (
            <div className="w-full bg-slate-900/95 backdrop-blur-md border border-slate-700/80 rounded-2xl px-3 md:px-4 py-2.5 shadow-2xl flex items-center justify-between gap-3 text-white transition-all">
              <div className="flex items-center gap-3">
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-xl shadow-lg shrink-0 ${
                    nav.turnInstruction === 'arriving'
                      ? 'bg-emerald-500 text-slate-950 animate-bounce'
                      : nav.turnInstruction === 'left'
                      ? 'bg-sky-500 text-white'
                      : nav.turnInstruction === 'right'
                      ? 'bg-sky-500 text-white'
                      : nav.turnInstruction === 'uturn'
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-emerald-600 text-white'
                  }`}
                >
                  {nav.turnInstruction === 'arriving' ? '🏁' :
                   nav.turnInstruction === 'left' ? '↰' :
                   nav.turnInstruction === 'right' ? '↱' :
                   nav.turnInstruction === 'uturn' ? '⤹' : '⬆'}
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-xs md:text-sm tracking-tight text-white line-clamp-1">
                      {nav.instructionText}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                    <span className="text-emerald-400 font-bold truncate max-w-[150px] md:max-w-[200px]">
                      🎯 {nav.goalTitle}
                    </span>
                    <span>•</span>
                    <span className="font-mono text-amber-300 font-semibold">{nav.distanceMeters}m</span>
                  </div>
                </div>
              </div>

              {/* Indian Left-Hand Traffic (LHT) Keep Left Indicator */}
              <div className="flex flex-col items-end shrink-0">
                {nav.isWrongLane ? (
                  <span className="px-2 py-1 rounded-lg bg-rose-600 text-white font-extrabold text-[10px] tracking-wider uppercase animate-pulse border border-rose-400 shadow-md">
                    ⚠️ WRONG LANE
                  </span>
                ) : (
                  <div className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-950/80 border border-emerald-700/60 text-emerald-400 font-mono text-[10px] tracking-wider uppercase">
                    <span>🇮🇳</span>
                    <span>KEEP LEFT</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Active Traffic Rules & Compliance Feedback Banner */}
          {telemetry.activeRuleTip && (
            <div className="w-full bg-slate-900/90 backdrop-blur-md border border-slate-700/70 text-slate-200 text-xs font-semibold px-3 py-1.5 rounded-xl shadow-lg flex items-center justify-between">
              <span className="flex items-center gap-1.5 truncate">
                {telemetry.activeRuleTip}
              </span>
              <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-slate-800 text-amber-400 border border-slate-700 shrink-0 ml-2">
                Indian Traffic Rules
              </span>
            </div>
          )}

          {/* Contraflow Wrong Lane Driving Banner */}
          {nav?.isWrongLane && (
            <div className="w-full bg-rose-950/90 border border-rose-600 text-rose-200 text-xs font-bold px-3 py-1.5 rounded-xl shadow-lg flex items-center justify-center gap-2 animate-pulse">
              <span>⚠️ Oncoming Traffic! Steer to the Left Carriageway (LHT)</span>
            </div>
          )}

          {/* Live Hazard or Signal Violation Notification */}
          {hazardAlert && (
            <div
              className={`px-4 py-2 rounded-xl border backdrop-blur-md text-xs md:text-sm font-bold shadow-2xl flex items-center gap-2 animate-bounce ${
                hazardAlert.type === 'danger'
                  ? 'bg-rose-950/90 text-rose-200 border-rose-600'
                  : hazardAlert.type === 'warning'
                  ? 'bg-amber-950/90 text-amber-200 border-amber-600'
                  : 'bg-sky-950/90 text-sky-200 border-sky-600'
              }`}
            >
              <span>{hazardAlert.message}</span>
            </div>
          )}

          {/* Next Signal Indicator */}
          {nearestSignal && (
            <div className="bg-slate-900/85 backdrop-blur-md border border-slate-700 px-3 py-1 rounded-full flex items-center gap-2.5 text-xs text-white shadow-lg">
              <span className="text-slate-400">Signal ({nearestSignal.dist}m):</span>
              <div className="flex items-center gap-1.5 bg-slate-950 px-2 py-0.5 rounded-full border border-slate-800">
                <div
                  className={`w-2.5 h-2.5 rounded-full transition-all ${
                    nearestSignal.signal.state === 'red' ? 'bg-red-500 shadow-[0_0_8px_#ef4444]' : 'bg-red-950'
                  }`}
                />
                <div
                  className={`w-2.5 h-2.5 rounded-full transition-all ${
                    nearestSignal.signal.state === 'yellow' ? 'bg-amber-400 shadow-[0_0_8px_#fbbf24]' : 'bg-amber-950'
                  }`}
                />
                <div
                  className={`w-2.5 h-2.5 rounded-full transition-all ${
                    nearestSignal.signal.state === 'green' ? 'bg-emerald-500 shadow-[0_0_8px_#10b981]' : 'bg-emerald-950'
                  }`}
                />
              </div>
            </div>
          )}
        </div>

        {/* Right: Minimap Radar & Quick Actions */}
        <div className="flex flex-col items-end gap-1.5 sm:gap-2 pointer-events-auto shrink-0">
          <div className="relative">
            <canvas
              ref={radarCanvasRef}
              width={96}
              height={96}
              className="rounded-full shadow-2xl border-2 border-sky-500/50 w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24"
            />
            <div className="absolute bottom-0.5 right-0.5 bg-slate-900/90 text-[8px] sm:text-[9px] text-sky-400 px-1 py-0.2 rounded font-mono border border-slate-700">
              GPS
            </div>
          </div>

          <div className="flex items-center gap-1 sm:gap-1.5 bg-slate-900/80 backdrop-blur-md p-1 sm:p-1.5 rounded-xl border border-slate-700/70">
            <button
              onClick={toggleSound}
              className="p-1 sm:p-1.5 md:p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition"
              title="Toggle Audio"
            >
              {muted ? <VolumeX size={14} /> : <Volume2 size={14} />}
            </button>
            <button
              onClick={onCameraChange}
              className="p-1 sm:p-1.5 md:p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition flex items-center gap-1 text-xs"
              title="Change Camera"
            >
              <Camera size={14} />
              <span className="hidden sm:inline uppercase text-[10px]">{cameraMode.replace('_', ' ')}</span>
            </button>
            <button
              onClick={onHeadlightsToggle}
              className={`p-1 sm:p-1.5 md:p-2 rounded-lg transition ${
                telemetry.headlightsOn ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' : 'bg-slate-800 text-slate-400'
              }`}
              title="Toggle Headlights"
            >
              <Lightbulb size={14} />
            </button>
            <button
              onClick={onRestart}
              className="p-1 sm:p-1.5 md:p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition"
              title="Restart Level"
            >
              <RotateCcw size={14} />
            </button>
            <button
              onClick={onPause}
              className="p-1 sm:p-1.5 md:p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition"
              title="Pause Game"
            >
              <Pause size={14} />
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Area: Digital Speedometer, Smooth Steering Gauge, and Controls */}
      <div className="w-full flex items-end justify-between gap-1.5 sm:gap-3 pointer-events-auto select-none">
        {/* Left Touch Controls: Steering Buttons */}
        <div className="flex flex-col gap-1.5 sm:gap-2 shrink-0">
          <div className="flex items-center gap-1.5 sm:gap-2">
            <button
              onPointerDown={(e) => {
                e.preventDefault();
                (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
                onSteerPress(-1);
              }}
              onPointerUp={(e) => {
                e.preventDefault();
                try { (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId); } catch {}
                onSteerPress(0);
              }}
              onPointerCancel={(e) => {
                e.preventDefault();
                try { (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId); } catch {}
                onSteerPress(0);
              }}
              onContextMenu={(e) => e.preventDefault()}
              className="w-13 h-13 sm:w-16 sm:h-16 md:w-20 md:h-20 rounded-2xl bg-slate-900/85 hover:bg-slate-800 active:bg-amber-500/30 border-2 border-slate-700 active:border-amber-400 flex items-center justify-center text-white text-xl sm:text-2xl font-bold shadow-2xl transition active:scale-95 touch-none select-none"
              title="Steer Left [A]"
            >
              ◀
            </button>
            <button
              onPointerDown={(e) => {
                e.preventDefault();
                (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
                onSteerPress(1);
              }}
              onPointerUp={(e) => {
                e.preventDefault();
                try { (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId); } catch {}
                onSteerPress(0);
              }}
              onPointerCancel={(e) => {
                e.preventDefault();
                try { (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId); } catch {}
                onSteerPress(0);
              }}
              onContextMenu={(e) => e.preventDefault()}
              className="w-13 h-13 sm:w-16 sm:h-16 md:w-20 md:h-20 rounded-2xl bg-slate-900/85 hover:bg-slate-800 active:bg-amber-500/30 border-2 border-slate-700 active:border-amber-400 flex items-center justify-center text-white text-xl sm:text-2xl font-bold shadow-2xl transition active:scale-95 touch-none select-none"
              title="Steer Right [D]"
            >
              ▶
            </button>
          </div>
          <button
            onClick={onHonk}
            onContextMenu={(e) => e.preventDefault()}
            className="w-full py-1.5 sm:py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-bold text-[10px] sm:text-xs uppercase tracking-wider flex items-center justify-center gap-1 shadow-lg active:scale-95 transition touch-none select-none"
          >
            📢 HONK [H]
          </button>
        </div>

        {/* Center: Dr. Driving Style Speedometer Cluster with Steering Arc */}
        <div className="bg-slate-950/90 backdrop-blur-xl border border-slate-800 px-2 sm:px-4 md:px-6 py-1.5 sm:py-3 rounded-2xl shadow-2xl flex flex-col items-center shrink min-w-0">
          {/* Health & Fuel */}
          <div className="flex items-center gap-2 sm:gap-4 md:gap-6 mb-1 sm:mb-2 w-full justify-between text-[10px] sm:text-xs font-mono">
            <div className="flex items-center gap-1 sm:gap-1.5 text-rose-400">
              <Heart size={12} className="sm:w-3.5 sm:h-3.5" />
              <span className="hidden sm:inline">HP</span>
              <div className="w-10 sm:w-14 md:w-16 bg-slate-800 h-1.5 sm:h-2 rounded-full overflow-hidden">
                <div
                  className="bg-rose-500 h-full transition-all"
                  style={{ width: `${telemetry.healthPercent}%` }}
                />
              </div>
            </div>

            {/* Gear & Blinker Indicators */}
            <div className="flex items-center gap-1 sm:gap-2">
              <button
                onClick={() => onToggleBlinker?.('left')}
                className={`px-1.5 sm:px-2 py-0.5 rounded text-[10px] sm:text-xs font-bold transition flex items-center gap-0.5 sm:gap-1 ${
                  blinkerState === 'left'
                    ? 'bg-amber-400 text-slate-950 font-black animate-pulse shadow-[0_0_10px_#fbbf24]'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
                title="Left Turn Indicator [Q]"
              >
                <span>⬅</span>
                <span className="text-[9px] sm:text-[10px] hidden xs:inline">Q</span>
              </button>

              <div className="flex items-center gap-0.5 sm:gap-1 font-bold text-xs sm:text-sm bg-slate-900 px-1.5 sm:px-2 py-0.5 rounded border border-slate-800">
                <span className={telemetry.gear === 'R' ? 'text-amber-400 font-black' : 'text-slate-600'}>R</span>
                <span className={telemetry.gear === 'N' ? 'text-sky-400 font-black' : 'text-slate-600'}>N</span>
                <span className={telemetry.gear === 'D' ? 'text-emerald-400 font-black' : 'text-slate-600'}>D</span>
              </div>

              <button
                onClick={() => onToggleBlinker?.('right')}
                className={`px-1.5 sm:px-2 py-0.5 rounded text-[10px] sm:text-xs font-bold transition flex items-center gap-0.5 sm:gap-1 ${
                  blinkerState === 'right'
                    ? 'bg-amber-400 text-slate-950 font-black animate-pulse shadow-[0_0_10px_#fbbf24]'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
                title="Right Turn Indicator [E]"
              >
                <span className="text-[9px] sm:text-[10px] hidden xs:inline">E</span>
                <span>➡</span>
              </button>
            </div>

            <div className="flex items-center gap-1 sm:gap-1.5 text-amber-400">
              <Flame size={12} className="sm:w-3.5 sm:h-3.5" />
              <span className="hidden sm:inline">FUEL</span>
              <div className="w-10 sm:w-14 md:w-16 bg-slate-800 h-1.5 sm:h-2 rounded-full overflow-hidden">
                <div
                  className="bg-amber-500 h-full transition-all"
                  style={{ width: `${telemetry.fuelPercent}%` }}
                />
              </div>
            </div>
          </div>

          {/* Digital Speedometer & Speed Limit Road Sign */}
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="flex items-baseline gap-0.5 sm:gap-1">
              <span className="text-3xl sm:text-4xl md:text-5xl font-black font-mono tracking-tighter text-white">
                {telemetry.speedKmh}
              </span>
              <span className="text-[10px] sm:text-xs font-bold text-slate-400">KM/H</span>
            </div>

            {/* Circular Indian Speed Limit Sign (IRC Standard) */}
            <div
              className={`w-8 h-8 sm:w-10 sm:h-10 md:w-11 md:h-11 rounded-full border-2 sm:border-[3px] md:border-4 flex flex-col items-center justify-center font-black shadow-lg shrink-0 transition-all ${
                telemetry.speedKmh > (telemetry.speedLimitKmh || 50)
                  ? 'bg-rose-950 border-rose-500 text-rose-300 animate-pulse shadow-[0_0_12px_#ef4444]'
                  : 'bg-white border-rose-600 text-slate-950'
              }`}
              title={`Speed Limit: ${telemetry.speedLimitKmh || 50} km/h`}
            >
              <span className="text-[6px] sm:text-[8px] md:text-[9px] leading-tight font-extrabold uppercase">LIMIT</span>
              <span className="text-[10px] sm:text-xs md:text-sm leading-none font-black">{telemetry.speedLimitKmh || 50}</span>
            </div>
          </div>

          {/* Steering Angle Bar */}
          <div className="w-20 sm:w-28 md:w-36 h-1.5 bg-slate-800 rounded-full mt-1 overflow-hidden relative">
            <div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-slate-600 -translate-x-1/2" />
            <div
              className="absolute top-0 bottom-0 bg-emerald-400 transition-all duration-75 rounded-full"
              style={{
                left: telemetry.steering < 0 ? `${50 + (telemetry.steering / 0.6) * 50}%` : '50%',
                width: `${Math.min(50, Math.abs(telemetry.steering / 0.6) * 50)}%`
              }}
            />
          </div>

          <div className="text-[9px] sm:text-[10px] md:text-[11px] font-mono text-slate-400 mt-1">
            RPM: <span className="text-sky-400">{telemetry.rpm}</span> • SCORE: <span className="text-emerald-400">{telemetry.score}</span>
          </div>
        </div>

        {/* Right Touch Controls: Pedals (Accelerate, Brake, Handbrake) */}
        <div className="flex flex-col gap-1.5 sm:gap-2 shrink-0">
          <div className="flex items-end gap-1.5 sm:gap-2">
            {/* Brake / Reverse Pedal */}
            <button
              onPointerDown={(e) => {
                e.preventDefault();
                (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
                onPedalPress(-1);
              }}
              onPointerUp={(e) => {
                e.preventDefault();
                try { (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId); } catch {}
                onPedalPress(0);
              }}
              onPointerCancel={(e) => {
                e.preventDefault();
                try { (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId); } catch {}
                onPedalPress(0);
              }}
              onContextMenu={(e) => e.preventDefault()}
              className="w-13 h-16 sm:w-16 sm:h-20 md:w-20 md:h-24 rounded-2xl bg-gradient-to-t from-rose-950 to-rose-900 border-2 border-rose-700 active:border-rose-400 text-rose-200 font-bold flex flex-col items-center justify-center shadow-2xl active:scale-95 transition touch-none select-none"
              title="Brake / Reverse [S]"
            >
              <span className="text-lg sm:text-xl">🛑</span>
              <span className="text-[9px] sm:text-[11px] font-mono mt-1">BRAKE</span>
            </button>

            {/* Gas / Accelerator Pedal */}
            <button
              onPointerDown={(e) => {
                e.preventDefault();
                (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
                onPedalPress(1);
              }}
              onPointerUp={(e) => {
                e.preventDefault();
                try { (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId); } catch {}
                onPedalPress(0);
              }}
              onPointerCancel={(e) => {
                e.preventDefault();
                try { (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId); } catch {}
                onPedalPress(0);
              }}
              onContextMenu={(e) => e.preventDefault()}
              className="w-13 h-20 sm:w-16 sm:h-24 md:w-20 md:h-28 rounded-2xl bg-gradient-to-t from-emerald-950 to-emerald-900 border-2 border-emerald-700 active:border-emerald-400 text-emerald-200 font-bold flex flex-col items-center justify-center shadow-2xl active:scale-95 transition touch-none select-none"
              title="Drive / Gas [W]"
            >
              <span className="text-lg sm:text-xl">⚡</span>
              <span className="text-[9px] sm:text-[11px] font-mono mt-1">DRIVE</span>
            </button>
          </div>

          <button
            onPointerDown={(e) => {
              e.preventDefault();
              (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
              onHandbrakePress(true);
            }}
            onPointerUp={(e) => {
              e.preventDefault();
              try { (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId); } catch {}
              onHandbrakePress(false);
            }}
            onPointerCancel={(e) => {
              e.preventDefault();
              try { (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId); } catch {}
              onHandbrakePress(false);
            }}
            onContextMenu={(e) => e.preventDefault()}
            className={`w-full py-1.5 sm:py-2 rounded-xl text-[10px] sm:text-xs font-bold border transition touch-none select-none ${
              telemetry.isHandbrake
                ? 'bg-red-600 text-white border-red-500 shadow-lg'
                : 'bg-slate-900/80 text-slate-300 border-slate-700'
            }`}
          >
            HANDBRAKE [SPACE]
          </button>
        </div>
      </div>
    </div>
  );
};
