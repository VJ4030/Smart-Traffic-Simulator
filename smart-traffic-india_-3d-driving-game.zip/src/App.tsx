import React, { useEffect, useRef, useState, useCallback } from 'react';
import { GameEngine } from './game/gameEngine';
import { buildIndianCity } from './game/environment';
import { VEHICLE_CATALOG } from './game/vehicleModels';
import { CAREER_MISSIONS } from './game/missions';
import { soundManager } from './audio/soundManager';
import {
  CameraMode,
  DrivingTelemetry,
  GameMode,
  Mission,
  PlayerStats,
  VehicleId
} from './types/game';
import { HUD } from './components/HUD';
import { MainMenu } from './components/MainMenu';
import { GarageView } from './components/GarageView';
import { CareerSelect } from './components/CareerSelect';
import { HowToPlay } from './components/HowToPlay';
import { CppSourceViewer } from './components/CppSourceViewer';
import { PauseModal } from './components/PauseModal';
import { GameOverModal } from './components/GameOverModal';
import { MissionSuccessModal } from './components/MissionSuccessModal';

const STATS_STORAGE_KEY = 'smart_traffic_india_stats_v1';

const INITIAL_STATS: PlayerStats = {
  cash: 2500,
  highScore: 0,
  unlockedVehicles: ['hatchback'],
  selectedVehicle: 'hatchback',
  completedMissions: [],
  customColors: {
    hatchback: '#0284c7',
    sedan: '#e11d48',
    suv: '#15803d',
    sports_car: '#f59e0b',
    auto_rickshaw: '#16a34a',
    city_bus: '#b91c1c',
    indian_truck: '#ea580c',
    motorcycle: '#475569',
    ambulance: '#ffffff'
  }
};

const DEFAULT_TELEMETRY: DrivingTelemetry = {
  speedKmh: 0,
  rpm: 800,
  gear: 'N',
  throttle: 0,
  steering: 0,
  isBraking: false,
  isHandbrake: false,
  headlightsOn: true,
  fuelPercent: 100,
  collisions: 0,
  redLightViolations: 0,
  score: 0,
  cashEarned: 0,
  distanceTravelledMeters: 0,
  healthPercent: 100
};

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);

  const [gameMode, setGameMode] = useState<GameMode>('menu');
  const [currentMission, setCurrentMission] = useState<Mission | null>(null);
  const [telemetry, setTelemetry] = useState<DrivingTelemetry>(DEFAULT_TELEMETRY);
  const [cameraMode, setCameraMode] = useState<CameraMode>('chase');
  const [playerPos, setPlayerPos] = useState({ x: 0, z: 0, angle: 0 });
  const [gameOverReason, setGameOverReason] = useState<string>('');
  const [hazardAlert, setHazardAlert] = useState<{ message: string; type: 'warning' | 'danger' | 'info' } | null>(null);
  const [blinkerState, setBlinkerState] = useState<'off' | 'left' | 'right'>('off');

  // Load stats from localStorage
  const [stats, setStats] = useState<PlayerStats>(() => {
    try {
      const saved = localStorage.getItem(STATS_STORAGE_KEY);
      if (saved) {
        return { ...INITIAL_STATS, ...JSON.parse(saved) };
      }
    } catch {
      // Ignore
    }
    return INITIAL_STATS;
  });

  // Save stats on update
  useEffect(() => {
    try {
      localStorage.setItem(STATS_STORAGE_KEY, JSON.stringify(stats));
    } catch {
      // Ignore
    }
  }, [stats]);

  // Keys tracking for WASD / Arrow input
  const keysDownRef = useRef<Record<string, boolean>>({});

  const updateEngineInput = useCallback(() => {
    if (!engineRef.current || gameMode !== 'playing') return;
    const keys = keysDownRef.current;

    let throttle = 0;
    if (keys['KeyW'] || keys['ArrowUp']) throttle += 1;
    if (keys['KeyS'] || keys['ArrowDown']) throttle -= 1;

    let steer = 0;
    // Standard Driving: KeyA/Left = Steer Left (-), KeyD/Right = Steer Right (+)
    if (keys['KeyA'] || keys['ArrowLeft']) steer -= 1;
    if (keys['KeyD'] || keys['ArrowRight']) steer += 1;

    const handbrake = !!keys['Space'];

    engineRef.current.setInput(throttle, steer, handbrake);
  }, [gameMode]);

  // Initialize Game Engine on Canvas mount
  useEffect(() => {
    if (!canvasRef.current) return;

    const cityEnv = buildIndianCity();

    const engine = new GameEngine({
      canvas: canvasRef.current,
      onTelemetryUpdate: (t) => {
        setTelemetry(t);
        if (engineRef.current) {
          setPlayerPos(engineRef.current.getPlayerPosition());
        }
      },
      onMissionComplete: (success, reason) => {
        if (success) {
          setGameMode('mission_success');
          // Award rewards
          if (currentMission) {
            setStats(prev => {
              const completed = prev.completedMissions.includes(currentMission.id)
                ? prev.completedMissions
                : [...prev.completedMissions, currentMission.id];
              return {
                ...prev,
                cash: prev.cash + currentMission.rewardCash,
                highScore: Math.max(prev.highScore, telemetry.score + currentMission.rewardScore),
                completedMissions: completed
              };
            });
          }
        } else {
          setGameOverReason(reason || 'Mission failed.');
          setGameMode('game_over');
        }
      },
      onHazardAlert: (msg, type) => {
        setHazardAlert({ message: msg, type });
        setTimeout(() => setHazardAlert(null), 3000);
      }
    });

    engine.initEnvironment(cityEnv);

    // Initial vehicle setup
    const initialVeh = VEHICLE_CATALOG.find(v => v.id === stats.selectedVehicle) || VEHICLE_CATALOG[0];
    engine.setPlayerVehicle(initialVeh, stats.customColors[initialVeh.id]);

    engineRef.current = engine;
    engine.start();

    return () => {
      engine.destroy();
      engineRef.current = null;
    };
  }, []);

  // Keyboard Event Handlers
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Audio auto-resume on first interaction
      soundManager.startEngine();

      if (e.code === 'KeyP' || e.code === 'Escape') {
        if (gameMode === 'playing') {
          setGameMode('pause');
          return;
        } else if (gameMode === 'pause') {
          setGameMode('playing');
          return;
        }
      }

      if (gameMode === 'playing') {
        if (e.code === 'KeyC') {
          cycleCamera();
          return;
        }
        if (e.code === 'KeyH') {
          engineRef.current?.honk();
          return;
        }
        if (e.code === 'KeyL') {
          engineRef.current?.toggleHeadlights();
          return;
        }
        if (e.code === 'KeyQ') {
          const next = engineRef.current?.toggleBlinker('left') || 'off';
          setBlinkerState(next);
          return;
        }
        if (e.code === 'KeyE') {
          const next = engineRef.current?.toggleBlinker('right') || 'off';
          setBlinkerState(next);
          return;
        }
      }

      keysDownRef.current[e.code] = true;
      updateEngineInput();
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      keysDownRef.current[e.code] = false;
      updateEngineInput();
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [gameMode, updateEngineInput]);

  // Update selected vehicle in 3D engine when changed in garage
  const handleSelectVehicle = (id: VehicleId) => {
    setStats(prev => ({ ...prev, selectedVehicle: id }));
    const veh = VEHICLE_CATALOG.find(v => v.id === id);
    if (veh && engineRef.current) {
      engineRef.current.setPlayerVehicle(veh, stats.customColors[id]);
    }
  };

  const handleBuyVehicle = (id: VehicleId, price: number) => {
    if (stats.cash >= price) {
      setStats(prev => ({
        ...prev,
        cash: prev.cash - price,
        unlockedVehicles: [...prev.unlockedVehicles, id],
        selectedVehicle: id
      }));
      const veh = VEHICLE_CATALOG.find(v => v.id === id);
      if (veh && engineRef.current) {
        engineRef.current.setPlayerVehicle(veh, stats.customColors[id]);
      }
    }
  };

  const handleColorChange = (id: VehicleId, hex: string) => {
    setStats(prev => ({
      ...prev,
      customColors: { ...prev.customColors, [id]: hex }
    }));
    const veh = VEHICLE_CATALOG.find(v => v.id === id);
    if (veh && engineRef.current) {
      engineRef.current.setPlayerVehicle(veh, hex);
    }
  };

  const cycleCamera = () => {
    const modes: CameraMode[] = ['chase', 'close_chase', 'hood', 'top_down'];
    const nextIdx = (modes.indexOf(cameraMode) + 1) % modes.length;
    const nextMode = modes[nextIdx];
    setCameraMode(nextMode);
    engineRef.current?.setCameraMode(nextMode);
  };

  const getMissionStartPos = (mission: Mission | null) => {
    if (!mission) return { x: -4.5, z: -40, angle: 0 };
    switch (mission.id) {
      case 2:
        return { x: -50, z: 4.5, angle: Math.PI / 2 }; // Eastbound on left lane
      case 6:
        return { x: 4.5, z: 40, angle: Math.PI }; // Southbound on left lane
      default:
        return { x: -4.5, z: -40, angle: 0 }; // Northbound on left lane
    }
  };

  const startMission = (mission: Mission) => {
    setCurrentMission(mission);
    setGameMode('playing');
    engineRef.current?.startMission(mission, getMissionStartPos(mission));
  };

  const startFreeDrive = () => {
    setCurrentMission(null);
    setGameMode('playing');
    engineRef.current?.startMission(null, getMissionStartPos(null));
  };

  const restartCurrent = () => {
    setGameMode('playing');
    if (currentMission) {
      engineRef.current?.startMission(currentMission, getMissionStartPos(currentMission));
    } else {
      engineRef.current?.startMission(null, getMissionStartPos(null));
    }
  };

  const nextMission = () => {
    if (!currentMission) {
      setGameMode('career_select');
      return;
    }
    const nextIdx = currentMission.id; // next index in CAREER_MISSIONS (id is 1-indexed)
    if (nextIdx < CAREER_MISSIONS.length) {
      startMission(CAREER_MISSIONS[nextIdx]);
    } else {
      setGameMode('career_select');
    }
  };

  // Touch control handlers
  const handlePedalPress = (throttle: number) => {
    if (throttle > 0) {
      keysDownRef.current['KeyW'] = true;
      keysDownRef.current['KeyS'] = false;
    } else if (throttle < 0) {
      keysDownRef.current['KeyS'] = true;
      keysDownRef.current['KeyW'] = false;
    } else {
      keysDownRef.current['KeyW'] = false;
      keysDownRef.current['KeyS'] = false;
    }
    updateEngineInput();
  };

  const handleSteerPress = (steer: number) => {
    if (steer < 0) {
      // Steer Left
      keysDownRef.current['KeyA'] = true;
      keysDownRef.current['KeyD'] = false;
    } else if (steer > 0) {
      // Steer Right
      keysDownRef.current['KeyD'] = true;
      keysDownRef.current['KeyA'] = false;
    } else {
      keysDownRef.current['KeyA'] = false;
      keysDownRef.current['KeyD'] = false;
    }
    updateEngineInput();
  };

  const handleHandbrakePress = (active: boolean) => {
    keysDownRef.current['Space'] = active;
    updateEngineInput();
  };

  return (
    <div className="fixed inset-0 w-full h-full overflow-hidden bg-slate-950 font-sans select-none touch-none">
      {/* 3D WebGL Canvas */}
      <canvas ref={canvasRef} className="w-full h-full block cursor-grab active:cursor-grabbing touch-none select-none" />

      {/* In-Game HUD overlay */}
      {gameMode === 'playing' && (
        <HUD
          telemetry={telemetry}
          mission={currentMission}
          cameraMode={cameraMode}
          onCameraChange={cycleCamera}
          onHeadlightsToggle={() => engineRef.current?.toggleHeadlights()}
          onHonk={() => engineRef.current?.honk()}
          onPause={() => setGameMode('pause')}
          onRestart={restartCurrent}
          playerPos={playerPos}
          signals={engineRef.current ? engineRef.current.getSignals() : []}
          onPedalPress={handlePedalPress}
          onSteerPress={handleSteerPress}
          onHandbrakePress={handleHandbrakePress}
          hazardAlert={hazardAlert}
          onToggleBlinker={(dir) => {
            const next = engineRef.current?.toggleBlinker(dir) || 'off';
            setBlinkerState(next);
          }}
          blinkerState={blinkerState}
        />
      )}

      {/* Menus and Modals */}
      {gameMode === 'menu' && (
        <MainMenu
          stats={stats}
          onStartCareer={() => setGameMode('career_select')}
          onStartFreeDrive={startFreeDrive}
          onOpenGarage={() => setGameMode('garage')}
          onOpenHowToPlay={() => setGameMode('how_to_play')}
          onOpenCppCode={() => setGameMode('cpp_code')}
        />
      )}

      {gameMode === 'career_select' && (
        <CareerSelect
          stats={stats}
          onSelectMission={startMission}
          onBack={() => setGameMode('menu')}
        />
      )}

      {gameMode === 'garage' && (
        <GarageView
          stats={stats}
          onSelectVehicle={handleSelectVehicle}
          onBuyVehicle={handleBuyVehicle}
          onColorChange={handleColorChange}
          onBack={() => setGameMode('menu')}
        />
      )}

      {gameMode === 'how_to_play' && (
        <HowToPlay onBack={() => setGameMode('menu')} />
      )}

      {gameMode === 'cpp_code' && (
        <CppSourceViewer onBack={() => setGameMode('menu')} />
      )}

      {gameMode === 'pause' && (
        <PauseModal
          onResume={() => setGameMode('playing')}
          onRestart={restartCurrent}
          onMenu={() => setGameMode('menu')}
        />
      )}

      {gameMode === 'game_over' && (
        <GameOverModal
          reason={gameOverReason}
          onRestart={restartCurrent}
          onMenu={() => setGameMode('menu')}
        />
      )}

      {gameMode === 'mission_success' && (
        <MissionSuccessModal
          mission={currentMission}
          score={telemetry.score}
          cashEarned={currentMission ? currentMission.rewardCash : 0}
          onNextMission={nextMission}
          onRestart={restartCurrent}
          onMenu={() => setGameMode('menu')}
        />
      )}
    </div>
  );
}
