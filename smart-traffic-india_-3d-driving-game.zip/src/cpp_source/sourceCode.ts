export interface CppFileItem {
  filename: string;
  category: 'Source' | 'Header' | 'Project Config' | 'Documentation';
  content: string;
}

export const CPP_SOURCE_FILES: CppFileItem[] = [
  {
    filename: 'main.cpp',
    category: 'Source',
    content: `/**
 * ============================================================================
 * SMART TRAFFIC INDIA: 3D REALISTIC DRIVING SIMULATOR
 * Modern C++ / OpenGL / FreeGLUT x64 Application
 * 
 * Features:
 *  - 9 Distinct Indian Vehicle Models (No box cars)
 *  - Continuous multi-lane Indian road grid & 4-way intersections
 *  - Functional 3-state traffic signals (Red, Yellow, Green)
 *  - Dynamic AI traffic with distance sensors & lane discipline
 *  - Potholes, speed breakers, sacred cows, and zebra crossings
 *  - 3rd-person chase, close-chase, and hood camera modes
 *  - Career mission progression & Free Drive modes
 * ============================================================================
 */

#include <GL/freeglut.h>
#include <iostream>
#include <chrono>
#include "Game.h"

// Global Game Instance
Game* g_game = nullptr;

// High-resolution timer for frame-rate independent delta time
auto g_lastFrameTime = std::chrono::high_resolution_clock::now();

void displayCallback() {
    if (g_game) {
        g_game->render();
    }
}

void reshapeCallback(int width, int height) {
    if (g_game) {
        g_game->onWindowResize(width, height);
    }
}

void timerCallback(int value) {
    auto currentFrameTime = std::chrono::high_resolution_clock::now();
    std::chrono::duration<float> elapsed = currentFrameTime - g_lastFrameTime;
    g_lastFrameTime = currentFrameTime;

    float dt = elapsed.count();
    // Clamp delta time to prevent physics explosions on pause/lag
    if (dt > 0.1f) dt = 0.1f;

    if (g_game) {
        g_game->update(dt);
    }

    glutPostRedisplay();
    glutTimerFunc(16, timerCallback, 0); // ~60 FPS target
}

void keyDownCallback(unsigned char key, int x, int y) {
    if (g_game) {
        g_game->onKeyDown(key, x, y);
    }
}

void keyUpCallback(unsigned char key, int x, int y) {
    if (g_game) {
        g_game->onKeyUp(key, x, y);
    }
}

void specialKeyDownCallback(int key, int x, int y) {
    if (g_game) {
        g_game->onSpecialKeyDown(key, x, y);
    }
}

void specialKeyUpCallback(int key, int x, int y) {
    if (g_game) {
        g_game->onSpecialKeyUp(key, x, y);
    }
}

int main(int argc, char** argv) {
    std::cout << "========================================================\\n";
    std::cout << "       SMART TRAFFIC INDIA: 3D DRIVING GAME             \\n";
    std::cout << "      OpenGL / FreeGLUT x64 Simulation Architecture    \\n";
    std::cout << "========================================================\\n";

    // Initialize GLUT
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(1280, 720);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Smart Traffic India - 3D Realistic Driving Simulator");

    // Initialize Game Engine
    g_game = new Game(1280, 720);
    g_game->initOpenGL();

    // Register GLUT Callbacks
    glutDisplayFunc(displayCallback);
    glutReshapeFunc(reshapeCallback);
    glutKeyboardFunc(keyDownCallback);
    glutKeyboardUpFunc(keyUpCallback);
    glutSpecialFunc(specialKeyDownCallback);
    glutSpecialUpFunc(specialKeyUpCallback);
    glutTimerFunc(16, timerCallback, 0);

    // Enter GLUT Main Event Loop
    glutMainLoop();

    delete g_game;
    return 0;
}
`
  },
  {
    filename: 'Game.h',
    category: 'Header',
    content: `#pragma once
#include <vector>
#include <string>
#include "Vehicle.h"
#include "World.h"
#include "Camera.h"

enum class GameState {
    MENU,
    CAREER_SELECT,
    PLAYING,
    GARAGE,
    PAUSED,
    MISSION_SUCCESS,
    GAME_OVER
};

struct MissionData {
    int id;
    std::string title;
    std::string description;
    float timeLimit;
    float targetX;
    float targetZ;
    int rewardCash;
    int maxCollisions;
};

class Game {
public:
    Game(int windowWidth, int windowHeight);
    ~Game();

    void initOpenGL();
    void update(float dt);
    void render();
    void onWindowResize(int width, int height);

    void onKeyDown(unsigned char key, int x, int y);
    void onKeyUp(unsigned char key, int x, int y);
    void onSpecialKeyDown(int key, int x, int y);
    void onSpecialKeyUp(int key, int x, int y);

    void startMission(int missionId);
    void startFreeDrive();

private:
    int m_windowWidth;
    int m_windowHeight;
    GameState m_state;

    World m_world;
    Vehicle m_playerVehicle;
    Camera m_camera;

    std::vector<Vehicle> m_aiVehicles;
    std::vector<MissionData> m_missions;
    int m_currentMissionIndex;
    float m_missionTimer;

    // Player Stats
    int m_cash;
    int m_score;
    float m_fuel;
    float m_vehicleHealth;
    int m_collisionsCount;
    int m_redLightViolations;

    // Input States
    bool m_keyUp;
    bool m_keyDown;
    bool m_keyLeft;
    bool m_keyRight;
    bool m_keyHandbrake;
    bool m_headlightsOn;

    // HUD & Notifications
    std::string m_activeNotification;
    float m_notificationTimer;

    void updatePhysics(float dt);
    void updateAITraffic(float dt);
    void checkCollisionsAndRules();
    void renderHUD();
    void renderText2D(float x, float y, const std::string& text, float r, float g, float b);
    void showNotification(const std::string& msg, float duration = 2.5f);
};
`
  },
  {
    filename: 'Game.cpp',
    category: 'Source',
    content: `#include "Game.h"
#include <GL/freeglut.h>
#include <cmath>
#include <sstream>
#include <iomanip>

Game::Game(int windowWidth, int windowHeight)
    : m_windowWidth(windowWidth),
      m_windowHeight(windowHeight),
      m_state(GameState::PLAYING),
      m_playerVehicle(VehicleType::HATCHBACK, 0.0f, -40.0f, 0.0f, true),
      m_camera(),
      m_currentMissionIndex(0),
      m_missionTimer(90.0f),
      m_cash(2500),
      m_score(0),
      m_fuel(100.0f),
      m_vehicleHealth(100.0f),
      m_collisionsCount(0),
      m_redLightViolations(0),
      m_keyUp(false),
      m_keyDown(false),
      m_keyLeft(false),
      m_keyRight(false),
      m_keyHandbrake(false),
      m_headlightsOn(true),
      m_notificationTimer(0.0f)
{
    // Initialize Career Missions
    m_missions.push_back({1, "Morning Commute", "Reach Connaught Place without breaking traffic rules.", 90.0f, 0.0f, 140.0f, 1200, 2});
    m_missions.push_back({2, "Chandni Chowk Rush", "Navigate through heavy auto-rickshaw traffic.", 75.0f, 140.0f, 0.0f, 1800, 1});
    m_missions.push_back({3, "Emergency 108 Run", "Fast escort to City Civil Hospital under time limit.", 60.0f, 140.0f, -140.0f, 3000, 3});

    // Populate AI traffic vehicles
    m_world.spawnTraffic(m_aiVehicles, 24);
}

Game::~Game() {}

void Game::initOpenGL() {
    glClearColor(0.53f, 0.81f, 0.92f, 1.0f); // Indian sky blue
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glShadeModel(GL_SMOOTH);

    // Setup Lighting
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_COLOR_MATERIAL);
    glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);

    GLfloat lightPos[] = { 100.0f, 180.0f, 80.0f, 1.0f };
    GLfloat lightAmbient[] = { 0.35f, 0.35f, 0.35f, 1.0f };
    GLfloat lightDiffuse[] = { 0.95f, 0.9f, 0.85f, 1.0f };
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
    glLightfv(GL_LIGHT0, GL_AMBIENT, lightAmbient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, lightDiffuse);
}

void Game::onWindowResize(int width, int height) {
    m_windowWidth = width;
    m_windowHeight = (height <= 0) ? 1 : height;
    glViewport(0, 0, m_windowWidth, m_windowHeight);
}

void Game::update(float dt) {
    if (m_state != GameState::PLAYING) return;

    if (m_notificationTimer > 0.0f) {
        m_notificationTimer -= dt;
    }

    if (m_missionTimer > 0.0f) {
        m_missionTimer -= dt;
        if (m_missionTimer <= 0.0f) {
            m_state = GameState::GAME_OVER;
            showNotification("Time Up! Destination not reached.");
        }
    }

    updatePhysics(dt);
    updateAITraffic(dt);
    m_world.update(dt);
    checkCollisionsAndRules();

    // Camera follow player
    m_camera.update(m_playerVehicle.getX(), m_playerVehicle.getY(), m_playerVehicle.getZ(),
                    m_playerVehicle.getHeading(), dt);
}

void Game::updatePhysics(float dt) {
    float throttle = 0.0f;
    float steer = 0.0f;

    if (m_keyUp) throttle += 1.0f;
    if (m_keyDown) throttle -= 1.0f;
    if (m_keyLeft) steer -= 1.0f;
    if (m_keyRight) steer += 1.0f;

    m_playerVehicle.applyInput(throttle, steer, m_keyHandbrake, dt);

    // Fuel burn
    if (std::abs(m_playerVehicle.getSpeed()) > 0.5f) {
        m_fuel = std::max(0.0f, m_fuel - 0.2f * dt);
    }
}

void Game::updateAITraffic(float dt) {
    for (auto& ai : m_aiVehicles) {
        ai.updateAI(m_playerVehicle, m_aiVehicles, m_world.getSignals(), dt);
    }
}

void Game::checkCollisionsAndRules() {
    float px = m_playerVehicle.getX();
    float pz = m_playerVehicle.getZ();

    // Check collision with AI vehicles
    for (auto& ai : m_aiVehicles) {
        float dx = px - ai.getX();
        float dz = pz - ai.getZ();
        float dist = std::sqrt(dx * dx + dz * dz);
        if (dist < 3.2f) {
            m_collisionsCount++;
            m_vehicleHealth = std::max(0.0f, m_vehicleHealth - 15.0f);
            m_playerVehicle.setSpeed(-m_playerVehicle.getSpeed() * 0.3f);
            showNotification("Collision Alert! Vehicle Damaged (-15% HP)");

            if (m_vehicleHealth <= 0.0f) {
                m_state = GameState::GAME_OVER;
            }
        }
    }

    // Check Traffic Signals
    for (const auto& sig : m_world.getSignals()) {
        float dist = std::hypot(px - sig.x, pz - sig.z);
        if (dist < 10.0f && sig.state == SignalState::RED && m_playerVehicle.getSpeed() > 3.0f) {
            m_redLightViolations++;
            m_score = std::max(0, m_score - 100);
            showNotification("Traffic Violation! Red Light Jumped (-100 Score)");
        }
    }

    // Check Mission Destination
    if (m_currentMissionIndex < (int)m_missions.size()) {
        const auto& mission = m_missions[m_currentMissionIndex];
        float distToTarget = std::hypot(px - mission.targetX, pz - mission.targetZ);
        if (distToTarget < 6.0f && m_playerVehicle.getSpeed() < 3.0f) {
            m_cash += mission.rewardCash;
            m_score += 500;
            m_state = GameState::MISSION_SUCCESS;
            showNotification("Mission Complete! Earned Rs. " + std::to_string(mission.rewardCash));
        }
    }
}

void Game::render() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // 3D Perspective Projection
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60.0, (double)m_windowWidth / (double)m_windowHeight, 0.5, 500.0);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    m_camera.apply();

    // Render World & Roads
    m_world.render();

    // Render AI Traffic
    for (const auto& ai : m_aiVehicles) {
        ai.render();
    }

    // Render Player Vehicle
    m_playerVehicle.render();

    // Render 2D Gameplay HUD
    renderHUD();

    glutSwapBuffers();
}

void Game::renderText2D(float x, float y, const std::string& text, float r, float g, float b) {
    glColor3f(r, g, b);
    glRasterPos2f(x, y);
    for (char c : text) {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, c);
    }
}

void Game::renderHUD() {
    glDisable(GL_LIGHTING);
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0, m_windowWidth, 0, m_windowHeight);

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();

    // Top Header Banner
    std::stringstream ss;
    ss << "SMART TRAFFIC INDIA | SPEED: " << (int)(std::abs(m_playerVehicle.getSpeed()) * 3.6f) << " KM/H";
    ss << " | CASH: Rs. " << m_cash << " | HP: " << (int)m_vehicleHealth << "%";
    renderText2D(30, m_windowHeight - 40, ss.str(), 1.0f, 0.9f, 0.2f);

    // Mission Timer & Objective
    if (m_currentMissionIndex < (int)m_missions.size()) {
        std::stringstream ms;
        ms << "MISSION: " << m_missions[m_currentMissionIndex].title << " | TIME: " << (int)m_missionTimer << "s";
        renderText2D(30, m_windowHeight - 70, ms.str(), 0.3f, 1.0f, 0.3f);
    }

    // Active Road Notification
    if (m_notificationTimer > 0.0f) {
        renderText2D(m_windowWidth / 2 - 180, m_windowHeight - 120, m_activeNotification, 1.0f, 0.2f, 0.2f);
    }

    // Controls Legend at bottom
    renderText2D(30, 25, "[W/UP] Accelerate | [S/DOWN] Brake/Reverse | [A/D] Steer | [SPACE] Handbrake | [C] Camera | [H] Horn", 0.9f, 0.9f, 0.9f);

    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glEnable(GL_LIGHTING);
}

void Game::showNotification(const std::string& msg, float duration) {
    m_activeNotification = msg;
    m_notificationTimer = duration;
}

void Game::onKeyDown(unsigned char key, int x, int y) {
    switch (key) {
        case 'w': case 'W': m_keyUp = true; break;
        case 's': case 'S': m_keyDown = true; break;
        case 'a': case 'A': m_keyLeft = true; break;
        case 'd': case 'D': m_keyRight = true; break;
        case ' ': m_keyHandbrake = true; break;
        case 'c': case 'C': m_camera.toggleMode(); break;
        case 'h': case 'H': showNotification("*HONK HONK!* (Indian Electric Horn)"); break;
        case 'l': case 'L': m_headlightsOn = !m_headlightsOn; break;
        case 27: exit(0); break; // ESC
    }
}

void Game::onKeyUp(unsigned char key, int x, int y) {
    switch (key) {
        case 'w': case 'W': m_keyUp = false; break;
        case 's': case 'S': m_keyDown = false; break;
        case 'a': case 'A': m_keyLeft = false; break;
        case 'd': case 'D': m_keyRight = false; break;
        case ' ': m_keyHandbrake = false; break;
    }
}

void Game::onSpecialKeyDown(int key, int x, int y) {
    switch (key) {
        case GLUT_KEY_UP: m_keyUp = true; break;
        case GLUT_KEY_DOWN: m_keyDown = true; break;
        case GLUT_KEY_LEFT: m_keyLeft = true; break;
        case GLUT_KEY_RIGHT: m_keyRight = true; break;
    }
}

void Game::onSpecialKeyUp(int key, int x, int y) {
    switch (key) {
        case GLUT_KEY_UP: m_keyUp = false; break;
        case GLUT_KEY_DOWN: m_keyDown = false; break;
        case GLUT_KEY_LEFT: m_keyLeft = false; break;
        case GLUT_KEY_RIGHT: m_keyRight = false; break;
    }
}
`
  },
  {
    filename: 'Vehicle.h',
    category: 'Header',
    content: `#pragma once
#include <vector>
#include <string>

enum class VehicleType {
    HATCHBACK,
    SEDAN,
    SUV,
    SPORTS_CAR,
    AUTO_RICKSHAW,
    CITY_BUS,
    INDIAN_TRUCK,
    MOTORCYCLE,
    AMBULANCE
};

class Vehicle {
public:
    Vehicle(VehicleType type, float x, float z, float heading, bool isPlayer = false);
    ~Vehicle();

    void applyInput(float throttle, float steer, bool handbrake, float dt);
    void updateAI(const Vehicle& player, const std::vector<Vehicle>& others, const std::vector<struct TrafficSignalData>& signals, float dt);
    void render() const;

    float getX() const { return m_x; }
    float getY() const { return m_y; }
    float getZ() const { return m_z; }
    float getHeading() const { return m_heading; }
    float getSpeed() const { return m_speed; }
    void setSpeed(float s) { m_speed = s; }

private:
    VehicleType m_type;
    bool m_isPlayer;

    float m_x, m_y, m_z;
    float m_speed;
    float m_heading;
    float m_steerAngle;

    float m_maxSpeed;
    float m_accel;
    float m_brake;
    float m_length;
    float m_width;

    float m_colorR, m_colorG, m_colorB;

    // Geometric Drawing Helpers (Distinct Low-Poly Indian Vehicles)
    void drawBox(float w, float h, float d) const;
    void drawWheel(float radius, float width) const;
    void renderAutoRickshaw() const;
    void renderIndianTruck() const;
    void renderCityBus() const;
    void renderSedan() const;
    void renderHatchback() const;
    void renderSUV() const;
    void renderSportsCar() const;
    void renderMotorcycle() const;
    void renderAmbulance() const;
};
`
  },
  {
    filename: 'Vehicle.cpp',
    category: 'Source',
    content: `#include "Vehicle.h"
#include "World.h"
#include <GL/freeglut.h>
#include <cmath>

Vehicle::Vehicle(VehicleType type, float x, float z, float heading, bool isPlayer)
    : m_type(type),
      m_isPlayer(isPlayer),
      m_x(x),
      m_y(0.0f),
      m_z(z),
      m_speed(0.0f),
      m_heading(heading),
      m_steerAngle(0.0f)
{
    // Configure Vehicle Characteristics & Dimensions
    switch (type) {
        case VehicleType::AUTO_RICKSHAW:
            m_maxSpeed = 16.0f; // ~58 km/h
            m_accel = 10.0f;
            m_brake = 18.0f;
            m_length = 2.6f;
            m_width = 1.3f;
            m_colorR = 0.1f; m_colorG = 0.65f; m_colorB = 0.2f; // Green
            break;
        case VehicleType::INDIAN_TRUCK:
            m_maxSpeed = 18.0f; // ~65 km/h
            m_accel = 6.0f;
            m_brake = 14.0f;
            m_length = 8.8f;
            m_width = 2.4f;
            m_colorR = 0.95f; m_colorG = 0.45f; m_colorB = 0.1f; // Saffron Orange
            break;
        case VehicleType::CITY_BUS:
            m_maxSpeed = 20.0f;
            m_accel = 7.0f;
            m_brake = 15.0f;
            m_length = 9.5f;
            m_width = 2.5f;
            m_colorR = 0.8f; m_colorG = 0.15f; m_colorB = 0.15f; // DTC Red
            break;
        case VehicleType::AMBULANCE:
            m_maxSpeed = 35.0f;
            m_accel = 15.0f;
            m_brake = 25.0f;
            m_length = 4.8f;
            m_width = 1.85f;
            m_colorR = 0.95f; m_colorG = 0.95f; m_colorB = 0.95f; // White
            break;
        case VehicleType::SPORTS_CAR:
            m_maxSpeed = 50.0f; // 180 km/h
            m_accel = 22.0f;
            m_brake = 30.0f;
            m_length = 4.5f;
            m_width = 1.9f;
            m_colorR = 0.95f; m_colorG = 0.75f; m_colorB = 0.1f; // Yellow Gold
            break;
        default: // HATCHBACK, SEDAN, SUV
            m_maxSpeed = 32.0f;
            m_accel = 13.0f;
            m_brake = 22.0f;
            m_length = 4.2f;
            m_width = 1.75f;
            m_colorR = 0.15f; m_colorG = 0.45f; m_colorB = 0.85f;
            break;
    }
}

Vehicle::~Vehicle() {}

void Vehicle::applyInput(float throttle, float steer, bool handbrake, float dt) {
    // Steering dynamics
    float targetSteer = steer * 0.6f;
    m_steerAngle += (targetSteer - m_steerAngle) * 5.0f * dt;

    if (throttle > 0.0f) {
        m_speed += throttle * m_accel * dt;
    } else if (throttle < 0.0f) {
        m_speed += throttle * m_brake * dt;
    } else {
        // Natural friction
        if (m_speed > 0.0f) m_speed = std::max(0.0f, m_speed - 3.0f * dt);
        if (m_speed < 0.0f) m_speed = std::min(0.0f, m_speed + 3.0f * dt);
    }

    if (handbrake) {
        m_speed *= std::max(0.0f, 1.0f - 8.0f * dt);
    }

    // Heading update
    if (std::abs(m_speed) > 0.1f) {
        m_heading += (m_speed / m_length) * std::tan(m_steerAngle) * dt;
    }

    // Integrate Position
    m_x += std::sin(m_heading) * m_speed * dt;
    m_z += std::cos(m_heading) * m_speed * dt;
}

void Vehicle::updateAI(const Vehicle& player, const std::vector<Vehicle>& others,
                      const std::vector<TrafficSignalData>& signals, float dt) {
    bool shouldBrake = false;

    // Check distance to player
    float dxP = player.getX() - m_x;
    float dzP = player.getZ() - m_z;
    if (std::hypot(dxP, dzP) < 10.0f) {
        shouldBrake = true;
    }

    // Check distance to other AI vehicles ahead
    for (const auto& other : others) {
        if (&other == this) continue;
        float dx = other.getX() - m_x;
        float dz = other.getZ() - m_z;
        float dist = std::hypot(dx, dz);
        if (dist < 12.0f && dz > 0) {
            shouldBrake = true;
            break;
        }
    }

    // Check Traffic Signals ahead
    for (const auto& sig : signals) {
        float dist = std::hypot(sig.x - m_x, sig.z - m_z);
        if (dist < 15.0f && dist > 2.0f && sig.state == SignalState::RED) {
            shouldBrake = true;
            break;
        }
    }

    if (shouldBrake) {
        m_speed = std::max(0.0f, m_speed - 12.0f * dt);
    } else {
        float targetCruising = m_maxSpeed * 0.7f;
        m_speed += (targetCruising - m_speed) * 2.0f * dt;
    }

    // Lane following along Z or X
    m_z += std::cos(m_heading) * m_speed * dt;
    m_x += std::sin(m_heading) * m_speed * dt;

    // City wrap-around
    if (m_z > 350.0f) m_z = -350.0f;
    if (m_z < -350.0f) m_z = 350.0f;
    if (m_x > 350.0f) m_x = -350.0f;
    if (m_x < -350.0f) m_x = 350.0f;
}

void Vehicle::drawBox(float w, float h, float d) const {
    glPushMatrix();
    glScalef(w, h, d);
    glutSolidCube(1.0);
    glPopMatrix();
}

void Vehicle::drawWheel(float radius, float width) const {
    glPushMatrix();
    glColor3f(0.12f, 0.12f, 0.12f);
    glutSolidCylinder(radius, width, 12, 1);
    glPopMatrix();
}

void Vehicle::renderAutoRickshaw() const {
    // Green Lower Hull
    glColor3f(0.1f, 0.65f, 0.2f);
    glPushMatrix();
    glTranslatef(0, 0.5f, 0);
    drawBox(1.3f, 0.6f, 2.5f);
    glPopMatrix();

    // Yellow Canopy Roof
    glColor3f(0.95f, 0.8f, 0.1f);
    glPushMatrix();
    glTranslatef(0, 1.45f, 0);
    drawBox(1.25f, 0.15f, 2.3f);
    glPopMatrix();

    // Front Windshield
    glColor3f(0.2f, 0.3f, 0.4f);
    glPushMatrix();
    glTranslatef(0, 1.15f, 0.95f);
    drawBox(1.15f, 0.55f, 0.05f);
    glPopMatrix();
}

void Vehicle::renderIndianTruck() const {
    // Cabin
    glColor3f(0.95f, 0.45f, 0.1f);
    glPushMatrix();
    glTranslatef(0, 1.4f, 2.8f);
    drawBox(2.35f, 1.8f, 2.4f);
    glPopMatrix();

    // Roof Crown / Visor
    glColor3f(0.95f, 0.85f, 0.1f);
    glPushMatrix();
    glTranslatef(0, 2.4f, 3.1f);
    drawBox(2.5f, 0.4f, 0.6f);
    glPopMatrix();

    // Wooden Cargo Deck
    glColor3f(0.1f, 0.4f, 0.75f);
    glPushMatrix();
    glTranslatef(0, 1.5f, -1.3f);
    drawBox(2.4f, 1.8f, 5.8f);
    glPopMatrix();
}

void Vehicle::renderCityBus() const {
    glColor3f(0.85f, 0.15f, 0.15f); // DTC Bus Red
    glPushMatrix();
    glTranslatef(0, 1.5f, 0);
    drawBox(2.5f, 2.4f, 9.4f);
    glPopMatrix();

    // Windows
    glColor3f(0.2f, 0.3f, 0.45f);
    glPushMatrix();
    glTranslatef(0, 1.7f, 0);
    drawBox(2.52f, 0.8f, 8.4f);
    glPopMatrix();
}

void Vehicle::renderSedan() const {
    glColor3f(m_colorR, m_colorG, m_colorB);
    glPushMatrix();
    glTranslatef(0, 0.5f, 0);
    drawBox(1.7f, 0.6f, 4.3f); // Lower body
    glPopMatrix();

    // Cabin
    glPushMatrix();
    glTranslatef(0, 1.05f, -0.15f);
    drawBox(1.48f, 0.55f, 2.2f);
    glPopMatrix();
}

void Vehicle::render() const {
    glPushMatrix();
    glTranslatef(m_x, m_y, m_z);
    glRotatef(m_heading * 180.0f / 3.14159f, 0, 1, 0);

    switch (m_type) {
        case VehicleType::AUTO_RICKSHAW: renderAutoRickshaw(); break;
        case VehicleType::INDIAN_TRUCK:  renderIndianTruck(); break;
        case VehicleType::CITY_BUS:      renderCityBus(); break;
        default:                         renderSedan(); break;
    }

    glPopMatrix();
}
`
  },
  {
    filename: 'World.h',
    category: 'Header',
    content: `#pragma once
#include <vector>

enum class SignalState {
    GREEN,
    YELLOW,
    RED
};

struct TrafficSignalData {
    float x;
    float z;
    SignalState state;
    float timer;
};

class World {
public:
    World();
    ~World();

    void update(float dt);
    void render() const;
    void spawnTraffic(std::vector<class Vehicle>& aiVehicles, int count);
    const std::vector<TrafficSignalData>& getSignals() const { return m_signals; }

private:
    std::vector<TrafficSignalData> m_signals;

    void renderRoadGrid() const;
    void renderBuildings() const;
    void renderHazards() const;
    void renderSignals() const;
};
`
  },
  {
    filename: 'World.cpp',
    category: 'Source',
    content: `#include "World.h"
#include "Vehicle.h"
#include <GL/freeglut.h>
#include <cmath>

World::World() {
    // Initialize 4-way Intersection Traffic Signals
    m_signals.push_back({ 10.0f, 10.0f, SignalState::GREEN, 0.0f });
    m_signals.push_back({ -10.0f, -10.0f, SignalState::GREEN, 0.0f });
    m_signals.push_back({ 10.0f, -10.0f, SignalState::RED, 15.0f });
    m_signals.push_back({ -10.0f, 10.0f, SignalState::RED, 15.0f });
}

World::~World() {}

void World::update(float dt) {
    for (auto& sig : m_signals) {
        sig.timer += dt;
        float cycle = std::fmod(sig.timer, 30.0f);
        if (cycle < 13.0f) {
            sig.state = SignalState::GREEN;
        } else if (cycle < 16.0f) {
            sig.state = SignalState::YELLOW;
        } else {
            sig.state = SignalState::RED;
        }
    }
}

void World::spawnTraffic(std::vector<Vehicle>& aiVehicles, int count) {
    aiVehicles.clear();
    VehicleType types[] = {
        VehicleType::AUTO_RICKSHAW,
        VehicleType::INDIAN_TRUCK,
        VehicleType::CITY_BUS,
        VehicleType::SEDAN,
        VehicleType::HATCHBACK,
        VehicleType::SUV
    };

    for (int i = 0; i < count; i++) {
        VehicleType t = types[i % 6];
        float laneX = (i % 2 == 0) ? 4.5f : -4.5f;
        float z = -250.0f + i * 25.0f;
        aiVehicles.emplace_back(t, laneX, z, 0.0f, false);
    }
}

void World::render() const {
    renderRoadGrid();
    renderBuildings();
    renderHazards();
    renderSignals();
}

void World::renderRoadGrid() const {
    // Ground
    glColor3f(0.58f, 0.64f, 0.72f);
    glBegin(GL_QUADS);
    glNormal3f(0, 1, 0);
    glVertex3f(-500.0f, 0.0f, -500.0f);
    glVertex3f(-500.0f, 0.0f, 500.0f);
    glVertex3f(500.0f, 0.0f, 500.0f);
    glVertex3f(500.0f, 0.0f, -500.0f);
    glEnd();

    // Asphalt Main Roads
    glColor3f(0.15f, 0.15f, 0.17f);
    glBegin(GL_QUADS);
    glNormal3f(0, 1, 0);
    glVertex3f(-9.0f, 0.02f, -500.0f);
    glVertex3f(-9.0f, 0.02f, 500.0f);
    glVertex3f(9.0f, 0.02f, 500.0f);
    glVertex3f(9.0f, 0.02f, -500.0f);

    glVertex3f(-500.0f, 0.02f, -9.0f);
    glVertex3f(-500.0f, 0.02f, 9.0f);
    glVertex3f(500.0f, 0.02f, 9.0f);
    glVertex3f(500.0f, 0.02f, -9.0f);
    glEnd();

    // Center Yellow Dividers
    glColor3f(0.98f, 0.8f, 0.1f);
    glLineWidth(3.0f);
    glBegin(GL_LINES);
    glVertex3f(0.0f, 0.03f, -500.0f);
    glVertex3f(0.0f, 0.03f, 500.0f);
    glVertex3f(-500.0f, 0.03f, 0.0f);
    glVertex3f(500.0f, 0.03f, 0.0f);
    glEnd();
}

void World::renderBuildings() const {
    // City Block Buildings
    for (int bx = -1; bx <= 1; bx += 2) {
        for (int bz = -1; bz <= 1; bz += 2) {
            glPushMatrix();
            glTranslatef(bx * 70.0f, 15.0f, bz * 70.0f);
            glColor3f(0.85f, 0.88f, 0.92f);
            glScalef(60.0f, 30.0f, 60.0f);
            glutSolidCube(1.0);
            glPopMatrix();
        }
    }
}

void World::renderHazards() const {
    // Indian Speed Breaker
    glColor3f(0.95f, 0.8f, 0.1f);
    glPushMatrix();
    glTranslatef(0.0f, 0.08f, 50.0f);
    glScalef(18.0f, 0.2f, 1.4f);
    glutSolidCube(1.0);
    glPopMatrix();

    // Pothole
    glColor3f(0.05f, 0.05f, 0.05f);
    glPushMatrix();
    glTranslatef(4.5f, 0.04f, -70.0f);
    glScalef(2.5f, 0.05f, 2.5f);
    glutSolidCube(1.0);
    glPopMatrix();
}

void World::renderSignals() const {
    for (const auto& sig : m_signals) {
        glPushMatrix();
        glTranslatef(sig.x, 0.0f, sig.z);

        // Pole
        glColor3f(0.28f, 0.33f, 0.41f);
        glPushMatrix();
        glTranslatef(0, 2.5f, 0);
        glScalef(0.3f, 5.0f, 0.3f);
        glutSolidCube(1.0);
        glPopMatrix();

        // Signal Light Box
        glColor3f(0.1f, 0.1f, 0.12f);
        glPushMatrix();
        glTranslatef(0, 4.5f, 0);
        glScalef(0.8f, 1.8f, 0.6f);
        glutSolidCube(1.0);
        glPopMatrix();

        // Active Light Bulb
        if (sig.state == SignalState::RED) glColor3f(1.0f, 0.0f, 0.0f);
        else if (sig.state == SignalState::YELLOW) glColor3f(1.0f, 0.85f, 0.0f);
        else glColor3f(0.0f, 1.0f, 0.0f);

        glPushMatrix();
        glTranslatef(0, 4.5f, 0.35f);
        glutSolidSphere(0.25, 10, 10);
        glPopMatrix();

        glPopMatrix();
    }
}
`
  },
  {
    filename: 'Camera.h',
    category: 'Header',
    content: `#pragma once
#include <GL/freeglut.h>
#include <cmath>

enum class CameraView {
    CHASE,
    CLOSE_CHASE,
    HOOD
};

class Camera {
public:
    Camera()
        : m_view(CameraView::CHASE),
          m_posX(0.0f), m_posY(3.5f), m_posZ(-8.0f),
          m_targetX(0.0f), m_targetY(1.0f), m_targetZ(0.0f) {}

    void toggleMode() {
        if (m_view == CameraView::CHASE) m_view = CameraView::CLOSE_CHASE;
        else if (m_view == CameraView::CLOSE_CHASE) m_view = CameraView::HOOD;
        else m_view = CameraView::CHASE;
    }

    void update(float targetX, float targetY, float targetZ, float heading, float dt) {
        float fwdX = std::sin(heading);
        float fwdZ = std::cos(heading);

        float desiredPosX = 0.0f;
        float desiredPosY = 0.0f;
        float desiredPosZ = 0.0f;

        switch (m_view) {
            case CameraView::CHASE:
                desiredPosX = targetX - fwdX * 7.5f;
                desiredPosY = targetY + 3.2f;
                desiredPosZ = targetZ - fwdZ * 7.5f;
                m_targetX = targetX + fwdX * 5.0f;
                m_targetY = targetY + 1.2f;
                m_targetZ = targetZ + fwdZ * 5.0f;
                break;
            case CameraView::CLOSE_CHASE:
                desiredPosX = targetX - fwdX * 4.8f;
                desiredPosY = targetY + 2.0f;
                desiredPosZ = targetZ - fwdZ * 4.8f;
                m_targetX = targetX + fwdX * 6.0f;
                m_targetY = targetY + 1.0f;
                m_targetZ = targetZ + fwdZ * 6.0f;
                break;
            case CameraView::HOOD:
                desiredPosX = targetX + fwdX * 1.5f;
                desiredPosY = targetY + 1.1f;
                desiredPosZ = targetZ + fwdZ * 1.5f;
                m_targetX = targetX + fwdX * 25.0f;
                m_targetY = targetY + 1.0f;
                m_targetZ = targetZ + fwdZ * 25.0f;
                break;
        }

        // Smooth Camera interpolation
        float smoothFactor = 8.0f * dt;
        if (smoothFactor > 1.0f) smoothFactor = 1.0f;
        m_posX += (desiredPosX - m_posX) * smoothFactor;
        m_posY += (desiredPosY - m_posY) * smoothFactor;
        m_posZ += (desiredPosZ - m_posZ) * smoothFactor;
    }

    void apply() const {
        gluLookAt(m_posX, m_posY, m_posZ,
                  m_targetX, m_targetY, m_targetZ,
                  0.0, 1.0, 0.0);
    }

private:
    CameraView m_view;
    float m_posX, m_posY, m_posZ;
    float m_targetX, m_targetY, m_targetZ;
};
`
  },
  {
    filename: 'CMakeLists.txt',
    category: 'Project Config',
    content: `cmake_minimum_required(VERSION 3.16)
project(SmartTrafficIndia LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Find OpenGL & FreeGLUT
find_package(OpenGL REQUIRED)
find_package(GLUT REQUIRED)

add_executable(SmartTrafficIndia
    main.cpp
    Game.h
    Game.cpp
    Vehicle.h
    Vehicle.cpp
    World.h
    World.cpp
    Camera.h
)

target_link_libraries(SmartTrafficIndia
    PRIVATE
    OpenGL::GL
    GLUT::GLUT
)
`
  },
  {
    filename: 'SmartTrafficIndia.vcxproj',
    category: 'Project Config',
    content: `<?xml version="1.0" encoding="utf-8"?>
<Project DefaultTargets="Build" xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
  <ItemGroup Label="ProjectConfigurations">
    <ProjectConfiguration Include="Debug|x64">
      <Configuration>Debug</Configuration>
      <Platform>x64</Platform>
    </ProjectConfiguration>
    <ProjectConfiguration Include="Release|x64">
      <Configuration>Release</Configuration>
      <Platform>x64</Platform>
    </ProjectConfiguration>
  </ItemGroup>
  <PropertyGroup Label="Globals">
    <VCProjectVersion>17.0</VCProjectVersion>
    <ProjectGuid>{A1B2C3D4-E5F6-7890-ABCD-EF1234567890}</ProjectGuid>
    <Keyword>Win32Proj</Keyword>
    <RootNamespace>SmartTrafficIndia</RootNamespace>
    <WindowsTargetPlatformVersion>10.0</WindowsTargetPlatformVersion>
  </PropertyGroup>
  <Import Project="$(VCTargetsPath)\\Microsoft.Cpp.Default.props" />
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Release|x64'" Label="Configuration">
    <ConfigurationType>Application</ConfigurationType>
    <UseDebugLibraries>false</UseDebugLibraries>
    <PlatformToolset>v143</PlatformToolset>
    <WholeProgramOptimization>true</WholeProgramOptimization>
    <CharacterSet>Unicode</CharacterSet>
  </PropertyGroup>
  <Import Project="$(VCTargetsPath)\\Microsoft.Cpp.props" />
  <ItemDefinitionGroup Condition="'$(Configuration)|$(Platform)'=='Release|x64'">
    <ClCompile>
      <WarningLevel>Level3</WarningLevel>
      <FunctionLevelLinking>true</FunctionLevelLinking>
      <IntrinsicFunctions>true</IntrinsicFunctions>
      <SDLCheck>true</SDLCheck>
      <PreprocessorDefinitions>NDEBUG;_CONSOLE;%(PreprocessorDefinitions)</PreprocessorDefinitions>
      <ConformanceMode>true</ConformanceMode>
      <LanguageStandard>stdcpp17</LanguageStandard>
    </ClCompile>
    <Link>
      <SubSystem>Console</SubSystem>
      <EnableCOMDATFolding>true</EnableCOMDATFolding>
      <OptimizeReferences>true</OptimizeReferences>
      <GenerateDebugInformation>true</GenerateDebugInformation>
      <AdditionalDependencies>opengl32.lib;glu32.lib;freeglut.lib;%(AdditionalDependencies)</AdditionalDependencies>
    </Link>
  </ItemDefinitionGroup>
  <ItemGroup>
    <ClCompile Include="main.cpp" />
    <ClCompile Include="Game.cpp" />
    <ClCompile Include="Vehicle.cpp" />
    <ClCompile Include="World.cpp" />
  </ItemGroup>
  <ItemGroup>
    <ClInclude Include="Game.h" />
    <ClInclude Include="Vehicle.h" />
    <ClInclude Include="World.h" />
    <ClInclude Include="Camera.h" />
  </ItemGroup>
  <Import Project="$(VCTargetsPath)\\Microsoft.Cpp.targets" />
</Project>
`
  },
  {
    filename: 'README_SETUP.md',
    category: 'Documentation',
    content: `# SMART TRAFFIC INDIA — VISUAL STUDIO COMMUNITY SETUP GUIDE (x64)

This document provides step-by-step instructions to compile and run the native C++ / OpenGL / FreeGLUT version of Smart Traffic India in **Visual Studio 2022 Community** on Windows (x64 architecture).

---

## Method 1: Install FreeGLUT via Vcpkg (Recommended & Fastest)

1. Open PowerShell / Command Prompt and run:
   \`\`\`bash
   git clone https://github.com/microsoft/vcpkg.git
   cd vcpkg
   .\\bootstrap-vcpkg.bat
   .\\vcpkg.exe integrate install
   .\\vcpkg.exe install freeglut:x64-windows
   \`\`\`

2. Open \`SmartTrafficIndia.sln\` in Visual Studio 2022.
3. Set Solution Configuration to **Release** and Platform to **x64**.
4. Press **F5** (or Build -> Build Solution).
5. The game compiles and launches with full hardware-accelerated OpenGL!

---

## Method 2: Manual FreeGLUT Setup in Visual Studio

1. Download FreeGLUT Windows binaries from: https://www.transmissionzero.co.uk/software/freeglut-devel/
2. Extract the archive (e.g. to \`C:\\freeglut\`).
3. In Visual Studio -> Right click Project -> **Properties**:
   - Configuration: **All Configurations**, Platform: **x64**
   - **C/C++ -> General -> Additional Include Directories**: Add \`C:\\freeglut\\include\`
   - **Linker -> General -> Additional Library Directories**: Add \`C:\\freeglut\\lib\\x64\`
   - **Linker -> Input -> Additional Dependencies**: Ensure \`freeglut.lib;opengl32.lib;glu32.lib\` are listed.
4. Copy \`freeglut.dll\` from \`C:\\freeglut\\bin\\x64\` into your output executable directory (e.g. \`x64\\Release\`).
5. Run the game!

---

## In-Game Controls
- **W / Up Arrow**: Accelerate
- **S / Down Arrow**: Brake / Reverse
- **A / Left Arrow**: Steer Left
- **D / Right Arrow**: Steer Right
- **Spacebar**: Handbrake
- **C**: Toggle Camera View (Chase -> Close Chase -> Hood)
- **H**: Electric Horn
- **L**: Toggle Headlights
- **ESC**: Exit Game
`
  }
];
