import * as THREE from 'three';
import { VehicleDefinition, VehicleId } from '../types/game';

export const VEHICLE_CATALOG: VehicleDefinition[] = [
  {
    id: 'hatchback',
    name: 'Alto Rider (Hatchback)',
    category: 'City Compact',
    description: 'Agile and economical, ideal for weaving through congested Indian arterial lanes and tight market alleys.',
    price: 0,
    unlocked: true,
    color: '#0284c7', // Sky Blue
    accentColor: '#1e293b',
    topSpeedKmh: 120,
    acceleration: 65,
    handling: 85,
    braking: 75,
    dimensions: { width: 1.6, height: 1.45, length: 3.5 }
  },
  {
    id: 'sedan',
    name: 'City Premier (Sedan)',
    category: 'Executive Sedan',
    description: 'Comfortable family cruiser with stable highway handling and smooth acceleration over flyovers.',
    price: 3500,
    unlocked: false,
    color: '#e11d48', // Crimson Red
    accentColor: '#0f172a',
    topSpeedKmh: 155,
    acceleration: 75,
    handling: 80,
    braking: 82,
    dimensions: { width: 1.75, height: 1.45, length: 4.4 }
  },
  {
    id: 'suv',
    name: 'Scorpio King (SUV)',
    category: 'Rugged SUV',
    description: 'High ground clearance and heavy suspension built to conquer Indian potholes, monsoon waterlogging, and speed bumps.',
    price: 6000,
    unlocked: false,
    color: '#15803d', // Forest Green
    accentColor: '#334155',
    topSpeedKmh: 145,
    acceleration: 70,
    handling: 72,
    braking: 85,
    dimensions: { width: 1.85, height: 1.8, length: 4.5 }
  },
  {
    id: 'sports_car',
    name: 'Formula Raj (Sports GT)',
    category: 'Supercar',
    description: 'Low-slung aerodynamic missile designed for blistering speed along the Yamuna & Bandra-Worli Sea Link Expressways.',
    price: 15000,
    unlocked: false,
    color: '#f59e0b', // Amber Gold
    accentColor: '#111827',
    topSpeedKmh: 210,
    acceleration: 95,
    handling: 90,
    braking: 92,
    dimensions: { width: 1.9, height: 1.25, length: 4.5 }
  },
  {
    id: 'auto_rickshaw',
    name: 'Tuk-Tuk Express (Auto)',
    category: 'Indian Three-Wheeler',
    description: 'The heartbeat of Indian traffic! Unbeatable turning radius, compact footprint, and classic green-and-yellow livery.',
    price: 1500,
    unlocked: false,
    color: '#16a34a', // Indian Auto Green
    accentColor: '#eab308', // Auto Yellow
    topSpeedKmh: 75,
    acceleration: 80,
    handling: 98,
    braking: 70,
    dimensions: { width: 1.3, height: 1.75, length: 2.6 }
  },
  {
    id: 'city_bus',
    name: 'DTC Metro Bus (City Transit)',
    category: 'Heavy Public Transit',
    description: 'Heavy passenger carrier with high momentum. Demands respectful distance, early braking, and wide turning arcs.',
    price: 8500,
    unlocked: false,
    color: '#b91c1c', // DTC Red
    accentColor: '#ffffff',
    topSpeedKmh: 85,
    acceleration: 45,
    handling: 55,
    braking: 65,
    dimensions: { width: 2.5, height: 2.9, length: 9.5 }
  },
  {
    id: 'indian_truck',
    name: 'Desi Lorry (Tata Goods Carrier)',
    category: 'National Highway Truck',
    description: 'Authentic Indian highway truck featuring carved canopy crown, colorful side murals, and legendary "HORN OK PLEASE" tailgate.',
    price: 11000,
    unlocked: false,
    color: '#ea580c', // Bright Saffron
    accentColor: '#0284c7',
    topSpeedKmh: 80,
    acceleration: 42,
    handling: 50,
    braking: 60,
    dimensions: { width: 2.4, height: 3.1, length: 8.8 }
  },
  {
    id: 'motorcycle',
    name: 'Pulsar Bullet (Motorbike)',
    category: 'Two Wheeler',
    description: 'Lightning-fast acceleration and ultra-narrow width for effortless lane filtering between bumper-to-bumper jams.',
    price: 2200,
    unlocked: false,
    color: '#475569', // Slate Gray
    accentColor: '#dc2626',
    topSpeedKmh: 135,
    acceleration: 92,
    handling: 94,
    braking: 72,
    dimensions: { width: 0.8, height: 1.3, length: 2.0 }
  },
  {
    id: 'ambulance',
    name: '108 Jeevan (Ambulance)',
    category: 'Emergency Response',
    description: 'High-priority emergency vehicle with working rooftop red/blue emergency strobe beacons. Sirens clear traffic lanes!',
    price: 4500,
    unlocked: false,
    color: '#ffffff', // Pure White
    accentColor: '#dc2626',
    topSpeedKmh: 150,
    acceleration: 78,
    handling: 78,
    braking: 88,
    dimensions: { width: 1.85, height: 2.2, length: 4.8 }
  }
];

// Reusable shared materials to maximize performance
const MAT_RUBBER = new THREE.MeshLambertMaterial({ color: 0x1f2421 });
const MAT_CHROME = new THREE.MeshStandardMaterial({ color: 0xd1d5db, roughness: 0.2, metalness: 0.8 });
const MAT_GLASS = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.1, metalness: 0.5, transparent: true, opacity: 0.75 });
const MAT_HEADLIGHT = new THREE.MeshBasicMaterial({ color: 0xffffff });
const MAT_TAILLIGHT = new THREE.MeshBasicMaterial({ color: 0xef4444 });
const MAT_YELLOW_LIGHT = new THREE.MeshBasicMaterial({ color: 0xf59e0b });
const MAT_BLUE_LIGHT = new THREE.MeshBasicMaterial({ color: 0x2563eb });
const MAT_INTERIOR = new THREE.MeshLambertMaterial({ color: 0x334155 });

function createWheel(radius: number, width: number, name?: string): THREE.Group {
  const wheelGroup = new THREE.Group();
  if (name) wheelGroup.name = name;
  
  // Inner pivot for rolling spin
  const rollGroup = new THREE.Group();
  rollGroup.name = 'roll_group';

  // Tire
  const tireGeo = new THREE.CylinderGeometry(radius, radius, width, 14);
  tireGeo.rotateZ(Math.PI / 2);
  const tire = new THREE.Mesh(tireGeo, MAT_RUBBER);
  tire.castShadow = true;
  rollGroup.add(tire);

  // Rim Hubcap
  const rimGeo = new THREE.CylinderGeometry(radius * 0.6, radius * 0.6, width * 1.05, 10);
  rimGeo.rotateZ(Math.PI / 2);
  const rim = new THREE.Mesh(rimGeo, MAT_CHROME);
  rollGroup.add(rim);

  wheelGroup.add(rollGroup);
  return wheelGroup;
}

/**
 * Procedural low-poly 3D models with distinct silhouettes and features.
 */
export function buildVehicleMesh(id: VehicleId, bodyColorHex: string = '#0284c7'): THREE.Group {
  const root = new THREE.Group();
  root.name = `vehicle_${id}`;

  const bodyMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(bodyColorHex),
    roughness: 0.4,
    metalness: 0.25
  });

  switch (id) {
    case 'hatchback': {
      // Lower body
      const chassisGeo = new THREE.BoxGeometry(1.6, 0.65, 3.4);
      const chassis = new THREE.Mesh(chassisGeo, bodyMat);
      chassis.position.y = 0.55;
      chassis.castShadow = true;
      root.add(chassis);

      // Cabin / Sloping Hatch
      const cabinGeo = new THREE.BoxGeometry(1.4, 0.55, 1.8);
      const cabin = new THREE.Mesh(cabinGeo, bodyMat);
      cabin.position.set(0, 1.05, -0.2);
      root.add(cabin);

      // Windows
      const windshieldGeo = new THREE.BoxGeometry(1.36, 0.48, 1.84);
      const windshield = new THREE.Mesh(windshieldGeo, MAT_GLASS);
      windshield.position.set(0, 1.05, -0.2);
      root.add(windshield);

      // Headlights
      const hlL = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.15, 0.1), MAT_HEADLIGHT);
      hlL.position.set(0.55, 0.6, 1.7);
      const hlR = hlL.clone();
      hlR.position.x = -0.55;
      root.add(hlL, hlR);

      // Taillights
      const tlL = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.15, 0.08), MAT_TAILLIGHT);
      tlL.position.set(0.55, 0.65, -1.7);
      const tlR = tlL.clone();
      tlR.position.x = -0.55;
      root.add(tlL, tlR);

      // 4 Wheels
      const wFL = createWheel(0.3, 0.2, 'wheel_fl');
      wFL.position.set(0.8, 0.3, 1.0);
      const wFR = createWheel(0.3, 0.2, 'wheel_fr');
      wFR.position.set(-0.8, 0.3, 1.0);
      const wRL = createWheel(0.3, 0.2, 'wheel_rl');
      wRL.position.set(0.8, 0.3, -1.0);
      const wRR = createWheel(0.3, 0.2, 'wheel_rr');
      wRR.position.set(-0.8, 0.3, -1.0);
      root.add(wFL, wFR, wRL, wRR);
      break;
    }

    case 'sedan': {
      // Chassis (Three-box silhouette: Bonnet, Cabin, Boot)
      const baseGeo = new THREE.BoxGeometry(1.7, 0.6, 4.3);
      const base = new THREE.Mesh(baseGeo, bodyMat);
      base.position.y = 0.55;
      base.castShadow = true;
      root.add(base);

      // Cabin
      const cabinGeo = new THREE.BoxGeometry(1.48, 0.6, 2.2);
      const cabin = new THREE.Mesh(cabinGeo, bodyMat);
      cabin.position.set(0, 1.1, -0.15);
      root.add(cabin);

      // Windshield and windows
      const glass = new THREE.Mesh(new THREE.BoxGeometry(1.44, 0.52, 2.24), MAT_GLASS);
      glass.position.set(0, 1.1, -0.15);
      root.add(glass);

      // Chrome Front Grille
      const grille = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.22, 0.08), MAT_CHROME);
      grille.position.set(0, 0.5, 2.16);
      root.add(grille);

      // Dual Headlights
      const hlL = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.16, 0.1), MAT_HEADLIGHT);
      hlL.position.set(0.6, 0.55, 2.16);
      const hlR = hlL.clone();
      hlR.position.x = -0.6;
      root.add(hlL, hlR);

      // Taillights
      const tlL = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.15, 0.08), MAT_TAILLIGHT);
      tlL.position.set(0.55, 0.6, -2.16);
      const tlR = tlL.clone();
      tlR.position.x = -0.55;
      root.add(tlL, tlR);

      // Wheels
      const wFL = createWheel(0.32, 0.22, 'wheel_fl');
      wFL.position.set(0.85, 0.32, 1.3);
      const wFR = createWheel(0.32, 0.22, 'wheel_fr');
      wFR.position.set(-0.85, 0.32, 1.3);
      const wRL = createWheel(0.32, 0.22, 'wheel_rl');
      wRL.position.set(0.85, 0.32, -1.3);
      const wRR = createWheel(0.32, 0.22, 'wheel_rr');
      wRR.position.set(-0.85, 0.32, -1.3);
      root.add(wFL, wFR, wRL, wRR);
      break;
    }

    case 'suv': {
      // Tall, rugged chassis
      const baseGeo = new THREE.BoxGeometry(1.85, 0.8, 4.4);
      const base = new THREE.Mesh(baseGeo, bodyMat);
      base.position.y = 0.7;
      base.castShadow = true;
      root.add(base);

      // Tall Cabin
      const cabinGeo = new THREE.BoxGeometry(1.7, 0.75, 2.8);
      const cabin = new THREE.Mesh(cabinGeo, bodyMat);
      cabin.position.set(0, 1.4, -0.4);
      root.add(cabin);

      // Panoramic Windows
      const glass = new THREE.Mesh(new THREE.BoxGeometry(1.66, 0.68, 2.84), MAT_GLASS);
      glass.position.set(0, 1.4, -0.4);
      root.add(glass);

      // Roof Rails
      const railGeo = new THREE.BoxGeometry(0.08, 0.08, 2.4);
      const railL = new THREE.Mesh(railGeo, MAT_CHROME);
      railL.position.set(0.75, 1.82, -0.4);
      const railR = railL.clone();
      railR.position.x = -0.75;
      root.add(railL, railR);

      // Rear Mounted Spare Tire
      const spareWheel = createWheel(0.36, 0.2);
      spareWheel.rotation.y = Math.PI / 2;
      spareWheel.position.set(0, 0.95, -2.25);
      root.add(spareWheel);

      // Headlights & Taillights
      const hlL = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.22, 0.1), MAT_HEADLIGHT);
      hlL.position.set(0.65, 0.8, 2.21);
      const hlR = hlL.clone();
      hlR.position.x = -0.65;
      root.add(hlL, hlR);

      const tlL = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.45, 0.08), MAT_TAILLIGHT);
      tlL.position.set(0.7, 0.95, -2.21);
      const tlR = tlL.clone();
      tlR.position.x = -0.7;
      root.add(tlL, tlR);

      // Big Wheels
      const wFL = createWheel(0.38, 0.25, 'wheel_fl');
      wFL.position.set(0.92, 0.38, 1.3);
      const wFR = createWheel(0.38, 0.25, 'wheel_fr');
      wFR.position.set(-0.92, 0.38, 1.3);
      const wRL = createWheel(0.38, 0.25, 'wheel_rl');
      wRL.position.set(0.92, 0.38, -1.3);
      const wRR = createWheel(0.38, 0.25, 'wheel_rr');
      wRR.position.set(-0.92, 0.38, -1.3);
      root.add(wFL, wFR, wRL, wRR);
      break;
    }

    case 'sports_car': {
      // Low slung aerodynamic wedge
      const baseGeo = new THREE.BoxGeometry(1.9, 0.45, 4.4);
      const base = new THREE.Mesh(baseGeo, bodyMat);
      base.position.y = 0.4;
      base.castShadow = true;
      root.add(base);

      // Sleek Cockpit
      const cockpitGeo = new THREE.BoxGeometry(1.4, 0.42, 1.9);
      const cockpit = new THREE.Mesh(cockpitGeo, bodyMat);
      cockpit.position.set(0, 0.8, -0.2);
      root.add(cockpit);

      // Dark Tint Canopy
      const glass = new THREE.Mesh(new THREE.BoxGeometry(1.36, 0.38, 1.94), MAT_GLASS);
      glass.position.set(0, 0.8, -0.2);
      root.add(glass);

      // Big GT Rear Wing / Spoiler
      const wingBoard = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.06, 0.4), bodyMat);
      wingBoard.position.set(0, 0.95, -2.0);
      const strutL = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.35, 0.08), MAT_CHROME);
      strutL.position.set(0.5, 0.75, -2.0);
      const strutR = strutL.clone();
      strutR.position.x = -0.5;
      root.add(wingBoard, strutL, strutR);

      // Aggressive Angular Headlights
      const hlL = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.12, 0.1), MAT_HEADLIGHT);
      hlL.position.set(0.68, 0.45, 2.2);
      hlL.rotation.z = -0.15;
      const hlR = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.12, 0.1), MAT_HEADLIGHT);
      hlR.position.set(-0.68, 0.45, 2.2);
      hlR.rotation.z = 0.15;
      root.add(hlL, hlR);

      // LED Light bar tail
      const tl = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.1, 0.08), MAT_TAILLIGHT);
      tl.position.set(0, 0.5, -2.2);
      root.add(tl);

      // Wide Low-profile Sports Wheels
      const wFL = createWheel(0.32, 0.26, 'wheel_fl');
      wFL.position.set(0.95, 0.32, 1.35);
      const wFR = createWheel(0.32, 0.26, 'wheel_fr');
      wFR.position.set(-0.95, 0.32, 1.35);
      const wRL = createWheel(0.34, 0.28, 'wheel_rl');
      wRL.position.set(0.96, 0.34, -1.3);
      const wRR = createWheel(0.34, 0.28, 'wheel_rr');
      wRR.position.set(-0.96, 0.34, -1.3);
      root.add(wFL, wFR, wRL, wRR);
      break;
    }

    case 'auto_rickshaw': {
      // Classic Indian Auto Rickshaw: Green Lower Hull + Bright Yellow Roof Canopy
      const hullMat = new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.5 }); // Green
      const roofMat = new THREE.MeshStandardMaterial({ color: 0xfacc15, roughness: 0.6 }); // Yellow

      // Lower Hull
      const hullGeo = new THREE.BoxGeometry(1.3, 0.6, 2.5);
      const hull = new THREE.Mesh(hullGeo, hullMat);
      hull.position.y = 0.55;
      hull.castShadow = true;
      root.add(hull);

      // Curved Yellow Canopy Roof
      const roofGeo = new THREE.BoxGeometry(1.26, 0.15, 2.3);
      const roof = new THREE.Mesh(roofGeo, roofMat);
      roof.position.set(0, 1.6, 0.0);
      root.add(roof);

      // Canopy Pillars (open sides)
      const pillarGeo = new THREE.CylinderGeometry(0.03, 0.03, 0.95, 6);
      const pFL = new THREE.Mesh(pillarGeo, MAT_CHROME);
      pFL.position.set(0.55, 1.1, 0.95);
      const pFR = pFL.clone();
      pFR.position.x = -0.55;
      const pBL = pFL.clone();
      pBL.position.set(0.55, 1.1, -1.05);
      const pBR = pFL.clone();
      pBR.position.set(-0.55, 1.1, -1.05);
      root.add(pFL, pFR, pBL, pBR);

      // Front Windshield Glass
      const frontGlass = new THREE.Mesh(new THREE.BoxGeometry(1.15, 0.65, 0.06), MAT_GLASS);
      frontGlass.position.set(0, 1.25, 0.95);
      root.add(frontGlass);

      // Passenger seat bench inside
      const seat = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.35, 0.6), MAT_INTERIOR);
      seat.position.set(0, 0.8, -0.6);
      root.add(seat);

      // Front Single Headlight
      const hl = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 0.08, 12), MAT_HEADLIGHT);
      hl.rotation.x = Math.PI / 2;
      hl.position.set(0, 0.65, 1.26);
      root.add(hl);

      // Rear tail lamps
      const tlL = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.12, 0.06), MAT_TAILLIGHT);
      tlL.position.set(0.45, 0.6, -1.26);
      const tlR = tlL.clone();
      tlR.position.x = -0.45;
      root.add(tlL, tlR);

      // 3 Wheels: 1 front centered, 2 rear
      const wFront = createWheel(0.25, 0.16, 'wheel_fl');
      wFront.position.set(0, 0.25, 0.95);
      const wRL = createWheel(0.25, 0.16, 'wheel_rl');
      wRL.position.set(0.65, 0.25, -0.75);
      const wRR = createWheel(0.25, 0.16, 'wheel_rr');
      wRR.position.set(-0.65, 0.25, -0.75);
      root.add(wFront, wRL, wRR);
      break;
    }

    case 'city_bus': {
      // Long city bus body
      const busGeo = new THREE.BoxGeometry(2.5, 2.4, 9.4);
      const busBody = new THREE.Mesh(busGeo, bodyMat);
      busBody.position.y = 1.6;
      busBody.castShadow = true;
      root.add(busBody);

      // Long side windows band
      const windowBandL = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.8, 8.4), MAT_GLASS);
      windowBandL.position.set(1.26, 1.8, 0);
      const windowBandR = windowBandL.clone();
      windowBandR.position.x = -1.26;
      root.add(windowBandL, windowBandR);

      // Front Panoramic Windscreen
      const frontGlass = new THREE.Mesh(new THREE.BoxGeometry(2.35, 1.0, 0.08), MAT_GLASS);
      frontGlass.position.set(0, 1.7, 4.71);
      root.add(frontGlass);

      // Destination Board "ROUTE 42: CONNAUGHT PLACE"
      const boardGeo = new THREE.BoxGeometry(1.8, 0.3, 0.1);
      const boardMat = new THREE.MeshBasicMaterial({ color: 0x0284c7 });
      const board = new THREE.Mesh(boardGeo, boardMat);
      board.position.set(0, 2.45, 4.71);
      root.add(board);

      // Dual Passenger Doors
      const doorMat = new THREE.MeshStandardMaterial({ color: 0x334155 });
      const doorF = new THREE.Mesh(new THREE.BoxGeometry(0.08, 1.6, 0.8), doorMat);
      doorF.position.set(1.26, 1.2, 2.8);
      const doorR = doorF.clone();
      doorR.position.z = -2.2;
      root.add(doorF, doorR);

      // Headlights & Tail
      const hlL = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.22, 0.1), MAT_HEADLIGHT);
      hlL.position.set(0.9, 0.7, 4.71);
      const hlR = hlL.clone();
      hlR.position.x = -0.9;
      root.add(hlL, hlR);

      const tlL = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.5, 0.1), MAT_TAILLIGHT);
      tlL.position.set(0.9, 0.9, -4.71);
      const tlR = tlL.clone();
      tlR.position.x = -0.9;
      root.add(tlL, tlR);

      // Heavy 6 Wheels (Twin rear wheels)
      const wFL = createWheel(0.48, 0.32, 'wheel_fl');
      wFL.position.set(1.2, 0.48, 2.8);
      const wFR = createWheel(0.48, 0.32, 'wheel_fr');
      wFR.position.set(-1.2, 0.48, 2.8);
      const wRL1 = createWheel(0.48, 0.32, 'wheel_rl');
      wRL1.position.set(1.2, 0.48, -2.6);
      const wRR1 = createWheel(0.48, 0.32, 'wheel_rr');
      wRR1.position.set(-1.2, 0.48, -2.6);
      root.add(wFL, wFR, wRL1, wRR1);
      break;
    }

    case 'indian_truck': {
      // Classic Indian Tata Goods Carrier
      // 1. Driver Cabin
      const cabGeo = new THREE.BoxGeometry(2.35, 1.8, 2.4);
      const cab = new THREE.Mesh(cabGeo, bodyMat);
      cab.position.set(0, 1.5, 2.8);
      cab.castShadow = true;
      root.add(cab);

      // Traditional Carved Roof Crown / Visor
      const visorGeo = new THREE.BoxGeometry(2.5, 0.4, 0.6);
      const visorMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b });
      const visor = new THREE.Mesh(visorGeo, visorMat);
      visor.position.set(0, 2.5, 3.1);
      root.add(visor);

      // Windscreen
      const cabGlass = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.7, 0.08), MAT_GLASS);
      cabGlass.position.set(0, 1.7, 4.01);
      root.add(cabGlass);

      // Heavy Chrome Bumper with Indian hanging tassels
      const bumper = new THREE.Mesh(new THREE.BoxGeometry(2.5, 0.35, 0.35), MAT_CHROME);
      bumper.position.set(0, 0.55, 4.1);
      root.add(bumper);

      // 2. High Wooden Cargo Body with side railings
      const cargoMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.7 });
      const cargoGeo = new THREE.BoxGeometry(2.4, 1.8, 5.8);
      const cargo = new THREE.Mesh(cargoGeo, cargoMat);
      cargo.position.set(0, 1.6, -1.3);
      cargo.castShadow = true;
      root.add(cargo);

      // Tailgate Signboard "HORN OK PLEASE"
      const tailCanvas = document.createElement('canvas');
      tailCanvas.width = 256;
      tailCanvas.height = 128;
      const ctx = tailCanvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#f59e0b';
        ctx.fillRect(0, 0, 256, 128);
        ctx.fillStyle = '#b91c1c';
        ctx.font = 'bold 26px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('HORN OK PLEASE', 128, 50);
        ctx.fillStyle = '#0f172a';
        ctx.font = 'bold 16px sans-serif';
        ctx.fillText('GOODS CARRIER • ALL INDIA', 128, 88);
      }
      const tailTexture = new THREE.CanvasTexture(tailCanvas);
      const tailSign = new THREE.Mesh(
        new THREE.BoxGeometry(2.2, 0.9, 0.06),
        new THREE.MeshBasicMaterial({ map: tailTexture })
      );
      tailSign.position.set(0, 1.4, -4.22);
      root.add(tailSign);

      // Tall vertical exhaust pipe
      const exhaustGeo = new THREE.CylinderGeometry(0.08, 0.08, 2.2, 8);
      const exhaust = new THREE.Mesh(exhaustGeo, MAT_CHROME);
      exhaust.position.set(1.15, 2.2, 1.5);
      root.add(exhaust);

      // Headlights & Tail
      const hlL = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 0.1, 10), MAT_HEADLIGHT);
      hlL.rotation.x = Math.PI / 2;
      hlL.position.set(0.85, 0.7, 4.02);
      const hlR = hlL.clone();
      hlR.position.x = -0.85;
      root.add(hlL, hlR);

      // Heavy 6 Wheels
      const wFL = createWheel(0.5, 0.35, 'wheel_fl');
      wFL.position.set(1.2, 0.5, 2.6);
      const wFR = createWheel(0.5, 0.35, 'wheel_fr');
      wFR.position.set(-1.2, 0.5, 2.6);
      const wRL1 = createWheel(0.5, 0.35, 'wheel_rl');
      wRL1.position.set(1.2, 0.5, -2.4);
      const wRR1 = createWheel(0.5, 0.35, 'wheel_rr');
      wRR1.position.set(-1.2, 0.5, -2.4);
      root.add(wFL, wFR, wRL1, wRR1);
      break;
    }

    case 'motorcycle': {
      // Sleek Indian street motorcycle (e.g. Pulsar / Bullet)
      const frameGeo = new THREE.BoxGeometry(0.25, 0.4, 1.6);
      const frameMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.7 });
      const frame = new THREE.Mesh(frameGeo, frameMat);
      frame.position.y = 0.65;
      root.add(frame);

      // Teardrop Fuel Tank
      const tankGeo = new THREE.BoxGeometry(0.38, 0.3, 0.6);
      const tank = new THREE.Mesh(tankGeo, bodyMat);
      tank.position.set(0, 0.9, 0.25);
      root.add(tank);

      // Seat
      const seatGeo = new THREE.BoxGeometry(0.3, 0.14, 0.7);
      const seat = new THREE.Mesh(seatGeo, MAT_INTERIOR);
      seat.position.set(0, 0.85, -0.35);
      root.add(seat);

      // Handlebars
      const handleGeo = new THREE.CylinderGeometry(0.025, 0.025, 0.75, 6);
      handleGeo.rotateZ(Math.PI / 2);
      const handlebar = new THREE.Mesh(handleGeo, MAT_CHROME);
      handlebar.position.set(0, 1.15, 0.55);
      root.add(handlebar);

      // Front Headlight
      const hl = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.08, 10), MAT_HEADLIGHT);
      hl.rotation.x = Math.PI / 2;
      hl.position.set(0, 1.0, 0.85);
      root.add(hl);

      // Rider Model (Helmet + Torso + Arms)
      const helmet = new THREE.Mesh(new THREE.SphereGeometry(0.18, 8, 8), new THREE.MeshStandardMaterial({ color: 0xdc2626 }));
      helmet.position.set(0, 1.45, -0.1);
      const torso = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.42, 0.28), new THREE.MeshStandardMaterial({ color: 0x2563eb }));
      torso.position.set(0, 1.15, -0.15);
      root.add(helmet, torso);

      // 2 Slim Wheels
      const wF = createWheel(0.35, 0.12, 'wheel_fl');
      wF.position.set(0, 0.35, 0.8);
      const wR = createWheel(0.35, 0.12, 'wheel_rl');
      wR.position.set(0, 0.35, -0.75);
      root.add(wF, wR);
      break;
    }

    case 'ambulance': {
      // 108 Jeevan Emergency Ambulance Van
      const whiteMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.3 });
      const redCrossMat = new THREE.MeshStandardMaterial({ color: 0xdc2626 });

      // Van Body
      const bodyGeo = new THREE.BoxGeometry(1.85, 1.4, 4.6);
      const body = new THREE.Mesh(bodyGeo, whiteMat);
      body.position.y = 1.1;
      body.castShadow = true;
      root.add(body);

      // Windscreen
      const glassGeo = new THREE.BoxGeometry(1.7, 0.65, 0.08);
      const glass = new THREE.Mesh(glassGeo, MAT_GLASS);
      glass.position.set(0, 1.35, 2.31);
      root.add(glass);

      // Red Cross Symbol on sides
      const crossH = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.2, 0.8), redCrossMat);
      crossH.position.set(0.93, 1.2, -0.2);
      const crossV = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.6, 0.25), redCrossMat);
      crossV.position.set(0.93, 1.2, -0.2);
      const crossHL = crossH.clone();
      crossHL.position.x = -0.93;
      const crossVL = crossV.clone();
      crossVL.position.x = -0.93;
      root.add(crossH, crossV, crossHL, crossVL);

      // Emergency Rooftop Beacon Light Bar (Flashing Red / Blue)
      const barBase = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.12, 0.25), MAT_CHROME);
      barBase.position.set(0, 1.86, 0.5);
      const beaconRed = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.18, 0.2), MAT_TAILLIGHT);
      beaconRed.name = 'beacon_red';
      beaconRed.position.set(0.3, 2.0, 0.5);
      const beaconBlue = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.18, 0.2), MAT_BLUE_LIGHT);
      beaconBlue.name = 'beacon_blue';
      beaconBlue.position.set(-0.3, 2.0, 0.5);
      root.add(barBase, beaconRed, beaconBlue);

      // Headlights & Tail
      const hlL = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.2, 0.08), MAT_HEADLIGHT);
      hlL.position.set(0.65, 0.7, 2.31);
      const hlR = hlL.clone();
      hlR.position.x = -0.65;
      root.add(hlL, hlR);

      const tlL = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.4, 0.08), MAT_TAILLIGHT);
      tlL.position.set(0.65, 0.85, -2.31);
      const tlR = tlL.clone();
      tlR.position.x = -0.65;
      root.add(tlL, tlR);

      // 4 Wheels
      const wFL = createWheel(0.36, 0.24, 'wheel_fl');
      wFL.position.set(0.9, 0.36, 1.35);
      const wFR = createWheel(0.36, 0.24, 'wheel_fr');
      wFR.position.set(-0.9, 0.36, 1.35);
      const wRL = createWheel(0.36, 0.24, 'wheel_rl');
      wRL.position.set(0.9, 0.36, -1.35);
      const wRR = createWheel(0.36, 0.24, 'wheel_rr');
      wRR.position.set(-0.9, 0.36, -1.35);
      root.add(wFL, wFR, wRL, wRR);
      break;
    }
  }

  return root;
}
