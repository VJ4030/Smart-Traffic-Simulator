import * as THREE from 'three';
import { HazardObject, SignalState, TimeOfDay, TrafficSignal } from '../types/game';

export interface CityEnvironment {
  sceneGroup: THREE.Group;
  signals: TrafficSignal[];
  signalMeshes: Map<string, { red: THREE.Mesh; yellow: THREE.Mesh; green: THREE.Mesh }>;
  hazards: HazardObject[];
  hazardMeshes: Map<string, THREE.Group>;
  ambientLight: THREE.AmbientLight;
  sunLight: THREE.DirectionalLight;
  streetLights: THREE.PointLight[];
  updateSignals: (dt: number) => void;
  updateHazards: (dt: number) => void;
  setTimeOfDay: (time: TimeOfDay) => void;
}

export const ROAD_WIDTH = 18;      // 4 lanes total (2 each direction, 4.5m per lane)
export const BLOCK_SIZE = 140;     // Distance between intersection centers
export const CITY_GRID_EXTENT = 2; // -2 to +2 blocks (5x5 grid = 700m x 700m playable city)

export function buildIndianCity(): CityEnvironment {
  const sceneGroup = new THREE.Group();
  sceneGroup.name = 'city_environment';

  // --- Lighting Setup ---
  const ambientLight = new THREE.AmbientLight(0xffffff, 0.75);
  sceneGroup.add(ambientLight);

  const sunLight = new THREE.DirectionalLight(0xfff5e6, 1.2);
  sunLight.position.set(80, 140, 60);
  sunLight.castShadow = true;
  sunLight.shadow.mapSize.width = 1024;
  sunLight.shadow.mapSize.height = 1024;
  sunLight.shadow.camera.near = 10;
  sunLight.shadow.camera.far = 400;
  const d = 160;
  sunLight.shadow.camera.left = -d;
  sunLight.shadow.camera.right = d;
  sunLight.shadow.camera.top = d;
  sunLight.shadow.camera.bottom = -d;
  sceneGroup.add(sunLight);

  const streetLights: THREE.PointLight[] = [];

  // Ground plane (Indian sandy/urban ground)
  const groundGeo = new THREE.PlaneGeometry(1000, 1000);
  const groundMat = new THREE.MeshLambertMaterial({ color: 0x94a3b8 });
  const ground = new THREE.Mesh(groundGeo, groundMat);
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -0.05;
  ground.receiveShadow = true;
  sceneGroup.add(ground);

  // Reusable Materials
  const asphaltMat = new THREE.MeshStandardMaterial({ color: 0x27272a, roughness: 0.85 });
  const sidewalkMat = new THREE.MeshStandardMaterial({ color: 0xa1a1aa, roughness: 0.7 });
  const whitePaintMat = new THREE.MeshBasicMaterial({ color: 0xf8fafc });
  const yellowPaintMat = new THREE.MeshBasicMaterial({ color: 0xfacc15 });
  const curbDividerMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.6 });
  const grassMat = new THREE.MeshLambertMaterial({ color: 0x4d7c0f });

  // Indian Shop Names & Banners
  const SHOP_NAMES = [
    { title: 'SHARMA SWEETS & CHAT', sub: 'Pure Desi Ghee Sweets', color: '#b91c1c' },
    { title: 'CHAI POINT & SNACKS', sub: 'Special Masala Chai & Samosa', color: '#ea580c' },
    { title: 'APNA TYRE & PUNCTURE', sub: '24x7 Wheel Balancing', color: '#0f766e' },
    { title: 'SHREE MEDICAL STORES', sub: 'Allopathic & Ayurvedic', color: '#16a34a' },
    { title: 'DELHI CYBER CAFE', sub: 'Printouts & Govt Forms', color: '#2563eb' },
    { title: 'ROYAL RAJPUT DHABA', sub: 'Tandoori Roti & Paneer', color: '#b45309' },
    { title: 'PATEL ELECTRONICS', sub: 'Mobile Recharge & Repairs', color: '#7c3aed' },
    { title: 'NAMASTE MART', sub: 'Supermarket & Groceries', color: '#0369a1' }
  ];

  function createShopBanner(title: string, sub: string, bgColor: string): THREE.Mesh {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 128;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = bgColor;
      ctx.fillRect(0, 0, 512, 128);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 36px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(title, 256, 52);
      ctx.fillStyle = '#fef08a';
      ctx.font = '22px sans-serif';
      ctx.fillText(sub, 256, 96);
    }
    const texture = new THREE.CanvasTexture(canvas);
    const geo = new THREE.BoxGeometry(10, 2.5, 0.4);
    const mat = new THREE.MeshBasicMaterial({ map: texture });
    return new THREE.Mesh(geo, mat);
  }

  // --- Generate City Grid (Roads, Intersections, Buildings) ---
  const roadSegments: { x: number; z: number; isIntersection: boolean }[] = [];
  const signals: TrafficSignal[] = [];
  const signalMeshes = new Map<string, { red: THREE.Mesh; yellow: THREE.Mesh; green: THREE.Mesh }>();

  // 1. Intersections & Roads
  for (let gx = -CITY_GRID_EXTENT; gx <= CITY_GRID_EXTENT; gx++) {
    for (let gz = -CITY_GRID_EXTENT; gz <= CITY_GRID_EXTENT; gz++) {
      const cx = gx * BLOCK_SIZE;
      const cz = gz * BLOCK_SIZE;

      // Intersection Square
      const interGeo = new THREE.PlaneGeometry(ROAD_WIDTH, ROAD_WIDTH);
      const interMesh = new THREE.Mesh(interGeo, asphaltMat);
      interMesh.rotation.x = -Math.PI / 2;
      interMesh.position.set(cx, 0.01, cz);
      interMesh.receiveShadow = true;
      sceneGroup.add(interMesh);
      roadSegments.push({ x: cx, z: cz, isIntersection: true });

      // Zebra Crossings on all 4 arms of intersection
      const zebraArms = [
        { zOff: ROAD_WIDTH / 2 + 1.8, xOff: 0, rot: 0 },
        { zOff: -(ROAD_WIDTH / 2 + 1.8), xOff: 0, rot: 0 },
        { zOff: 0, xOff: ROAD_WIDTH / 2 + 1.8, rot: Math.PI / 2 },
        { zOff: 0, xOff: -(ROAD_WIDTH / 2 + 1.8), rot: Math.PI / 2 }
      ];

      zebraArms.forEach(arm => {
        const zebraGroup = new THREE.Group();
        const numStripes = 10;
        for (let s = 0; s < numStripes; s++) {
          const stripe = new THREE.Mesh(new THREE.PlaneGeometry(0.7, 3.2), whitePaintMat);
          stripe.rotation.x = -Math.PI / 2;
          stripe.position.set((s - (numStripes - 1) / 2) * 1.5, 0.02, 0);
          zebraGroup.add(stripe);
        }
        zebraGroup.position.set(cx + arm.xOff, 0, cz + arm.zOff);
        zebraGroup.rotation.y = arm.rot;
        sceneGroup.add(zebraGroup);

        // Stop Line before zebra crossing
        const stopLine = new THREE.Mesh(new THREE.PlaneGeometry(ROAD_WIDTH - 2, 0.6), whitePaintMat);
        stopLine.rotation.x = -Math.PI / 2;
        stopLine.position.set(
          cx + (arm.xOff ? Math.sign(arm.xOff) * (ROAD_WIDTH / 2 + 3.8) : 0),
          0.02,
          cz + (arm.zOff ? Math.sign(arm.zOff) * (ROAD_WIDTH / 2 + 3.8) : 0)
        );
        if (arm.rot !== 0) stopLine.rotation.y = arm.rot;
        sceneGroup.add(stopLine);
      });

      // 4 Traffic Signals for each intersection in Indian Left-Hand Traffic (LHT):
      // Road width is 18m.
      // Stop line is at ROAD_WIDTH / 2 + 3.8 = 12.8m from intersection center.
      // Left sidewalk curb is at ROAD_WIDTH / 2 + 1.2 = 10.2m from road center.
      const stopLineOffset = ROAD_WIDTH / 2 + 3.8; // 12.8m
      const curbOffset = ROAD_WIDTH / 2 + 1.2;     // 10.2m

      const sigPositions = [
        // Northbound: approaching cz from south (z < cz), driving along x = cx - 4.5.
        // Stop line is at z = cz - 12.8. Left curb is at x = cx - 10.2.
        { id: `sig_${gx}_${gz}_N`, x: cx - curbOffset, z: cz - stopLineOffset, facing: 'north' as const, dirAngle: 0 },

        // Southbound: approaching cz from north (z > cz), driving along x = cx + 4.5.
        // Stop line is at z = cz + 12.8. Left curb is at x = cx + 10.2.
        { id: `sig_${gx}_${gz}_S`, x: cx + curbOffset, z: cz + stopLineOffset, facing: 'south' as const, dirAngle: Math.PI },

        // Eastbound: approaching cx from west (x < cx), driving along z = cz + 4.5.
        // Stop line is at x = cx - 12.8. Left curb is at z = cz + 10.2.
        { id: `sig_${gx}_${gz}_E`, x: cx - stopLineOffset, z: cz + curbOffset, facing: 'east' as const, dirAngle: Math.PI / 2 },

        // Westbound: approaching cx from east (x > cx), driving along z = cz - 4.5.
        // Stop line is at x = cx + 12.8. Left curb is at z = cz - 10.2.
        { id: `sig_${gx}_${gz}_W`, x: cx + stopLineOffset, z: cz - curbOffset, facing: 'west' as const, dirAngle: -Math.PI / 2 }
      ];

      // Offset timing between N-S and E-W to create real alternating green/red traffic cycles
      sigPositions.forEach((pos, idx) => {
        const isNS = idx < 2;
        const initialTimer = isNS ? 0 : 16;
        const initialState: SignalState = isNS ? 'green' : 'red';

        signals.push({
          id: pos.id,
          x: pos.x,
          z: pos.z,
          facing: pos.facing,
          state: initialState,
          timer: initialTimer,
          cycleTime: { green: 14, yellow: 3.5, red: 17.5 }
        });

        // 3D Signal Post with Cantilever Mast Arm extending over driver's left lane
        const poleGroup = new THREE.Group();
        poleGroup.position.set(pos.x, 0, pos.z);
        poleGroup.rotation.y = pos.dirAngle;

        // Heavy vertical pole at curb
        const pole = new THREE.Mesh(
          new THREE.CylinderGeometry(0.16, 0.20, 6.2, 8),
          new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.6 })
        );
        pole.position.y = 3.1;
        poleGroup.add(pole);

        // Mast arm extension extending horizontally +X by 5.5m over the left carriageway
        const arm = new THREE.Mesh(
          new THREE.BoxGeometry(5.6, 0.16, 0.16),
          new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.6 })
        );
        arm.position.set(2.8, 5.5, 0);
        poleGroup.add(arm);

        // Support strut diagonal brace
        const strut = new THREE.Mesh(
          new THREE.BoxGeometry(2.0, 0.1, 0.1),
          new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.6 })
        );
        strut.position.set(1.0, 4.6, 0);
        strut.rotation.z = Math.PI / 4;
        poleGroup.add(strut);

        // Signal Housing Assembly at end of mast arm (centered at X = 5.2, directly over left lane)
        const headGroup = new THREE.Group();
        headGroup.position.set(5.2, 5.2, 0);

        // High-contrast Indian IRC Backing Board with yellow safety border
        const backPlate = new THREE.Mesh(
          new THREE.BoxGeometry(0.9, 2.2, 0.08),
          new THREE.MeshBasicMaterial({ color: 0xfacc15 }) // Bright yellow border
        );
        const innerPlate = new THREE.Mesh(
          new THREE.BoxGeometry(0.78, 2.08, 0.1),
          new THREE.MeshBasicMaterial({ color: 0x0a0a0a }) // Black contrast plate
        );
        headGroup.add(backPlate, innerPlate);

        // Signal Housing Box
        const box = new THREE.Mesh(
          new THREE.BoxGeometry(0.58, 1.8, 0.35),
          new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.5 })
        );
        box.position.set(0, 0, 0.1);
        headGroup.add(box);

        // Red, Yellow, Green Bulbs (facing towards -Z, directly facing oncoming approaching driver!)
        const redBulb = new THREE.Mesh(
          new THREE.CylinderGeometry(0.2, 0.2, 0.12, 16),
          new THREE.MeshBasicMaterial({ color: initialState === 'red' ? 0xff2222 : 0x2e0505 })
        );
        redBulb.rotation.x = Math.PI / 2;
        redBulb.position.set(0, 0.6, -0.15);

        const yellowBulb = new THREE.Mesh(
          new THREE.CylinderGeometry(0.2, 0.2, 0.12, 16),
          new THREE.MeshBasicMaterial({ color: 0x2a1d00 })
        );
        yellowBulb.rotation.x = Math.PI / 2;
        yellowBulb.position.set(0, 0.0, -0.15);

        const greenBulb = new THREE.Mesh(
          new THREE.CylinderGeometry(0.2, 0.2, 0.12, 16),
          new THREE.MeshBasicMaterial({ color: initialState === 'green' ? 0x00e676 : 0x022414 })
        );
        greenBulb.rotation.x = Math.PI / 2;
        greenBulb.position.set(0, -0.6, -0.15);

        // Anti-glare Visor Hoods over each bulb
        [-0.6, 0.0, 0.6].forEach(yPos => {
          const visor = new THREE.Mesh(
            new THREE.CylinderGeometry(0.23, 0.23, 0.22, 12, 1, true, 0, Math.PI),
            new THREE.MeshBasicMaterial({ color: 0x111827, side: THREE.DoubleSide })
          );
          visor.rotation.z = Math.PI / 2;
          visor.position.set(0, yPos + 0.1, -0.2);
          headGroup.add(visor);
        });

        headGroup.add(redBulb, yellowBulb, greenBulb);
        poleGroup.add(headGroup);
        sceneGroup.add(poleGroup);

        signalMeshes.set(pos.id, { red: redBulb, yellow: yellowBulb, green: greenBulb });
      });

      // 2. North-South Road Stretch (if not at bottom edge)
      if (gz < CITY_GRID_EXTENT) {
        const roadLength = BLOCK_SIZE - ROAD_WIDTH;
        const roadCenterZ = cz + BLOCK_SIZE / 2;

        const roadMesh = new THREE.Mesh(new THREE.PlaneGeometry(ROAD_WIDTH, roadLength), asphaltMat);
        roadMesh.rotation.x = -Math.PI / 2;
        roadMesh.position.set(cx, 0.01, roadCenterZ);
        roadMesh.receiveShadow = true;
        sceneGroup.add(roadMesh);

        // Double Yellow Center Lines (Indian road style)
        const dYellow1 = new THREE.Mesh(new THREE.PlaneGeometry(0.15, roadLength), yellowPaintMat);
        dYellow1.rotation.x = -Math.PI / 2;
        dYellow1.position.set(cx - 0.2, 0.02, roadCenterZ);
        const dYellow2 = dYellow1.clone();
        dYellow2.position.x = cx + 0.2;
        sceneGroup.add(dYellow1, dYellow2);

        // Dashed White Lane Dividers (both left and right carriageways)
        const numDashes = Math.floor(roadLength / 6);
        for (let i = 0; i < numDashes; i++) {
          const dashZ = roadCenterZ - roadLength / 2 + (i + 0.5) * 6;
          // Left side lane divider
          const dashL = new THREE.Mesh(new THREE.PlaneGeometry(0.18, 3.0), whitePaintMat);
          dashL.rotation.x = -Math.PI / 2;
          dashL.position.set(cx - ROAD_WIDTH / 4, 0.02, dashZ);
          // Right side lane divider
          const dashR = new THREE.Mesh(new THREE.PlaneGeometry(0.18, 3.0), whitePaintMat);
          dashR.rotation.x = -Math.PI / 2;
          dashR.position.set(cx + ROAD_WIDTH / 4, 0.02, dashZ);
          sceneGroup.add(dashL, dashR);
        }

        // Painted White Indian Lane Directional Arrows
        const numArrows = 2;
        for (let a = 0; a < numArrows; a++) {
          const arrowZ = roadCenterZ - roadLength / 4 + a * (roadLength / 2);

          // Left carriageway (traveling North +Z in Indian LHD)
          const arrowL = new THREE.Mesh(new THREE.ConeGeometry(0.7, 1.6, 3), whitePaintMat);
          arrowL.rotation.x = -Math.PI / 2;
          arrowL.position.set(cx - ROAD_WIDTH / 4, 0.03, arrowZ);
          sceneGroup.add(arrowL);

          // Right carriageway (traveling South -Z in Indian LHD)
          const arrowR = new THREE.Mesh(new THREE.ConeGeometry(0.7, 1.6, 3), whitePaintMat);
          arrowR.rotation.x = Math.PI / 2;
          arrowR.position.set(cx + ROAD_WIDTH / 4, 0.03, arrowZ);
          sceneGroup.add(arrowR);
        }

        // Sidewalks on left & right
        const swWidth = 3.5;
        const swL = new THREE.Mesh(new THREE.BoxGeometry(swWidth, 0.3, roadLength), sidewalkMat);
        swL.position.set(cx - ROAD_WIDTH / 2 - swWidth / 2, 0.15, roadCenterZ);
        const swR = new THREE.Mesh(new THREE.BoxGeometry(swWidth, 0.3, roadLength), sidewalkMat);
        swR.position.set(cx + ROAD_WIDTH / 2 + swWidth / 2, 0.15, roadCenterZ);
        sceneGroup.add(swL, swR);

        // Road divider curb with bougainvillea shrubs & streetlights
        const divider = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.25, roadLength), curbDividerMat);
        divider.position.set(cx, 0.12, roadCenterZ);
        sceneGroup.add(divider);

        // Streetlights along median
        const numLamps = 3;
        for (let l = 0; l < numLamps; l++) {
          const lz = roadCenterZ - roadLength / 2 + (l + 0.5) * (roadLength / numLamps);
          const lampPost = new THREE.Group();
          lampPost.position.set(cx, 0, lz);

          const poleMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 6.0, 8), new THREE.MeshStandardMaterial({ color: 0x475569 }));
          poleMesh.position.y = 3.0;
          lampPost.add(poleMesh);

          // Dual lantern arms
          const armMesh = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.1, 0.1), new THREE.MeshStandardMaterial({ color: 0x475569 }));
          armMesh.position.y = 6.0;
          lampPost.add(armMesh);

          const lampL = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.15, 8), new THREE.MeshBasicMaterial({ color: 0xfef08a }));
          lampL.position.set(-1.1, 5.85, 0);
          const lampR = lampL.clone();
          lampR.position.x = 1.1;
          lampPost.add(lampL, lampR);
          sceneGroup.add(lampPost);
        }
      }

      // 3. East-West Road Stretch (if not at right edge)
      if (gx < CITY_GRID_EXTENT) {
        const roadLength = BLOCK_SIZE - ROAD_WIDTH;
        const roadCenterX = cx + BLOCK_SIZE / 2;

        const roadMesh = new THREE.Mesh(new THREE.PlaneGeometry(roadLength, ROAD_WIDTH), asphaltMat);
        roadMesh.rotation.x = -Math.PI / 2;
        roadMesh.position.set(roadCenterX, 0.01, cz);
        roadMesh.receiveShadow = true;
        sceneGroup.add(roadMesh);

        // Double Yellow Center Lines
        const dYellow1 = new THREE.Mesh(new THREE.PlaneGeometry(roadLength, 0.15), yellowPaintMat);
        dYellow1.rotation.x = -Math.PI / 2;
        dYellow1.position.set(roadCenterX, 0.02, cz - 0.2);
        const dYellow2 = dYellow1.clone();
        dYellow2.position.z = cz + 0.2;
        sceneGroup.add(dYellow1, dYellow2);

        // Dashed White Lane Dividers
        const numDashes = Math.floor(roadLength / 6);
        for (let i = 0; i < numDashes; i++) {
          const dashX = roadCenterX - roadLength / 2 + (i + 0.5) * 6;
          const dashTop = new THREE.Mesh(new THREE.PlaneGeometry(3.0, 0.18), whitePaintMat);
          dashTop.rotation.x = -Math.PI / 2;
          dashTop.position.set(dashX, 0.02, cz - ROAD_WIDTH / 4);

          const dashBot = new THREE.Mesh(new THREE.PlaneGeometry(3.0, 0.18), whitePaintMat);
          dashBot.rotation.x = -Math.PI / 2;
          dashBot.position.set(dashX, 0.02, cz + ROAD_WIDTH / 4);
          sceneGroup.add(dashTop, dashBot);
        }

        // Painted White Indian Lane Directional Arrows for East-West roads
        const numArrowsEW = 2;
        for (let a = 0; a < numArrowsEW; a++) {
          const arrowX = roadCenterX - roadLength / 4 + a * (roadLength / 2);

          // Left carriageway looking East (cz + ROAD_WIDTH/4) pointing East (+X)
          const arrowEast = new THREE.Mesh(new THREE.ConeGeometry(0.7, 1.6, 3), whitePaintMat);
          arrowEast.rotation.x = -Math.PI / 2;
          arrowEast.rotation.z = -Math.PI / 2;
          arrowEast.position.set(arrowX, 0.03, cz + ROAD_WIDTH / 4);
          sceneGroup.add(arrowEast);

          // Right carriageway looking West (cz - ROAD_WIDTH/4) pointing West (-X)
          const arrowWest = new THREE.Mesh(new THREE.ConeGeometry(0.7, 1.6, 3), whitePaintMat);
          arrowWest.rotation.x = -Math.PI / 2;
          arrowWest.rotation.z = Math.PI / 2;
          arrowWest.position.set(arrowX, 0.03, cz - ROAD_WIDTH / 4);
          sceneGroup.add(arrowWest);
        }

        // Sidewalks top & bottom
        const swWidth = 3.5;
        const swTop = new THREE.Mesh(new THREE.BoxGeometry(roadLength, 0.3, swWidth), sidewalkMat);
        swTop.position.set(roadCenterX, 0.15, cz - ROAD_WIDTH / 2 - swWidth / 2);
        const swBot = new THREE.Mesh(new THREE.BoxGeometry(roadLength, 0.3, swWidth), sidewalkMat);
        swBot.position.set(roadCenterX, 0.15, cz + ROAD_WIDTH / 2 + swWidth / 2);
        sceneGroup.add(swTop, swBot);
      }

      // 4. Urban Buildings & Shops inside the block corner
      if (gx < CITY_GRID_EXTENT && gz < CITY_GRID_EXTENT) {
        const blockOriginX = cx + ROAD_WIDTH / 2 + 3.5;
        const blockOriginZ = cz + ROAD_WIDTH / 2 + 3.5;
        const blockInnerSize = BLOCK_SIZE - ROAD_WIDTH - 7.0;

        // Ground lawn / paving inside block
        const blockPark = new THREE.Mesh(new THREE.PlaneGeometry(blockInnerSize, blockInnerSize), grassMat);
        blockPark.rotation.x = -Math.PI / 2;
        blockPark.position.set(blockOriginX + blockInnerSize / 2, 0.05, blockOriginZ + blockInnerSize / 2);
        sceneGroup.add(blockPark);

        // Generate 4-6 distinct Indian buildings per block with varied heights & colors
        const buildingColors = [0xe2e8f0, 0xfde047, 0xfca5a5, 0x93c5fd, 0xd8b4fe, 0xfed7aa];
        const numBld = 5;
        for (let b = 0; b < numBld; b++) {
          const bW = 16 + (b * 3) % 10;
          const bD = 16 + ((b * 5) % 12);
          const bH = 12 + ((gx + gz + b) * 7) % 24;

          const bMat = new THREE.MeshStandardMaterial({
            color: buildingColors[(gx + gz + b + 10) % buildingColors.length],
            roughness: 0.6
          });
          const bMesh = new THREE.Mesh(new THREE.BoxGeometry(bW, bH, bD), bMat);
          const bx = blockOriginX + 12 + (b % 2) * (blockInnerSize - 30);
          const bz = blockOriginZ + 12 + Math.floor(b / 2) * (blockInnerSize / 2 - 10);
          bMesh.position.set(bx, bH / 2, bz);
          bMesh.castShadow = true;
          bMesh.receiveShadow = true;
          sceneGroup.add(bMesh);

          // Add Shop Banner on ground floor facing street
          const shopData = SHOP_NAMES[(gx * 3 + gz + b + 10) % SHOP_NAMES.length];
          const banner = createShopBanner(shopData.title, shopData.sub, shopData.color);
          banner.position.set(bx, 3.2, bz - bD / 2 - 0.25);
          sceneGroup.add(banner);

          // Water tank on roof (authentic Indian urban architecture)
          const tankGeo = new THREE.CylinderGeometry(1.2, 1.2, 1.8, 10);
          const tankMat = new THREE.MeshStandardMaterial({ color: 0x0284c7 });
          const tank = new THREE.Mesh(tankGeo, tankMat);
          tank.position.set(bx + 2, bH + 0.9, bz);
          sceneGroup.add(tank);
        }
      }
    }
  }

  // --- Dynamic Indian Road Hazards (Potholes, Speed Breakers, Barricades, Pedestrians) ---
  const hazards: HazardObject[] = [];
  const hazardMeshes = new Map<string, THREE.Group>();

  // 1. Potholes (asphalt depressions)
  const potholeLocations = [
    { x: 30, z: -4.5, warning: 'Pothole Ahead! Steer around or slow down' },
    { x: -50, z: 4.5, warning: 'Deep Pothole Detected!' },
    { x: 4.5, z: 75, warning: 'Monsoon Pothole! Avoid suspension damage' },
    { x: -4.5, z: -180, warning: 'Broken Asphalt Ahead' },
    { x: 170, z: -4.5, warning: 'Pothole on fast lane!' }
  ];

  potholeLocations.forEach((loc, idx) => {
    const id = `pothole_${idx}`;
    const pGroup = new THREE.Group();
    pGroup.position.set(loc.x, 0.04, loc.z);

    // Dark jagged irregular hole
    const holeGeo = new THREE.CircleGeometry(1.6, 10);
    const holeMat = new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.95 });
    const hole = new THREE.Mesh(holeGeo, holeMat);
    hole.rotation.x = -Math.PI / 2;
    pGroup.add(hole);

    // Jagged rim outline
    const rimGeo = new THREE.RingGeometry(1.5, 1.85, 10);
    const rimMat = new THREE.MeshBasicMaterial({ color: 0x44403c });
    const rim = new THREE.Mesh(rimGeo, rimMat);
    rim.rotation.x = -Math.PI / 2;
    pGroup.add(rim);

    sceneGroup.add(pGroup);
    hazardMeshes.set(id, pGroup);

    hazards.push({
      id,
      type: 'pothole',
      x: loc.x,
      z: loc.z,
      width: 3.2,
      depth: 3.2,
      height: 0.2,
      active: true,
      warningText: loc.warning
    });
  });

  // 2. Speed Breakers (Ramped bump with yellow & black warning paint)
  const speedBreakerLocations = [
    { x: 0, z: 50, rot: 0, warning: 'Speed Breaker! Slow below 25 km/h' },
    { x: 0, z: -50, rot: 0, warning: 'Speed Breaker Ahead! Brake now' },
    { x: 50, z: 0, rot: Math.PI / 2, warning: 'Rumble Strip / Speed Bump' },
    { x: -50, z: 0, rot: Math.PI / 2, warning: 'Speed Breaker Ahead!' }
  ];

  speedBreakerLocations.forEach((loc, idx) => {
    const id = `breaker_${idx}`;
    const bGroup = new THREE.Group();
    bGroup.position.set(loc.x, 0.1, loc.z);
    bGroup.rotation.y = loc.rot;

    // Curved bump
    const bumpGeo = new THREE.CylinderGeometry(0.18, 0.18, ROAD_WIDTH / 2, 10, 1, false, 0, Math.PI);
    bumpGeo.rotateZ(Math.PI / 2);
    const bumpMat = new THREE.MeshStandardMaterial({ color: 0xfacc15, roughness: 0.6 });
    const bump = new THREE.Mesh(bumpGeo, bumpMat);
    bGroup.add(bump);

    // Warning triangles / black stripes
    for (let s = -3; s <= 3; s++) {
      const stripe = new THREE.Mesh(new THREE.PlaneGeometry(0.4, 0.9), new THREE.MeshBasicMaterial({ color: 0x18181b }));
      stripe.rotation.x = -Math.PI / 2;
      stripe.position.set(s * 1.2, 0.11, 0);
      bGroup.add(stripe);
    }

    // Roadside Yellow Warning Triangle Signboard
    const signGroup = new THREE.Group();
    signGroup.position.set(ROAD_WIDTH / 4 + 1.8, 0, 0);
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 2.2, 8), new THREE.MeshStandardMaterial({ color: 0x475569 }));
    post.position.y = 1.1;
    const signBoard = new THREE.Mesh(new THREE.ConeGeometry(0.7, 0.9, 3), new THREE.MeshBasicMaterial({ color: 0xfacc15 }));
    signBoard.position.y = 2.4;
    signGroup.add(post, signBoard);
    bGroup.add(signGroup);

    sceneGroup.add(bGroup);
    hazardMeshes.set(id, bGroup);

    hazards.push({
      id,
      type: 'speed_breaker',
      x: loc.x,
      z: loc.z,
      width: loc.rot === 0 ? ROAD_WIDTH / 2 : 1.5,
      depth: loc.rot === 0 ? 1.5 : ROAD_WIDTH / 2,
      height: 0.25,
      active: true,
      warningText: loc.warning
    });
  });

  // 3. Indian Holy Cow & Pedestrians crossing at zebra crossing
  const cowGroup = new THREE.Group();
  cowGroup.position.set(3.5, 0, 72);
  // Low-poly cow body (authentic Indian road scene)
  const cowBody = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.9, 2.2), new THREE.MeshStandardMaterial({ color: 0xd6d3d1 }));
  cowBody.position.y = 1.0;
  const cowHead = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.6, 0.7), new THREE.MeshStandardMaterial({ color: 0xa8a29e }));
  cowHead.position.set(0, 1.4, 1.1);
  const cowHornL = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.4, 5), new THREE.MeshStandardMaterial({ color: 0x292524 }));
  cowHornL.position.set(0.25, 1.8, 1.0);
  cowHornL.rotation.z = -0.3;
  const cowHornR = cowHornL.clone();
  cowHornR.position.x = -0.25;
  cowHornR.rotation.z = 0.3;
  cowGroup.add(cowBody, cowHead, cowHornL, cowHornR);
  sceneGroup.add(cowGroup);
  hazardMeshes.set('cow_0', cowGroup);

  hazards.push({
    id: 'cow_0',
    type: 'cow',
    x: 3.5,
    z: 72,
    width: 1.4,
    depth: 2.4,
    height: 1.8,
    active: true,
    warningText: 'Sacred Cow on Road! Stop and give way',
    walkDir: 1
  });

  // --- Dynamic Updates & State Controllers ---
  function updateSignals(dt: number) {
    signals.forEach(sig => {
      sig.timer += dt;
      const totalCycle = sig.cycleTime.green + sig.cycleTime.yellow + sig.cycleTime.red;
      const currentPos = sig.timer % totalCycle;

      let nextState: SignalState = 'red';
      if (currentPos < sig.cycleTime.green) {
        nextState = 'green';
      } else if (currentPos < sig.cycleTime.green + sig.cycleTime.yellow) {
        nextState = 'yellow';
      } else {
        nextState = 'red';
      }

      sig.state = nextState;

      // Update Visual Bulbs
      const meshSet = signalMeshes.get(sig.id);
      if (meshSet) {
        (meshSet.red.material as THREE.MeshBasicMaterial).color.setHex(sig.state === 'red' ? 0xff0000 : 0x2b0707);
        (meshSet.yellow.material as THREE.MeshBasicMaterial).color.setHex(sig.state === 'yellow' ? 0xfbbf24 : 0x332505);
        (meshSet.green.material as THREE.MeshBasicMaterial).color.setHex(sig.state === 'green' ? 0x22c55e : 0x064e3b);
      }
    });
  }

  function updateHazards(dt: number) {
    hazards.forEach(hz => {
      if (hz.type === 'cow' && hz.walkDir !== undefined) {
        hz.x += hz.walkDir * 0.4 * dt;
        if (hz.x > 7.0) hz.walkDir = -1;
        if (hz.x < -7.0) hz.walkDir = 1;
        const mesh = hazardMeshes.get(hz.id);
        if (mesh) {
          mesh.position.x = hz.x;
          mesh.rotation.y = hz.walkDir > 0 ? 0 : Math.PI;
        }
      }
    });
  }

  function setTimeOfDay(time: TimeOfDay) {
    switch (time) {
      case 'day':
        ambientLight.intensity = 0.8;
        ambientLight.color.setHex(0xffffff);
        sunLight.intensity = 1.3;
        sunLight.color.setHex(0xfff5e6);
        sunLight.position.set(80, 140, 60);
        streetLights.forEach(l => (l.intensity = 0.1));
        break;
      case 'sunset':
        ambientLight.intensity = 0.55;
        ambientLight.color.setHex(0xfdba74); // Warm Orange
        sunLight.intensity = 1.0;
        sunLight.color.setHex(0xf97316);
        sunLight.position.set(120, 45, 40);
        streetLights.forEach(l => (l.intensity = 0.6));
        break;
      case 'night':
        ambientLight.intensity = 0.18;
        ambientLight.color.setHex(0x1e293b); // Midnight Blue
        sunLight.intensity = 0.15;
        sunLight.color.setHex(0x38bdf8);
        sunLight.position.set(20, 60, -40);
        streetLights.forEach(l => (l.intensity = 1.4));
        break;
    }
  }

  return {
    sceneGroup,
    signals,
    signalMeshes,
    hazards,
    hazardMeshes,
    ambientLight,
    sunLight,
    streetLights,
    updateSignals,
    updateHazards,
    setTimeOfDay
  };
}
