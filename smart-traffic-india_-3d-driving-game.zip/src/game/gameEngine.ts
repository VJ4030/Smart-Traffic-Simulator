import * as THREE from 'three';
import { soundManager } from '../audio/soundManager';
import {
  AIVehicle,
  CameraMode,
  DrivingTelemetry,
  HazardObject,
  Mission,
  NavigationInfo,
  SignalState,
  TrafficSignal,
  VehicleDefinition,
  VehicleId
} from '../types/game';
import { BLOCK_SIZE, CityEnvironment, ROAD_WIDTH } from './environment';
import { buildVehicleMesh, VEHICLE_CATALOG } from './vehicleModels';

export const CITY_SPEED_LIMIT_KMH = 50;

export interface GameEngineOptions {
  canvas: HTMLCanvasElement;
  onTelemetryUpdate: (telemetry: DrivingTelemetry) => void;
  onMissionComplete: (success: boolean, reason?: string) => void;
  onHazardAlert: (message: string, type: 'warning' | 'danger' | 'info') => void;
}

export class GameEngine {
  private canvas: HTMLCanvasElement;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private renderer: THREE.WebGLRenderer;
  private city: CityEnvironment;

  // Player Vehicle Dynamics
  private playerMesh: THREE.Group | null = null;
  private playerDef: VehicleDefinition;
  private playerPos = new THREE.Vector3(0, 0, 0);
  private playerSpeed = 0;       // m/s (+ forward, - reverse)
  private playerAngle = 0;       // radians (0 = North +Z)
  private playerYawRate = 0;     // rad/s (smoothed rotational momentum)
  private playerSteerAngle = 0;  // current actual wheel steer angle
  private playerTargetSteer = 0; // target steer based on input & speed
  private smoothSteerInput = 0;  // smoothed input (-1 to 1)
  private smoothThrottle = 0;    // smoothed input (-1 to 1)
  private gearState: 'D' | 'N' | 'R' = 'D';

  // Suspension & Ride Dynamics (Harmonic Oscillator)
  private suspensionOffset = 0;  // vertical chassis displacement (m)
  private suspensionVelocity = 0;// vertical bounce velocity (m/s)
  private chassisPitch = 0;      // forward/backward dive/squat (rad)
  private chassisRoll = 0;       // cornering body roll (rad)

  // Status & Scores
  private playerHealth = 100;
  private playerFuel = 100;
  private totalCollisions = 0;
  private redLightViolations = 0;
  private score = 0;
  private distanceMeters = 0;
  private activeRuleTip = '🚦 Stop behind white line on RED • Keep Left';

  // Headlights
  private headlightL: THREE.SpotLight | null = null;
  private headlightR: THREE.SpotLight | null = null;
  private headlightsActive = true;

  // Camera
  private cameraMode: CameraMode = 'chase';
  private cameraPosSmooth = new THREE.Vector3();
  private cameraLookSmooth = new THREE.Vector3();
  private cameraAngleSmooth = 0;

  // Controls input
  private inputThrottle = 0; // -1 to 1
  private inputSteer = 0;    // -1 to 1
  private inputHandbrake = false;

  // AI Traffic
  private aiVehicles: AIVehicle[] = [];
  private aiMeshes = new Map<string, THREE.Group>();

  // Mission & Navigation
  private currentMission: Mission | null = null;
  private missionTimer = 0;
  private destinationMarker: THREE.Group | null = null;
  private navArrowMesh: THREE.Group | null = null;
  private missionCompleted = false;

  // Traffic Rules & Violations Tracking
  private rewardedSignals = new Set<string>();
  private penalizedSignals = new Set<string>();
  private lastSpeedingAlertTime = 0;
  private lastBlinkerReminderTime = 0;
  private lastContraflowAlertTime = 0;
  private lastHazardHitTime = 0;
  private collisionCooldown = 0;
  private blinkerState: 'off' | 'left' | 'right' = 'off';
  private blinkerTimer = 0;

  // Loop & Throttled Telemetry Dispatch (60 FPS rendering, 20 FPS UI state)
  private animationFrameId: number | null = null;
  private lastTime = 0;
  private telemetryDispatchTimer = 0;
  private onTelemetryUpdate: (t: DrivingTelemetry) => void;
  private onMissionComplete: (s: boolean, reason?: string) => void;
  private onHazardAlert: (msg: string, type: 'warning' | 'danger' | 'info') => void;

  constructor(options: GameEngineOptions) {
    this.canvas = options.canvas;
    this.onTelemetryUpdate = options.onTelemetryUpdate;
    this.onMissionComplete = options.onMissionComplete;
    this.onHazardAlert = options.onHazardAlert;

    // 1. Scene setup
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x87ceeb);
    this.scene.fog = new THREE.FogExp2(0x87ceeb, 0.0035);

    // 2. Camera
    this.camera = new THREE.PerspectiveCamera(
      60,
      this.canvas.clientWidth / this.canvas.clientHeight,
      0.5,
      600
    );

    // 3. Renderer (Optimized for smooth 60fps without high-DPI GPU lag)
    this.renderer = new THREE.WebGLRenderer({
      canvas: this.canvas,
      antialias: true,
      powerPreference: 'high-performance'
    });
    this.renderer.setSize(this.canvas.clientWidth, this.canvas.clientHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5)); // 1.5x pixel ratio prevents 4K lag
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    // 4. City Environment
    this.city = this.scene.add(new THREE.Group()) as unknown as CityEnvironment;
    const builtCity = (window as unknown as { _tempCity?: CityEnvironment })._tempCity;
    if (builtCity) {
      this.city = builtCity;
    }

    // Default vehicle
    this.playerDef = VEHICLE_CATALOG[0];

    // Build 3D Navigation Waypoint Arrow
    this.navArrowMesh = this.buildNavArrowMesh();
    this.scene.add(this.navArrowMesh);

    // Resize handler
    this.handleResize = this.handleResize.bind(this);
    window.addEventListener('resize', this.handleResize);
    window.addEventListener('orientationchange', this.handleResize);
  }

  public initEnvironment(cityEnv: CityEnvironment) {
    this.city = cityEnv;
    this.scene.add(cityEnv.sceneGroup);
  }

  public setPlayerVehicle(def: VehicleDefinition, customColor?: string) {
    this.playerDef = def;
    if (this.playerMesh) {
      this.scene.remove(this.playerMesh);
    }
    const color = customColor || def.color;
    this.playerMesh = buildVehicleMesh(def.id, color);
    this.scene.add(this.playerMesh);

    // Attach Front Spotlights (Headlights without redundant shadow rendering passes)
    if (this.headlightL) this.scene.remove(this.headlightL);
    if (this.headlightR) this.scene.remove(this.headlightR);

    this.headlightL = new THREE.SpotLight(0xfffbeb, 2.5, 60, Math.PI / 6, 0.4);
    this.headlightR = new THREE.SpotLight(0xfffbeb, 2.5, 60, Math.PI / 6, 0.4);
    this.headlightL.castShadow = false; // Prevents 2 additional scene shadow render passes per frame
    this.headlightR.castShadow = false;

    this.scene.add(this.headlightL, this.headlightR);
    this.scene.add(this.headlightL.target, this.headlightR.target);

    this.updateHeadlights();
  }

  public setCameraMode(mode: CameraMode) {
    this.cameraMode = mode;
  }

  public toggleHeadlights() {
    this.headlightsActive = !this.headlightsActive;
    this.updateHeadlights();
    return this.headlightsActive;
  }

  private updateHeadlights() {
    if (this.headlightL && this.headlightR) {
      this.headlightL.visible = this.headlightsActive;
      this.headlightR.visible = this.headlightsActive;
    }
  }

  public honk() {
    soundManager.playHorn();
    // Nearby AI reaction: vehicles ahead clear lane or yield
    this.aiVehicles.forEach(ai => {
      const dist = Math.hypot(ai.x - this.playerPos.x, ai.z - this.playerPos.z);
      if (dist < 28) {
        ai.speed = Math.min(ai.maxSpeed * 1.15, ai.speed + 2.0);
      }
    });
  }

  public setInput(throttle: number, steer: number, handbrake: boolean) {
    this.inputThrottle = Math.max(-1, Math.min(1, throttle));
    this.inputSteer = Math.max(-1, Math.min(1, steer));
    this.inputHandbrake = handbrake;
  }

  // --- 3D Nav Arrow Mesh Builder ---
  private buildNavArrowMesh(): THREE.Group {
    const group = new THREE.Group();
    group.name = 'nav_arrow_group';

    // Stylized glowing 3D navigational chevron
    const arrowShape = new THREE.Shape();
    arrowShape.moveTo(0, 0.85);
    arrowShape.lineTo(0.55, -0.45);
    arrowShape.lineTo(0.22, -0.22);
    arrowShape.lineTo(0.22, -0.75);
    arrowShape.lineTo(-0.22, -0.75);
    arrowShape.lineTo(-0.22, -0.22);
    arrowShape.lineTo(-0.55, -0.45);
    arrowShape.closePath();

    const extrudeSettings = {
      depth: 0.16,
      bevelEnabled: true,
      bevelSegments: 2,
      steps: 1,
      bevelSize: 0.04,
      bevelThickness: 0.04
    };
    const arrowGeo = new THREE.ExtrudeGeometry(arrowShape, extrudeSettings);
    arrowGeo.rotateX(Math.PI / 2);

    const arrowMat = new THREE.MeshBasicMaterial({
      color: 0x10b981,
      transparent: true,
      opacity: 0.95
    });
    const arrowMesh = new THREE.Mesh(arrowGeo, arrowMat);
    group.add(arrowMesh);

    // Glowing navigation compass ring
    const ringGeo = new THREE.RingGeometry(0.85, 1.05, 24);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x34d399,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.55
    });
    const ringMesh = new THREE.Mesh(ringGeo, ringMat);
    ringMesh.rotation.x = Math.PI / 2;
    group.add(ringMesh);

    return group;
  }

  public startMission(mission: Mission | null, startPos?: { x: number; z: number; angle?: number }) {
    this.currentMission = mission;
    this.missionTimer = mission ? mission.timeLimitSec : 0;
    this.missionCompleted = false;
    this.totalCollisions = 0;
    this.redLightViolations = 0;
    this.score = 0;
    this.distanceMeters = 0;
    this.playerHealth = 100;
    this.playerFuel = 100;
    this.rewardedSignals.clear();
    this.penalizedSignals.clear();

    // Reset Player Position to authentic Indian Left-Hand Carriageway (LHT)
    const initX = startPos?.x ?? -4.5;
    const initZ = startPos?.z ?? -40;
    const initAngle = startPos?.angle ?? 0;

    this.playerPos.set(initX, 0, initZ);
    this.playerAngle = initAngle;
    this.playerYawRate = 0;
    this.cameraAngleSmooth = initAngle;
    this.playerSpeed = 0;
    this.playerSteerAngle = 0;
    this.playerTargetSteer = 0;
    this.smoothSteerInput = 0;
    this.smoothThrottle = 0;
    this.suspensionOffset = 0;
    this.suspensionVelocity = 0;
    this.chassisPitch = 0;
    this.chassisRoll = 0;
    this.gearState = 'D';

    // Create Destination Beacon / Checkpoint Marker
    if (this.destinationMarker) {
      this.scene.remove(this.destinationMarker);
      this.destinationMarker = null;
    }

    const targetX = mission ? mission.targetX : 0;
    const targetZ = mission ? mission.targetZ : 140;

    if (mission) {
      this.city.setTimeOfDay(mission.timeOfDay);
      this.scene.fog = new THREE.FogExp2(
        mission.timeOfDay === 'night' ? 0x0f172a : mission.timeOfDay === 'sunset' ? 0xf97316 : 0x87ceeb,
        0.0035
      );
      this.scene.background = new THREE.Color(
        mission.timeOfDay === 'night' ? 0x090d16 : mission.timeOfDay === 'sunset' ? 0x7c2d12 : 0x87ceeb
      );
    } else {
      this.city.setTimeOfDay('day');
      this.scene.fog = new THREE.FogExp2(0x87ceeb, 0.0035);
      this.scene.background = new THREE.Color(0x87ceeb);
    }

    // 3D Destination Cylinder + Pulsing Rings + Tower Beacon
    const markerGroup = new THREE.Group();
    markerGroup.position.set(targetX, 0, targetZ);

    const ringGeo = new THREE.RingGeometry(3.5, 4.8, 32);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0x10b981, side: THREE.DoubleSide });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.05;
    markerGroup.add(ring);

    const outerRingGeo = new THREE.RingGeometry(5.2, 5.8, 32);
    const outerRingMat = new THREE.MeshBasicMaterial({
      color: 0x34d399,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.6
    });
    const outerRing = new THREE.Mesh(outerRingGeo, outerRingMat);
    outerRing.rotation.x = -Math.PI / 2;
    outerRing.position.y = 0.06;
    markerGroup.add(outerRing);

    const beaconGeo = new THREE.CylinderGeometry(4.2, 4.2, 28, 24, 1, true);
    const beaconMat = new THREE.MeshBasicMaterial({
      color: 0x10b981,
      transparent: true,
      opacity: 0.35,
      side: THREE.DoubleSide
    });
    const beacon = new THREE.Mesh(beaconGeo, beaconMat);
    beacon.position.y = 14;
    markerGroup.add(beacon);

    const diamondGeo = new THREE.OctahedronGeometry(1.6, 0);
    const diamondMat = new THREE.MeshBasicMaterial({ color: 0x34d399 });
    const diamond = new THREE.Mesh(diamondGeo, diamondMat);
    diamond.position.y = 16;
    markerGroup.add(diamond);

    this.destinationMarker = markerGroup;
    this.scene.add(this.destinationMarker);

    // Spawn AI Traffic suited to density
    this.spawnAITraffic(mission ? mission.trafficDensity : 'medium');
  }

  private spawnAITraffic(density: 'low' | 'medium' | 'high') {
    // Clear existing AI
    this.aiVehicles.forEach(ai => {
      const mesh = this.aiMeshes.get(ai.id);
      if (mesh) this.scene.remove(mesh);
    });
    this.aiVehicles = [];
    this.aiMeshes.clear();

    const count = density === 'low' ? 14 : density === 'medium' ? 24 : 36;
    const aiTypes: VehicleId[] = [
      'auto_rickshaw',
      'auto_rickshaw',
      'auto_rickshaw',
      'hatchback',
      'sedan',
      'suv',
      'city_bus',
      'indian_truck',
      'motorcycle',
      'motorcycle',
      'ambulance'
    ];

    const colors = ['#e11d48', '#2563eb', '#16a34a', '#f59e0b', '#0891b2', '#475569', '#ea580c', '#f8fafc'];

    for (let i = 0; i < count; i++) {
      const type = aiTypes[Math.floor(Math.random() * aiTypes.length)];
      const color = colors[Math.floor(Math.random() * colors.length)];
      const id = `ai_${i}`;

      const isZRoad = Math.random() > 0.5;
      const roadCoord = (Math.floor(Math.random() * 5) - 2) * BLOCK_SIZE;
      const direction: 1 | -1 = Math.random() > 0.5 ? 1 : -1;

      // Authentic Indian Left-Hand Traffic (LHT) Lane Distribution
      const useFastLane = Math.random() > 0.5 && type !== 'auto_rickshaw' && type !== 'city_bus';
      const laneDist = useFastLane ? 2.5 : 6.0;

      const laneOffset = isZRoad
        ? (direction === 1 ? -laneDist : laneDist)
        : (direction === 1 ? laneDist : -laneDist);

      const distanceOnRoad = (Math.random() - 0.5) * 550;
      const x = isZRoad ? roadCoord + laneOffset : distanceOnRoad;
      const z = isZRoad ? distanceOnRoad : roadCoord + laneOffset;

      const angle = isZRoad
        ? (direction === 1 ? 0 : Math.PI)
        : (direction === 1 ? Math.PI / 2 : -Math.PI / 2);

      const aiVehicle: AIVehicle = {
        id,
        type,
        color,
        x,
        z,
        speed: 8 + Math.random() * 8, // ~30 to 60 km/h
        targetSpeed: 10 + Math.random() * 6,
        maxSpeed: type === 'auto_rickshaw' ? 14 : type === 'city_bus' ? 15 : 22,
        angle,
        lane: laneOffset,
        roadAxis: isZRoad ? 'z' : 'x',
        direction,
        width: type === 'city_bus' || type === 'indian_truck' ? 2.5 : 1.7,
        length: type === 'city_bus' ? 9.5 : type === 'indian_truck' ? 8.8 : 4.0,
        isBraking: false
      };

      this.aiVehicles.push(aiVehicle);

      const mesh = buildVehicleMesh(type, color);
      mesh.position.set(x, 0, z);
      mesh.rotation.y = angle;
      this.scene.add(mesh);
      this.aiMeshes.set(id, mesh);
    }
  }

  // --- Main Simulation Loop ---
  public start() {
    soundManager.startEngine();
    this.lastTime = performance.now();
    const loop = (time: number) => {
      const dt = Math.min((time - this.lastTime) / 1000, 0.1);
      this.lastTime = time;

      this.update(dt);
      this.render();

      this.animationFrameId = requestAnimationFrame(loop);
    };
    this.animationFrameId = requestAnimationFrame(loop);
  }

  public stop() {
    soundManager.stopEngine();
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
  }

  public destroy() {
    this.stop();
    window.removeEventListener('resize', this.handleResize);
    window.removeEventListener('orientationchange', this.handleResize);
    this.renderer.dispose();
  }

  private handleResize() {
    const width = this.canvas.clientWidth || window.innerWidth;
    const height = this.canvas.clientHeight || window.innerHeight;
    if (width === 0 || height === 0) return;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  private update(dt: number) {
    if (this.missionCompleted) return;

    // 0. Collision Immunity Decay & Flash
    if (this.collisionCooldown > 0) {
      this.collisionCooldown = Math.max(0, this.collisionCooldown - dt);
      if (this.playerMesh) {
        this.playerMesh.visible = Math.floor(this.collisionCooldown * 12) % 2 === 0;
      }
    } else if (this.playerMesh && !this.playerMesh.visible) {
      this.playerMesh.visible = true;
    }

    // Blinker relay sound
    if (this.blinkerState !== 'off') {
      this.blinkerTimer += dt;
      if (this.blinkerTimer >= 0.4) {
        this.blinkerTimer = 0;
        soundManager.playIndicatorClick();
      }
    }

    // 1. Update Environment Signals & Hazards
    this.city.updateSignals(dt);
    this.city.updateHazards(dt);

    // Rotate destination diamond & animate beacon
    if (this.destinationMarker) {
      const diamond = this.destinationMarker.children[3];
      if (diamond) {
        diamond.rotation.y += 2.2 * dt;
        diamond.rotation.z += 1.0 * dt;
      }
      const outerRing = this.destinationMarker.children[1];
      if (outerRing) {
        const pulse = 1.0 + Math.sin(performance.now() * 0.005) * 0.12;
        outerRing.scale.set(pulse, pulse, pulse);
      }
    }

    // 2. Player Vehicle Physics Integration (Ride, Handling, Kinematics)
    this.updatePlayerPhysics(dt);

    // 3. Update 3D Nav Arrow hovering above vehicle
    this.updateNavArrow();

    // 4. AI Traffic Simulation & Collisions
    this.updateAITraffic(dt);

    // 5. Comprehensive Indian Traffic Rules Evaluation
    this.checkRulesAndHazards(dt);

    // 6. Update Camera (Cinematic damping & smooth tracking)
    this.updateCamera(dt);

    // 7. Update Sound Pitch
    const speedKmh = Math.abs(this.playerSpeed * 3.6);
    soundManager.updateEngine(speedKmh, this.inputThrottle);

    // 8. Throttled Telemetry & Navigation Guidance Dispatch (20 FPS to eliminate React jank)
    this.telemetryDispatchTimer += dt;
    if (this.telemetryDispatchTimer >= 0.05) {
      this.telemetryDispatchTimer = 0;
      this.updateMissionAndTelemetry(dt);
    }
  }

  // --- Dynamic 3D Navigation Arrow Update ---
  private updateNavArrow() {
    if (!this.navArrowMesh) return;

    const targetX = this.currentMission ? this.currentMission.targetX : 0;
    const targetZ = this.currentMission ? this.currentMission.targetZ : 140;

    const dx = targetX - this.playerPos.x;
    const dz = targetZ - this.playerPos.z;
    const angleToTarget = Math.atan2(dx, dz);

    const baseHeight = (this.cameraMode === 'hood') ? 1.6 : (this.playerDef.dimensions.height + 1.25);
    const floatBob = Math.sin(performance.now() * 0.004) * 0.12;

    this.navArrowMesh.position.set(
      this.playerPos.x,
      baseHeight + floatBob + this.suspensionOffset,
      this.playerPos.z
    );
    this.navArrowMesh.rotation.y = angleToTarget;
  }

  // --- Advanced Ride & Handling Physics Model ---
  private updatePlayerPhysics(dt: number) {
    const def = this.playerDef;
    const maxSpeedMs = def.topSpeedKmh / 3.6;
    const accelPower = 11.5 * (def.acceleration / 100);
    const brakePower = 22.0 * (def.braking / 100);
    const currentSpeedKmh = Math.abs(this.playerSpeed * 3.6);

    // 1. Progressive input smoothing
    const steerRampSpeed = 7.0 * (def.handling / 100);
    this.smoothSteerInput += (this.inputSteer - this.smoothSteerInput) * Math.min(1, steerRampSpeed * dt);

    const throttleRampSpeed = 5.0;
    this.smoothThrottle += (this.inputThrottle - this.smoothThrottle) * Math.min(1, throttleRampSpeed * dt);

    // 2. Speed-sensitive steering (prevents high-speed oversteer/spinouts, allows sharp low-speed turns)
    const speedDamping = 1 / (1 + (currentSpeedKmh / 38) * 1.15);
    const maxSteerAngle = 0.56 * speedDamping;
    this.playerTargetSteer = -this.smoothSteerInput * maxSteerAngle;

    // Self-centering caster torque
    const isSteering = Math.abs(this.inputSteer) > 0.05;
    const steerResponse = isSteering ? (4.2 * (def.handling / 100)) : 8.8;
    this.playerSteerAngle += (this.playerTargetSteer - this.playerSteerAngle) * Math.min(1, steerResponse * dt);

    // 3. Transmission & Braking / Reverse Lock Logic
    let accelForce = 0;
    if (this.smoothThrottle > 0) {
      if (this.playerSpeed < -0.3) {
        accelForce = brakePower;
      } else {
        this.gearState = 'D';
        accelForce = this.smoothThrottle * accelPower;
      }
    } else if (this.smoothThrottle < 0) {
      if (this.playerSpeed > 0.3) {
        accelForce = this.smoothThrottle * brakePower;
        if (currentSpeedKmh > 18) soundManager.playBrakeScreech();
      } else {
        this.gearState = 'R';
        accelForce = this.smoothThrottle * (accelPower * 0.45);
      }
    } else {
      const rollingResistance = 1.6;
      const aeroDrag = 0.0075 * this.playerSpeed * Math.abs(this.playerSpeed);
      const totalDrag = (rollingResistance + aeroDrag) * dt;
      if (this.playerSpeed > 0) {
        this.playerSpeed = Math.max(0, this.playerSpeed - totalDrag);
      } else if (this.playerSpeed < 0) {
        this.playerSpeed = Math.min(0, this.playerSpeed + totalDrag);
      }
    }

    // Apply acceleration force
    this.playerSpeed += accelForce * dt;

    // Handbrake application
    if (this.inputHandbrake) {
      const handbrakeBraking = 19.0 * dt;
      if (this.playerSpeed > 0) {
        this.playerSpeed = Math.max(0, this.playerSpeed - handbrakeBraking);
      } else if (this.playerSpeed < 0) {
        this.playerSpeed = Math.min(0, this.playerSpeed + handbrakeBraking);
      }
      if (currentSpeedKmh > 10) soundManager.playBrakeScreech();
    }

    // Speed clamps
    this.playerSpeed = Math.max(-maxSpeedMs * 0.32, Math.min(maxSpeedMs, this.playerSpeed));

    // 4. Smooth Yaw Dynamics
    if (Math.abs(this.playerSpeed) > 0.05) {
      const wheelbase = Math.max(2.1, def.dimensions.length);
      const targetYawRate = (this.playerSpeed / wheelbase) * Math.tan(this.playerSteerAngle);
      const yawGrip = this.inputHandbrake ? 5.5 : 13.0;
      this.playerYawRate += (targetYawRate - this.playerYawRate) * Math.min(1, yawGrip * dt);
      this.playerAngle += this.playerYawRate * dt;
    } else {
      this.playerYawRate = 0;
    }

    // 5. Integrate forward position
    const dx = Math.sin(this.playerAngle) * this.playerSpeed * dt;
    const dz = Math.cos(this.playerAngle) * this.playerSpeed * dt;
    this.playerPos.x += dx;
    this.playerPos.z += dz;
    this.distanceMeters += Math.hypot(dx, dz);

    // Fuel consumption
    if (Math.abs(this.playerSpeed) > 0.1) {
      this.playerFuel = Math.max(0, this.playerFuel - 0.22 * dt);
    }

    // 6. Suspension and Ride Dynamics
    const targetPitch = (accelForce / 12) * -0.045;
    this.chassisPitch += (targetPitch - this.chassisPitch) * Math.min(1, 6.0 * dt);

    const lateralG = (this.playerSpeed * this.playerYawRate) / 9.8;
    const targetRoll = -lateralG * 0.14 - this.playerSteerAngle * (currentSpeedKmh / maxSpeedMs) * 0.08;
    this.chassisRoll += (targetRoll - this.chassisRoll) * Math.min(1, 7.5 * dt);

    const springK = 65.0;
    const springDamper = 8.5;
    const springAccel = -springK * this.suspensionOffset - springDamper * this.suspensionVelocity;
    this.suspensionVelocity += springAccel * dt;
    this.suspensionOffset += this.suspensionVelocity * dt;
    this.suspensionOffset = Math.max(-0.25, Math.min(0.25, this.suspensionOffset));

    // 7. Sync 3D Mesh
    if (this.playerMesh) {
      this.playerMesh.position.set(this.playerPos.x, this.suspensionOffset, this.playerPos.z);
      this.playerMesh.rotation.set(this.chassisPitch, this.playerAngle, this.chassisRoll, 'YXZ');

      const wFL = this.playerMesh.getObjectByName('wheel_fl');
      const wFR = this.playerMesh.getObjectByName('wheel_fr');
      if (wFL) wFL.rotation.y = this.playerSteerAngle;
      if (wFR) wFR.rotation.y = this.playerSteerAngle;

      const rollDelta = (this.playerSpeed * dt) / 0.35;
      ['wheel_fl', 'wheel_fr', 'wheel_rl', 'wheel_rr'].forEach(wName => {
        const wGroup = this.playerMesh?.getObjectByName(wName);
        const rollGroup = wGroup?.getObjectByName('roll_group');
        if (rollGroup) {
          rollGroup.rotation.x += rollDelta;
        }
      });
    }

    // 8. Update Spotlights (Headlights)
    if (this.headlightL && this.headlightR && this.headlightsActive) {
      const fwd = new THREE.Vector3(Math.sin(this.playerAngle), 0, Math.cos(this.playerAngle));
      const right = new THREE.Vector3(Math.cos(this.playerAngle), 0, -Math.sin(this.playerAngle));

      const posL = this.playerPos.clone().add(right.clone().multiplyScalar(0.7)).add(new THREE.Vector3(0, 0.6, 0));
      const posR = this.playerPos.clone().add(right.clone().multiplyScalar(-0.7)).add(new THREE.Vector3(0, 0.6, 0));

      this.headlightL.position.copy(posL);
      this.headlightR.position.copy(posR);

      this.headlightL.target.position.copy(posL.clone().add(fwd.clone().multiplyScalar(22)));
      this.headlightR.target.position.copy(posR.clone().add(fwd.clone().multiplyScalar(22)));
    }
  }

  // --- AI Traffic Simulation with Smooth Following & Indian LHT Rules ---
  private updateAITraffic(dt: number) {
    this.aiVehicles.forEach(ai => {
      let shouldBrake = false;
      let targetSpeed = ai.targetSpeed;

      const distToPlayer = Math.hypot(this.playerPos.x - ai.x, this.playerPos.z - ai.z);
      if (distToPlayer < 9.5) {
        shouldBrake = true;
      }

      this.aiVehicles.forEach(other => {
        if (other.id === ai.id) return;
        if (other.roadAxis === ai.roadAxis && other.direction === ai.direction) {
          const deltaZ = (other.z - ai.z) * ai.direction;
          const deltaX = (other.x - ai.x) * ai.direction;
          const distAhead = ai.roadAxis === 'z' ? deltaZ : deltaX;
          if (distAhead > 0 && distAhead < 14) {
            shouldBrake = true;
            targetSpeed = Math.min(targetSpeed, other.speed * 0.85);
          }
        }
      });

      // AI stops accurately at the approach stop lines of red signals
      const nextSignal = this.findNearestSignalAhead(ai.x, ai.z, ai.roadAxis, ai.direction);
      if (nextSignal && nextSignal.distAhead < 16 && nextSignal.distAhead > 0) {
        if (nextSignal.signal.state === 'red' || nextSignal.signal.state === 'yellow') {
          shouldBrake = true;
          targetSpeed = 0;
        }
      }

      if (shouldBrake) {
        ai.speed = Math.max(0, ai.speed - 12 * dt);
        ai.isBraking = true;
      } else {
        ai.speed += (targetSpeed - ai.speed) * 2.2 * dt;
        ai.isBraking = false;
      }

      if (ai.roadAxis === 'z') {
        ai.z += ai.direction * ai.speed * dt;
        if (ai.z > 350) ai.z = -350;
        if (ai.z < -350) ai.z = 350;
      } else {
        ai.x += ai.direction * ai.speed * dt;
        if (ai.x > 350) ai.x = -350;
        if (ai.x < -350) ai.x = 350;
      }

      const mesh = this.aiMeshes.get(ai.id);
      if (mesh) {
        mesh.position.set(ai.x, 0, ai.z);
        mesh.rotation.y = ai.angle;
      }

      if (distToPlayer < (ai.length / 2 + this.playerDef.dimensions.length / 2) * 0.75) {
        const pushVec = new THREE.Vector3(this.playerPos.x - ai.x, 0, this.playerPos.z - ai.z).normalize();
        this.handlePlayerCollision('AI Vehicle', pushVec);
      }
    });
  }

  private findNearestSignalAhead(x: number, z: number, axis: 'x' | 'z', dir: 1 | -1): { signal: TrafficSignal; distAhead: number } | null {
    let closest: TrafficSignal | null = null;
    let minDist = 999;

    this.city.signals.forEach(sig => {
      const distZ = (sig.z - z) * dir;
      const distX = (sig.x - x) * dir;
      const dist = axis === 'z' ? distZ : distX;

      if (dist > 0 && dist < 35 && dist < minDist) {
        minDist = dist;
        closest = sig;
      }
    });

    return closest ? { signal: closest, distAhead: minDist } : null;
  }

  // --- Indian Left-Hand Traffic (LHT) Contraflow Detection ---
  private checkContraflowDriving(): boolean {
    if (Math.abs(this.playerSpeed) < 1.0) return false;

    const nearestBlockX = Math.round(this.playerPos.x / BLOCK_SIZE) * BLOCK_SIZE;
    const distToRoadCenterZ = Math.abs(this.playerPos.x - nearestBlockX);

    const nearestBlockZ = Math.round(this.playerPos.z / BLOCK_SIZE) * BLOCK_SIZE;
    const distToRoadCenterX = Math.abs(this.playerPos.z - nearestBlockZ);

    const inIntersection = (Math.abs(this.playerPos.x % BLOCK_SIZE) < 12.0) && (Math.abs(this.playerPos.z % BLOCK_SIZE) < 12.0);
    if (inIntersection) return false;

    // On North-South road:
    if (distToRoadCenterZ < 8.5) {
      const cosAngle = Math.cos(this.playerAngle);
      // Northbound (+Z): left carriageway is playerPos.x < nearestBlockX - 0.4
      if (cosAngle > 0.4 && this.playerPos.x > nearestBlockX + 0.5) {
        return true;
      }
      // Southbound (-Z): left carriageway is playerPos.x > nearestBlockX + 0.4
      if (cosAngle < -0.4 && this.playerPos.x < nearestBlockX - 0.5) {
        return true;
      }
    }

    // On East-West road:
    if (distToRoadCenterX < 8.5) {
      const sinAngle = Math.sin(this.playerAngle);
      // Eastbound (+X): left carriageway is playerPos.z > nearestBlockZ + 0.4
      if (sinAngle > 0.4 && this.playerPos.z < nearestBlockZ - 0.5) {
        return true;
      }
      // Westbound (-X): left carriageway is playerPos.z < nearestBlockZ - 0.4
      if (sinAngle < -0.4 && this.playerPos.z > nearestBlockZ + 0.5) {
        return true;
      }
    }

    return false;
  }

  // --- Comprehensive Indian Traffic Rules & Penalties Engine ---
  private checkRulesAndHazards(dt: number) {
    const now = performance.now();
    const speedKmh = Math.abs(this.playerSpeed * 3.6);
    const cosAngle = Math.cos(this.playerAngle);
    const sinAngle = Math.sin(this.playerAngle);

    // 1. Precise Traffic Signal Stop Line Compliance & Violation
    this.city.signals.forEach(sig => {
      // Check if this signal matches driver's approach direction
      let isApproachMatch = false;
      let distToStopLine = 999;
      let lateralOffset = 999;

      if (sig.facing === 'north' && cosAngle > 0.4) {
        // Driver heading North (+Z), stop line is at sig.z
        isApproachMatch = true;
        distToStopLine = sig.z - this.playerPos.z;
        lateralOffset = Math.abs(this.playerPos.x - sig.x);
      } else if (sig.facing === 'south' && cosAngle < -0.4) {
        // Driver heading South (-Z), stop line is at sig.z
        isApproachMatch = true;
        distToStopLine = this.playerPos.z - sig.z;
        lateralOffset = Math.abs(this.playerPos.x - sig.x);
      } else if (sig.facing === 'east' && sinAngle > 0.4) {
        // Driver heading East (+X), stop line is at sig.x
        isApproachMatch = true;
        distToStopLine = sig.x - this.playerPos.x;
        lateralOffset = Math.abs(this.playerPos.z - sig.z);
      } else if (sig.facing === 'west' && sinAngle < -0.4) {
        // Driver heading West (-X), stop line is at sig.x
        isApproachMatch = true;
        distToStopLine = this.playerPos.x - sig.x;
        lateralOffset = Math.abs(this.playerPos.z - sig.z);
      }

      if (isApproachMatch && lateralOffset < 8.5) {
        // A. Approaching Stop Line on Red Signal
        if (sig.state === 'red') {
          // If stopped cleanly right before the white line (within 0.5m to 10m, speed < 2.5 km/h)
          if (distToStopLine > 0.5 && distToStopLine < 11.0 && speedKmh < 2.5) {
            if (!this.rewardedSignals.has(sig.id)) {
              this.rewardedSignals.add(sig.id);
              this.score += 50;
              this.activeRuleTip = '✅ Clean Stop at Red Signal (+50 pts)';
              this.onHazardAlert('✅ Excellent! Clean Stop at Red Signal (+50 pts)', 'info');
              soundManager.playIndicatorClick();
            }
          }

          // Approaching fast on red warning
          if (distToStopLine > 3.0 && distToStopLine < 18.0 && speedKmh > 25) {
            this.activeRuleTip = '🚦 RED SIGNAL AHEAD — Brake for White Stop Line!';
          }

          // B. Crossing Stop Line into Intersection on Red (Signal Violation)
          if (distToStopLine <= 0 && distToStopLine > -14.0 && speedKmh > 4.0) {
            if (!this.penalizedSignals.has(sig.id)) {
              this.penalizedSignals.add(sig.id);
              this.redLightViolations++;
              this.score = Math.max(0, this.score - 100);
              this.activeRuleTip = '🚦 Traffic Signal Violation! Red Light Jumped (-100 pts)';
              this.onHazardAlert('🚦 Red Light Violation! Jumped Signal at Stop Line (-100 pts)', 'danger');
              soundManager.playHazardWarning();
            }
          }
        } else if (sig.state === 'green') {
          // Reset cycle tracking when light turns green
          this.rewardedSignals.delete(sig.id);
          this.penalizedSignals.delete(sig.id);
        }
      }
    });

    // 2. Urban Speed Limit Enforcement (50 km/h)
    if (speedKmh > CITY_SPEED_LIMIT_KMH + 6) {
      if (now - this.lastSpeedingAlertTime > 4500) {
        this.lastSpeedingAlertTime = now;
        this.score = Math.max(0, this.score - 25);
        this.activeRuleTip = `⚠️ Speed Limit Exceeded! (${Math.round(speedKmh)} km/h in 50 km/h zone)`;
        this.onHazardAlert(`⚠️ Over Speeding! City Speed Limit is ${CITY_SPEED_LIMIT_KMH} km/h (-25 pts)`, 'warning');
        soundManager.playHazardWarning();
      }
    }

    // 3. Turn Indicator (Blinker) Compliance when turning at intersections
    const inJunction = (Math.abs(this.playerPos.x % BLOCK_SIZE) < 14.0) && (Math.abs(this.playerPos.z % BLOCK_SIZE) < 14.0);
    const isTurning = Math.abs(this.playerSteerAngle) > 0.22;
    if (inJunction && isTurning && now - this.lastBlinkerReminderTime > 5000) {
      this.lastBlinkerReminderTime = now;
      const turningLeft = this.playerSteerAngle < 0;
      const indicatorActive = turningLeft ? (this.blinkerState === 'left') : (this.blinkerState === 'right');

      if (indicatorActive) {
        this.score += 20;
        this.activeRuleTip = '✅ Proper Turn Signal Used (+20 pts)';
        this.onHazardAlert('✅ Good Driving! Turn Indicator Used Correctly (+20 pts)', 'info');
      } else {
        this.activeRuleTip = '💡 Rule: Use Turn Indicators [Q / E] before turning!';
        this.onHazardAlert('💡 Tip: Switch on Turn Indicator [Q for Left, E for Right] before turning!', 'info');
      }
    }

    // 4. Indian Left-Hand Traffic (LHT) Contraflow Warning
    if (this.checkContraflowDriving() && now - this.lastContraflowAlertTime > 4000) {
      this.lastContraflowAlertTime = now;
      this.score = Math.max(0, this.score - 30);
      this.activeRuleTip = '⚠️ Driving on Wrong Carriageway! Keep Left 🇮🇳';
      this.onHazardAlert('⚠️ Wrong Carriageway! Indian Traffic Drives on the Left Side 🇮🇳 (-30 pts)', 'warning');
      soundManager.playHazardWarning();
    }

    // 5. Road Hazards (Speed Breakers, Potholes, Sacred Cow)
    if (now - this.lastHazardHitTime > 1500) {
      this.city.hazards.forEach(hz => {
        const dist = Math.hypot(hz.x - this.playerPos.x, hz.z - this.playerPos.z);
        if (dist < (hz.width / 2 + 1.2)) {
          this.lastHazardHitTime = now;

          if (hz.type === 'pothole') {
            this.suspensionVelocity = -2.2;
            if (speedKmh > 22) {
              this.playerHealth = Math.max(0, this.playerHealth - 12);
              this.score = Math.max(0, this.score - 35);
              soundManager.playSpeedBreakerThud();
              this.activeRuleTip = '💥 Pothole Damage! Swerve around road depressions';
              this.onHazardAlert('💥 Hit Deep Pothole at Speed! Suspension Damaged (-35 pts)', 'warning');
            }
          } else if (hz.type === 'speed_breaker') {
            this.suspensionVelocity = 1.8;
            if (speedKmh > 25) {
              this.playerHealth = Math.max(0, this.playerHealth - 8);
              this.score = Math.max(0, this.score - 40);
              soundManager.playSpeedBreakerThud();
              this.activeRuleTip = '⚠️ Harsh Speed Breaker Bump! Slow below 25 km/h';
              this.onHazardAlert('⚠️ Crossed Speed Breaker without braking! Slow to 25 km/h (-40 pts)', 'warning');
            } else {
              this.score += 25;
              this.activeRuleTip = '✅ Smooth Speed Breaker Crossing (+25 pts)';
              this.onHazardAlert('✅ Smoothly Navigated Speed Breaker! (+25 pts)', 'info');
            }
          } else if (hz.type === 'cow') {
            const pushVec = new THREE.Vector3(this.playerPos.x - hz.x, 0, this.playerPos.z - hz.z).normalize();
            this.handlePlayerCollision('Sacred Cow', pushVec);
          }
        }
      });
    }

    // 6. City Perimeter Bounds
    if (Math.abs(this.playerPos.x) > 340 || Math.abs(this.playerPos.z) > 340) {
      this.playerPos.x = Math.max(-335, Math.min(335, this.playerPos.x));
      this.playerPos.z = Math.max(-335, Math.min(335, this.playerPos.z));
      this.playerSpeed = 0;
      this.onHazardAlert('⚠️ Reached City Perimeter!', 'info');
    }
  }

  private handlePlayerCollision(targetName: string, pushVec?: THREE.Vector3) {
    if (this.collisionCooldown > 0) return;
    this.collisionCooldown = 1.5;

    this.totalCollisions++;
    this.playerSpeed = -this.playerSpeed * 0.35;
    this.playerHealth = Math.max(0, this.playerHealth - 15);
    this.score = Math.max(0, this.score - 100);
    this.suspensionVelocity = 2.0;
    soundManager.playCrash();

    if (pushVec && pushVec.lengthSq() > 0.01) {
      this.playerPos.add(pushVec.clone().multiplyScalar(1.5));
    } else {
      const fwd = new THREE.Vector3(Math.sin(this.playerAngle), 0, Math.cos(this.playerAngle));
      this.playerPos.sub(fwd.clone().multiplyScalar(1.5));
    }

    this.activeRuleTip = `💥 Collision with ${targetName}! (-100 pts)`;
    this.onHazardAlert(`💥 Collision with ${targetName}! (-100 pts)`, 'danger');

    if (this.playerHealth <= 0) {
      this.missionCompleted = true;
      this.onMissionComplete(false, 'Vehicle Totalled! Vehicle health reached 0%.');
    }
  }

  public toggleBlinker(direction: 'left' | 'right'): 'off' | 'left' | 'right' {
    if (this.blinkerState === direction) {
      this.blinkerState = 'off';
    } else {
      this.blinkerState = direction;
      soundManager.playIndicatorClick();
    }
    return this.blinkerState;
  }

  public getBlinkerState(): 'off' | 'left' | 'right' {
    return this.blinkerState;
  }

  // --- Smooth Camera Following with Angular Interpolation ---
  private updateCamera(dt: number) {
    this.cameraAngleSmooth += (this.playerAngle - this.cameraAngleSmooth) * Math.min(1.0, 5.5 * dt);

    const fwd = new THREE.Vector3(Math.sin(this.cameraAngleSmooth), 0, Math.cos(this.cameraAngleSmooth));
    const up = new THREE.Vector3(0, 1, 0);

    let targetCamPos = new THREE.Vector3();
    let targetLookAt = new THREE.Vector3();

    switch (this.cameraMode) {
      case 'chase':
        targetCamPos = this.playerPos.clone().sub(fwd.clone().multiplyScalar(7.5)).add(up.clone().multiplyScalar(3.2 + this.suspensionOffset * 0.5));
        targetLookAt = this.playerPos.clone().add(fwd.clone().multiplyScalar(6.0)).add(up.clone().multiplyScalar(1.2));
        break;

      case 'close_chase':
        targetCamPos = this.playerPos.clone().sub(fwd.clone().multiplyScalar(5.0)).add(up.clone().multiplyScalar(2.0 + this.suspensionOffset * 0.5));
        targetLookAt = this.playerPos.clone().add(fwd.clone().multiplyScalar(8.0)).add(up.clone().multiplyScalar(1.0));
        break;

      case 'hood':
        targetCamPos = this.playerPos.clone().add(fwd.clone().multiplyScalar(1.4)).add(up.clone().multiplyScalar(1.1 + this.suspensionOffset));
        targetLookAt = this.playerPos.clone().add(fwd.clone().multiplyScalar(25)).add(up.clone().multiplyScalar(1.0));
        break;

      case 'top_down':
        targetCamPos = this.playerPos.clone().add(new THREE.Vector3(0, 48, 0));
        targetLookAt = this.playerPos.clone();
        break;
    }

    const damping = this.cameraMode === 'hood' ? 24.0 : 8.0;
    this.cameraPosSmooth.lerp(targetCamPos, Math.min(1.0, damping * dt));
    this.cameraLookSmooth.lerp(targetLookAt, Math.min(1.0, damping * dt));

    this.camera.position.copy(this.cameraPosSmooth);
    this.camera.lookAt(this.cameraLookSmooth);
  }

  // --- Turn-by-Turn Navigation & Telemetry Computation ---
  private updateMissionAndTelemetry(dt: number) {
    const speedKmh = Math.abs(this.playerSpeed * 3.6);
    const rpm = 800 + (speedKmh % 35) * 120 + (this.inputThrottle > 0 ? 900 : 0);
    const gear = this.playerSpeed < -0.1 ? 'R' : this.playerSpeed < 0.2 ? 'N' : 'D';

    const targetX = this.currentMission ? this.currentMission.targetX : 0;
    const targetZ = this.currentMission ? this.currentMission.targetZ : 140;
    const goalTitle = this.currentMission ? this.currentMission.title : 'Connaught Place Hub';

    const dx = targetX - this.playerPos.x;
    const dz = targetZ - this.playerPos.z;
    const distToGoal = Math.hypot(dx, dz);

    const worldAngleToGoal = Math.atan2(dx, dz);
    let relBearing = worldAngleToGoal - this.playerAngle;
    while (relBearing > Math.PI) relBearing -= Math.PI * 2;
    while (relBearing < -Math.PI) relBearing += Math.PI * 2;
    const relBearingDeg = Math.round((relBearing * 180) / Math.PI);

    let turnInstruction: 'straight' | 'left' | 'right' | 'uturn' | 'arriving' = 'straight';
    let instructionText = 'Continue Straight Ahead';

    if (distToGoal < 18) {
      turnInstruction = 'arriving';
      instructionText = 'Arriving at Destination Bay! Slow Down & Stop';
    } else if (Math.abs(relBearing) < 0.35) {
      turnInstruction = 'straight';
      instructionText = `Continue Straight for ${Math.round(distToGoal)}m`;
    } else if (relBearing >= 0.35 && relBearing < 2.1) {
      turnInstruction = 'left';
      instructionText = `Turn Left at Next Junction (${Math.round(distToGoal)}m)`;
    } else if (relBearing <= -0.35 && relBearing > -2.1) {
      turnInstruction = 'right';
      instructionText = `Turn Right at Next Junction (${Math.round(distToGoal)}m)`;
    } else {
      turnInstruction = 'uturn';
      instructionText = `Make a U-Turn / Take Next Right (${Math.round(distToGoal)}m)`;
    }

    const isWrongLane = this.checkContraflowDriving();

    const navInfo: NavigationInfo = {
      hasGoal: true,
      goalTitle,
      distanceMeters: Math.round(distToGoal),
      turnInstruction,
      instructionText,
      relativeBearingDeg: relBearingDeg,
      targetX,
      targetZ,
      isWrongLane
    };

    // Mission countdown & completion conditions
    if (this.currentMission) {
      this.missionTimer = Math.max(0, this.missionTimer - dt);

      if (distToGoal < 22 && distToGoal >= 7.0) {
        this.onHazardAlert('🏁 Slow down & stop inside the green checkpoint!', 'info');
      }

      if (distToGoal < 7.5 && speedKmh < 20) {
        this.missionCompleted = true;
        soundManager.playMissionSuccess();
        this.score += this.currentMission.rewardScore;
        this.onMissionComplete(true);
      } else if (this.missionTimer <= 0) {
        this.missionCompleted = true;
        this.onMissionComplete(false, 'Time Limit Expired! Destination not reached.');
      } else if (this.totalCollisions > this.currentMission.allowedCollisions) {
        this.missionCompleted = true;
        this.onMissionComplete(false, `Too many collisions! Max allowed was ${this.currentMission.allowedCollisions}.`);
      } else if (this.redLightViolations > this.currentMission.allowedRedLights) {
        this.missionCompleted = true;
        this.onMissionComplete(false, `Too many signal violations! Max allowed was ${this.currentMission.allowedRedLights}.`);
      }
    }

    // Telemetry dispatch (includes speedLimitKmh and activeRuleTip)
    this.onTelemetryUpdate({
      speedKmh: Math.round(speedKmh),
      rpm: Math.round(rpm),
      gear,
      throttle: this.smoothThrottle,
      steering: -this.playerSteerAngle,
      isBraking: this.inputThrottle < 0 || this.inputHandbrake,
      isHandbrake: this.inputHandbrake,
      headlightsOn: this.headlightsActive,
      fuelPercent: Math.round(this.playerFuel),
      collisions: this.totalCollisions,
      redLightViolations: this.redLightViolations,
      score: this.score,
      cashEarned: this.currentMission ? this.currentMission.rewardCash : 0,
      distanceTravelledMeters: Math.round(this.distanceMeters),
      healthPercent: Math.round(this.playerHealth),
      navigation: navInfo,
      speedLimitKmh: CITY_SPEED_LIMIT_KMH,
      activeRuleTip: this.activeRuleTip
    });
  }

  private render() {
    this.renderer.render(this.scene, this.camera);
  }

  public getPlayerPosition() {
    return { x: this.playerPos.x, z: this.playerPos.z, angle: this.playerAngle };
  }

  public getSignals() {
    return this.city.signals;
  }

  public getAIVehicles() {
    return this.aiVehicles;
  }
}
