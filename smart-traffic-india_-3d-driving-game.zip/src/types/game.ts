export type GameMode = 'menu' | 'career_select' | 'playing' | 'garage' | 'how_to_play' | 'cpp_code' | 'pause' | 'game_over' | 'mission_success';

export type CameraMode = 'chase' | 'close_chase' | 'hood' | 'top_down';

export type TimeOfDay = 'day' | 'sunset' | 'night';

export type VehicleId = 
  | 'hatchback'
  | 'sedan'
  | 'suv'
  | 'sports_car'
  | 'auto_rickshaw'
  | 'city_bus'
  | 'indian_truck'
  | 'motorcycle'
  | 'ambulance';

export interface VehicleDefinition {
  id: VehicleId;
  name: string;
  category: string;
  description: string;
  price: number;
  unlocked: boolean;
  color: string;
  accentColor: string;
  topSpeedKmh: number;
  acceleration: number; // 0-100 rating
  handling: number;     // steering response rating
  braking: number;      // brake strength rating
  dimensions: {
    width: number;
    height: number;
    length: number;
  };
}

export type SignalState = 'red' | 'yellow' | 'green';

export interface TrafficSignal {
  id: string;
  x: number;
  z: number;
  facing: 'north' | 'south' | 'east' | 'west';
  state: SignalState;
  timer: number;
  cycleTime: {
    green: number;
    yellow: number;
    red: number;
  };
}

export interface HazardObject {
  id: string;
  type: 'pothole' | 'speed_breaker' | 'barrier' | 'pedestrian' | 'cow';
  x: number;
  z: number;
  width: number;
  depth: number;
  height: number;
  rotation?: number;
  active: boolean;
  warningText: string;
  walkDir?: number;
}

export interface AIVehicle {
  id: string;
  type: VehicleId;
  color: string;
  x: number;
  z: number;
  speed: number; // units per second
  targetSpeed: number;
  maxSpeed: number;
  angle: number; // radians
  lane: number;
  roadAxis: 'x' | 'z';
  direction: 1 | -1;
  width: number;
  length: number;
  isBraking: boolean;
}

export interface Mission {
  id: number;
  title: string;
  subheading: string;
  description: string;
  targetKmhMin?: number;
  timeLimitSec: number;
  targetX: number;
  targetZ: number;
  rewardCash: number;
  rewardScore: number;
  allowedCollisions: number;
  allowedRedLights: number;
  trafficDensity: 'low' | 'medium' | 'high';
  timeOfDay: TimeOfDay;
}

export interface PlayerStats {
  cash: number;
  highScore: number;
  unlockedVehicles: VehicleId[];
  selectedVehicle: VehicleId;
  completedMissions: number[];
  customColors: Record<VehicleId, string>;
}

export interface NavigationInfo {
  hasGoal: boolean;
  goalTitle: string;
  distanceMeters: number;
  turnInstruction: 'straight' | 'left' | 'right' | 'uturn' | 'arriving';
  instructionText: string;
  relativeBearingDeg: number;
  targetX: number;
  targetZ: number;
  isWrongLane: boolean;
}

export interface DrivingTelemetry {
  speedKmh: number;
  rpm: number;
  gear: 'R' | 'N' | 'D';
  throttle: number;
  steering: number;
  isBraking: boolean;
  isHandbrake: boolean;
  headlightsOn: boolean;
  fuelPercent: number;
  collisions: number;
  redLightViolations: number;
  score: number;
  cashEarned: number;
  distanceTravelledMeters: number;
  healthPercent: number;
  navigation?: NavigationInfo;
  speedLimitKmh?: number;
  activeRuleTip?: string;
}

